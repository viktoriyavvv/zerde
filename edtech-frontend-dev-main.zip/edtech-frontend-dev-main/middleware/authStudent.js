export default function ({ $auth, redirect }) {
  const user = $auth.user

  if (user && (user.role === 'student' || user.role === 'admin')) {
    return true
  } else redirect('/')
}
