export default function ({ $auth, redirect }) {
  const user = $auth.user

  if (user && user.role !== 'student') {
    return redirect('/ScheduleMain')
  } else return true
}
