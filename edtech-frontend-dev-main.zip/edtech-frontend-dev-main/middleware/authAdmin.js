export default function ({ $auth, redirect }) {
  const user = $auth.user

  if (user && user.role === 'admin') {
    return true
  } else redirect('/')
}
