export default function ({ $auth, redirect }) {
  const user = $auth.user

  if (
    user &&
    (user.role === 'teacher' ||
      user.role === 'admin' ||
      user.role === 'class-teacher')
  ) {
    return true
  } else redirect('/')
}
