import { useUserStore, useProfileStore } from '~/store'

export default async function ({ $auth, $axios }) {
  if (!$auth.loggedIn) {
    return
  }

  const user = useUserStore()
  user.setUser($auth.user)

  if ($auth.user.role === 'student') {
    const studentProfile = useProfileStore()
    const res = await $axios.get('/accounts/me/student/')
    if (res.status === 200) {
      studentProfile.setProfile(res.data)
    }
  }
}
