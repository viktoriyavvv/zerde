import Vue from 'vue'
import VueHtml2pdf from 'vue-html2pdf'

Vue.use(VueHtml2pdf)
