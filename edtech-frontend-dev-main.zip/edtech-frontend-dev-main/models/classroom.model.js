export class Classroom {
  constructor({ uuid, name }) {
    this.uuid = uuid
    this.name = name
  }

  static serialize({ uuid, number: name }) {
    return new Classroom({
      uuid,
      name,
    })
  }

  static serializeList(classrooms) {
    return classrooms.map(Classroom.serialize)
  }
}
