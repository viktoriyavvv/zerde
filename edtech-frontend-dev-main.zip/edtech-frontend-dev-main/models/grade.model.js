import { StudentProfile, TeacherProfile } from './profile.model'

export class Grade {
  constructor({ uuid, teacherProfiles, studentProfiles, classTeacherProfile }) {
    this.uuid = uuid
    this.teacherProfiles = teacherProfiles
    this.studentProfiles = studentProfiles
    this.classTeacherProfile = classTeacherProfile
  }

  static serialize({
    uuid,
    teacher_profiles: teacherProfiles,
    student_profiles: studentProfiles,
    class_teacher_profile: classTeacherProfile,
  }) {
    return new Grade({
      uuid,
      teacherProfiles: teacherProfiles
        ? TeacherProfile.serializeList(teacherProfiles)
        : [],
      studentProfiles: studentProfiles
        ? StudentProfile.serializeList(studentProfiles)
        : [],
      classTeacherProfile: classTeacherProfile
        ? TeacherProfile.serialize(classTeacherProfile)
        : {},
    })
  }

  static serializeList(gradeList) {
    return gradeList.map(Grade.serialize)
  }
}

export class StudentGrade {
  constructor({ uuid, name }) {
    this.uuid = uuid
    this.name = name
  }

  static serialize({ uuid, name }) {
    return new StudentGrade({
      uuid,
      name,
    })
  }

  static serializeList(grade) {
    return grade.map(StudentGrade.serialize)
  }
}

export class ClassTeacherGrade {
  constructor({ uuid, name, classTeacherProfile }) {
    this.uuid = uuid
    this.name = name
    this.classTeacherProfile = classTeacherProfile
  }

  static serialize({ uuid, name, class_teacher_profile: classTeacherProfile }) {
    return new ClassTeacherGrade({
      uuid,
      name,
      classTeacherProfile: classTeacherProfile
        ? TeacherProfile.serialize(classTeacherProfile)
        : {},
    })
  }

  static serializeList(grade) {
    return grade.map(ClassTeacherGrade.serialize)
  }
}
