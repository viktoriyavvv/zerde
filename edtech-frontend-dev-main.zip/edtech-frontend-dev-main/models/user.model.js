export class User {
  constructor({ email, firstName, lastName, role, fullName }) {
    this.email = email
    this.firstName = firstName
    this.lastName = lastName
    this.fullName = fullName
    this.role = role
  }

  /**
   * @param {Object} data
   * @param {string} data.email
   * @param {string} data.first_name
   * @param {string} data.last_name
   * @returns {User}
   */
  static serialize({
    first_name: firstName,
    last_name: lastName,
    fullName,
    email,
    role,
  }) {
    return new User({
      firstName,
      lastName,
      email,
      role,
      fullName: lastName + ' ' + firstName,
    })
  }

  static serializeList(profiles) {
    return profiles.map(User.serialize)
  }
}
