import { ScheduleTime } from './schedule.model'
import { Classroom } from './classroom.model.js'
import { User } from '~/models/user.model'

export class Subject {
  constructor({ uuid, name, markCriteria }) {
    this.uuid = uuid
    this.name = name
    this.markCriteria = markCriteria
  }

  static serialize({ uuid, name, criteria_of_mark: markCriteria }) {
    return new Subject({
      uuid,
      name,
      markCriteria,
    })
  }

  static serializeList(subjects) {
    return subjects.map(Subject.serialize)
  }
}

export class ScheduledSubject {
  constructor({ uuid, subject, classroom, teacherName, scheduleTime }) {
    this.uuid = uuid
    this.subject = subject
    this.classroom = classroom
    this.teacherName = teacherName
    this.scheduleTime = scheduleTime
  }

  static serialize({
    uuid,
    subject,
    classroom,
    teacher_name: teacherName,
    schedule_time: scheduleTime,
  }) {
    return new ScheduledSubject({
      uuid,
      subject: Subject.serialize(subject),
      classroom: Classroom.serialize(classroom),
      teacherName: teacherName
        ? User.serialize(teacherName)
        : {
            firstName: '',
            lastName: '',
          },
      scheduleTime: ScheduleTime.serialize(scheduleTime),
    })
  }

  static serializeList(subjects) {
    return subjects.map(ScheduledSubject.serialize) || []
  }
}

export class ScheduledSubjectByDate {
  constructor({ date, scheduledSubjects }) {
    this.date = date
    this.scheduledSubjects = scheduledSubjects
  }

  static serialize({ date, scheduled_subjects: scheduledSubjects }) {
    return new ScheduledSubjectByDate({
      date,
      scheduledSubjects:
        ScheduledSubject.serializeList(scheduledSubjects) || {},
    })
  }

  static serializeList(days) {
    return days.map(ScheduledSubjectByDate.serialize)
  }
}
