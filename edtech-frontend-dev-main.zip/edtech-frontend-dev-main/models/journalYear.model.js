import { Grade } from '@/models/grade.model'
import { StudentProfile } from '@/models/profile.model'

export class SchoolYear {
  constructor({ studentMarkBooks, grade, quarters, examMark, uuid, byTerm }) {
    this.studentMarkBooks = studentMarkBooks
    this.grade = grade
    this.quarters = quarters
    this.examMark = examMark
    this.uuid = uuid
    this.byTerm = byTerm
  }

  static serialize({
    student_mark_books: studentMarkBooks,
    grade,
    quarters,
    exam_mark: examMark,
    uuid,
    by_term: byTerm,
  }) {
    return new SchoolYear({
      studentMarkBooks: StudentMarkBookYear.serializeList(studentMarkBooks),
      grade: Grade.serialize(grade),
      quarters: Quarters.serializeList(quarters),
      examMark: examMark ? ExamMark.serialize(examMark) : '',
      uuid,
      byTerm,
    })
  }
}

export class StudentMarkBookYear {
  constructor({
    uuid,
    studentProfile,
    quarterMarks,
    schoolYearMark,
    studentExamMark,
    finalMarkStudent,
    recommendedYearMark,
  }) {
    this.uuid = uuid
    this.studentProfile = studentProfile
    this.quarterMarks = quarterMarks
    this.schoolYearMark = schoolYearMark
    this.studentExamMark = studentExamMark
    this.finalMarkStudent = finalMarkStudent
    this.recommendedYearMark = recommendedYearMark
  }

  static serialize({
    uuid,
    student_profile: studentProfile,
    quarter_marks: quarterMarks,
    school_year_mark: schoolYearMark,
    student_exam_mark: studentExamMark,
    final_mark_student: finalMarkStudent,
    recommended_year_mark: recommendedYearMark,
  }) {
    return new StudentMarkBookYear({
      uuid,
      studentProfile: StudentProfile.serialize(studentProfile),
      quarterMarks: QuarterMarks.serializeList(quarterMarks),
      schoolYearMark: schoolYearMark
        ? SchoolYearMark.serialize(schoolYearMark)
        : '',
      studentExamMark: studentExamMark
        ? StudentExamMark.serialize(studentExamMark)
        : '',
      finalMarkStudent: finalMarkStudent
        ? FinalMarkStudent.serialize(finalMarkStudent)
        : '',
      recommendedYearMark,
    })
  }

  static serializeList(books) {
    return books ? books.map(StudentMarkBookYear.serialize) : []
  }
}

export class Quarters {
  constructor({ uuid, name, isTermQuarter }) {
    this.uuid = uuid
    this.name = name
    this.isTermQuarter = isTermQuarter
  }

  static serialize({ uuid, name, is_term_quarter: isTermQuarter }) {
    return new Quarters({
      uuid,
      name,
      isTermQuarter,
    })
  }

  static serializeList(quarters) {
    return quarters.map(Quarters.serialize)
  }
}

export class QuarterMarks {
  constructor({ uuid, quarter, markValue, maxMarkValue }) {
    this.uuid = uuid
    this.quarter = quarter
    this.markValue = markValue
    this.maxMarkValue = maxMarkValue
  }

  static serialize({
    uuid,
    quarter,
    mark_value: markValue,
    max_mark_value: maxMarkValue,
  }) {
    return new QuarterMarks({
      uuid,
      quarter: Quarter.serialize(quarter),
      markValue,
      maxMarkValue,
    })
  }

  static serializeList(marks) {
    return marks.map(QuarterMarks.serialize)
  }
}

export class Quarter {
  constructor({ uuid, name, isTermQuarter }) {
    this.uuid = uuid
    this.name = name
    this.isTermQuarter = isTermQuarter
  }

  static serialize({ uuid, name, is_term_quarter: isTermQuarter }) {
    return new Quarter({
      uuid,
      name,
      isTermQuarter,
    })
  }
}

export class SchoolYearMark {
  constructor({ uuid, markValue, maxMarkValue }) {
    this.uuid = uuid
    this.markValue = markValue
    this.maxMarkValue = maxMarkValue
  }

  static serialize({
    uuid,
    mark_value: markValue,
    max_mark_value: maxMarkValue,
  }) {
    return new SchoolYearMark({
      uuid,
      markValue,
      maxMarkValue,
    })
  }
}

export class ExamMark {
  constructor({ uuid, maxMarkValue, maxScoreValue }) {
    this.uuid = uuid
    this.maxMarkValue = maxMarkValue
    this.maxScoreValue = maxScoreValue
  }

  static serialize({
    uuid,
    max_mark_value: maxMarkValue,
    max_score_value: maxScoreValue,
  }) {
    return new ExamMark({
      uuid,
      maxMarkValue,
      maxScoreValue,
    })
  }
}

export class StudentExamMark {
  constructor({ markValue, scoreValue, uuid = '' }) {
    this.uuid = uuid
    this.markValue = markValue
    this.scoreValue = scoreValue
  }

  static serialize({ uuid, mark_value: markValue, score_value: scoreValue }) {
    return new StudentExamMark({
      uuid: uuid || '',
      markValue: markValue || '',
      scoreValue: scoreValue || '',
    })
  }
}

export class FinalMarkStudent {
  constructor({ uuid, markValue, maxMarkValue }) {
    this.uuid = uuid
    this.markValue = markValue
    this.maxMarkValue = maxMarkValue
  }

  static serialize({
    uuid,
    mark_value: markValue,
    max_mark_value: maxMarkValue,
  }) {
    return new FinalMarkStudent({
      uuid: uuid || '',
      markValue,
      maxMarkValue,
    })
  }
}
