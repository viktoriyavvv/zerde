import { Subject } from '~/models/subject.model'
import { Classroom } from '~/models/classroom.model'
import { User } from '~/models/user.model'

export class ScheduleTime {
  constructor({ startTime, endTime, breakTime, uuid }) {
    this.startTime = startTime
    this.endTime = endTime
    this.breakTime = breakTime
    this.uuid = uuid
  }

  static serialize({
    start_time: startTime,
    end_time: endTime,
    break_time: breakTime,
    uuid,
  }) {
    return new ScheduleTime({
      startTime,
      endTime,
      breakTime,
      uuid,
    })
  }

  static serializeList(bellrangList) {
    return bellrangList.map(ScheduleTime.serialize)
  }
}

export class Schedule {
  constructor({ uuid, subject, classroom, scheduleTime, date, teacher }) {
    this.uuid = uuid
    this.subject = subject
    this.classroom = classroom
    this.scheduleTime = scheduleTime
    this.date = date
    this.teacher = teacher
  }

  static serialize({
    uuid,
    subject,
    classroom,
    schedule_time: scheduleTime,
    schedule_date: date,
    teacher_profile: teacher,
  }) {
    return new Schedule({
      uuid,
      subject: Subject.serialize(subject),
      classroom: Classroom.serialize(classroom),
      scheduleTime: ScheduleTime.serialize(scheduleTime),
      date,
      teacher: TeacherProfileList.serialize(teacher),
    })
  }

  static serializeList(scheduleList) {
    return scheduleList.map(Schedule.serialize)
  }
}

export class TeacherProfileList {
  constructor({ uuid, account }) {
    this.uuid = uuid
    this.account = account
  }

  static serialize({ uuid, user_account: account }) {
    return new TeacherProfileList({
      uuid,
      account: User.serialize(account),
    })
  }

  static serializeList(teachers) {
    return teachers.map(TeacherProfileList.serialize)
  }
}
