import { Mark } from './mark.model'
import { User } from './user.model'

export class HomeworkStudent {
  constructor({
    uuid,
    deadline,
    state,
    subject,
    teacherName,
    mark,
    homeworkType,
  }) {
    this.uuid = uuid
    this.deadline = deadline
    this.state = state
    this.subject = subject
    this.teacherName = teacherName
    this.mark = mark
    this.homeworkType = homeworkType
  }

  static serialize({
    uuid,
    deadline,
    student_state: state,
    subject,
    teacher_name: teacherName,
    marks: mark,
    assignment_type: homeworkType,
  }) {
    return new HomeworkStudent({
      uuid,
      deadline: formatDeadline(deadline),
      state,
      subject,
      teacherName: User.serialize(teacherName),
      mark: Mark.serializeList(mark),
      homeworkType,
    })
  }

  static serializeList(homeworks) {
    return homeworks.map(HomeworkStudent.serialize)
  }
}

export class HomeworkTeacher {
  constructor({
    uuid,
    deadline,
    subject,
    state,
    grade,
    gradeGroup,
    description,
    repliedStudents,
    totalStudents,
    studentStats,
  }) {
    this.uuid = uuid
    this.deadline = deadline
    this.subject = subject
    this.state = state
    this.grade = grade
    this.gradeGroup = gradeGroup
    this.description = description
    this.repliedStudents = repliedStudents
    this.totalStudents = totalStudents
    this.studentStats = studentStats
  }

  static serialize({
    uuid,
    deadline,
    subject,
    state,
    grade,
    grade_group: gradeGroup,
    description,
    replied_student_count: repliedStudents,
    student_count: totalStudents,
    studentStats,
  }) {
    return new HomeworkTeacher({
      uuid,
      deadline: formatDeadline(deadline),
      subject,
      state,
      grade,
      gradeGroup,
      description,
      repliedStudents,
      totalStudents,
      studentStats: (repliedStudents * 100) / totalStudents,
    })
  }

  static serializeList(homeworks) {
    return homeworks.map(HomeworkTeacher.serialize)
  }
}

export class HomeworkDetails {
  constructor({
    uuid,
    teacherName,
    subject,
    description,
    attachedFiles,
    deadline,
  }) {
    this.uuid = uuid
    this.teacherName = teacherName
    this.subject = subject
    this.description = description
    this.attachedFiles = attachedFiles
    this.deadline = deadline
  }

  static serialize({
    uuid,
    teacher_name: teacherName,
    subject,
    description,
    attached_files: attachedFiles,
    deadline,
  }) {
    return new HomeworkDetails({
      uuid,
      teacherName: User.serialize(teacherName),
      subject,
      description,
      attachedFiles: File.serializeList(attachedFiles),
      deadline,
    })
  }
}

export class StudentAnswer {
  constructor({ uuid, doc, comment }) {
    this.uuid = uuid
    this.doc = doc
    this.comment = comment
  }

  static serialize({ uuid, comment, attached_files: doc }) {
    return new StudentAnswer({
      uuid: uuid || '',
      comment: comment || '',
      doc: doc ? File.serializeList(doc) : [],
    })
  }

  static serializeList(answers) {
    return answers ? answers.map(StudentAnswer.serialize) : []
  }
}

export class File {
  constructor({ uuid, name, file }) {
    this.uuid = uuid
    this.name = name
    this.file = file
  }

  static serialize({ uuid, file_name: name, file }) {
    return new File({
      uuid,
      name,
      file,
    })
  }

  static serializeList(files) {
    return files ? files.map(File.serialize) : []
  }
}

function formatDeadline(deadline) {
  return new Date(Date.parse(deadline)).toLocaleDateString('ru-RU', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })
}

export class CertainHomework {
  constructor({ uuid, userAccount, mark, studentAssignmentReplies }) {
    this.uuid = uuid
    this.userAccount = userAccount
    this.mark = mark
    this.studentAssignmentReplies = studentAssignmentReplies
  }

  static serialize({
    uuid,
    user_account: userAccount,
    mark,
    student_assignment_replies: studentAssignmentReplies,
  }) {
    return new CertainHomework({
      uuid,
      userAccount: User.serialize(userAccount),
      mark: mark ? Mark.serialize(mark) : {},
      studentAssignmentReplies: StudentReply.serializeList(
        studentAssignmentReplies
      ),
    })
  }

  static serializeList(homeworks) {
    return homeworks.map(CertainHomework.serialize)
  }
}

export class SelectedHomeworkTeacher {
  constructor({
    uuid,
    subject,
    deadline,
    grade,
    gradeGroup,
    description,
    attachedFiles,
    state,
    replies,
  }) {
    this.uuid = uuid
    this.subject = subject
    this.deadline = deadline
    this.grade = grade
    this.gradeGroup = gradeGroup
    this.description = description
    this.attachedFiles = attachedFiles
    this.state = state
    this.replies = replies
  }

  static serialize({
    uuid,
    subject,
    deadline,
    grade,
    grade_group: gradeGroup,
    description,
    attached_files: attachedFiles,
    state,
    student_profiles: replies,
  }) {
    return new SelectedHomeworkTeacher({
      uuid,
      subject,
      deadline,
      grade,
      gradeGroup,
      description,
      attachedFiles: attachedFiles ? File.serializeList(attachedFiles) : [],
      state,
      replies: replies ? CertainHomework.serializeList(replies) : [],
    })
  }
}

export class StudentReply {
  constructor({ uuid, files, comment }) {
    this.uuid = uuid
    this.files = files
    this.comment = comment
  }

  static serialize({ uuid, attached_files: files, comment }) {
    return new StudentReply({
      uuid,
      files: files ? File.serializeList(files) : [],
      comment,
    })
  }

  static serializeList(replies) {
    return replies.map(StudentReply.serialize)
  }
}
