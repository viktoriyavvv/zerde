export class Term {
  constructor({ uuid, name, startDate, endDate }) {
    this.uuid = uuid
    this.name = name
    this.startDate = startDate
    this.endDate = endDate
  }

  static serialize({ uuid, name, start_date: startDate, end_date: endDate }) {
    return new Term({
      uuid,
      name,
      startDate,
      endDate,
    })
  }

  static serializeList(terms) {
    return terms.map(Term.serialize)
  }
}
