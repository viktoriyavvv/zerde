import { User } from '~/models/user.model'

export class Assignment {
  constructor({ uuid, subject, teacherName, deadline }) {
    this.uuid = uuid
    this.subject = subject
    this.teacherName = teacherName
    this.deadline = deadline
  }

  static serialize({ uuid, subject, teacher_name: teacherName, deadline }) {
    return new Assignment({
      uuid,
      subject,
      teacherName: User.serialize(teacherName),
      deadline: deadline.replace(/T.*/, '').split('-').reverse().join('.'),
    })
  }
}

export class AssignmentMark {
  constructor({ assignment, maxMark, markValue, comment }) {
    this.assignment = assignment
    this.maxMark = maxMark
    this.markValue = markValue
    this.comment = comment
  }

  static serialize({
    assignment,
    max_mark_value: maxMark,
    mark_value: markValue,
    comment,
  }) {
    return new AssignmentMark({
      assignment: Assignment.serialize(assignment),
      maxMark,
      markValue,
      comment,
    })
  }

  static serializeList(assignmentMarkList) {
    return assignmentMarkList.map(AssignmentMark.serialize)
  }
}
