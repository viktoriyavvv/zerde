import { Subject } from '~/models/subject.model'
export class Mark {
  constructor({
    uuid,
    markValue,
    maxMarkValue,
    markPercentValue,
    comment,
    date,
  }) {
    this.uuid = uuid
    this.markValue = markValue
    this.maxMarkValue = maxMarkValue
    this.markPercentValue = markPercentValue
    this.comment = comment
    this.date = date
  }

  static serialize({
    uuid,
    mark_value: markValue,
    max_mark_value: maxMarkValue,
    markPercentValue,
    comment,
    date,
  }) {
    return new Mark({
      uuid,
      markValue,
      maxMarkValue,
      markPercentValue: (markValue * 100) / maxMarkValue,
      comment,
      date,
    })
  }

  static serializeList(marks) {
    if (marks === null || marks === undefined || marks.length === 0) {
      return [
        {
          uuid: '',
          markValue: '',
          maxMarkValue: '',
          comment: '',
        },
      ]
    }
    return marks.map(Mark.serialize)
  }
}

export class QuarterMark {
  constructor({
    uuid,
    subject,
    studentMarks,
    quizMarks,
    quizMarksList,
    examineMarksList,
    quarterMarkValue,
    marksQuizPercent,
    examPercent,
    totalPercent,
    totalAbsenceCount,
    delayAttendanceCount,
    reasonAbsenceCount,
  }) {
    this.uuid = uuid
    this.subject = subject
    this.studentMarks = studentMarks
    this.quizMarks = quizMarks
    this.quizMarksList = quizMarksList
    this.examineMarksList = examineMarksList
    this.quarterMarkValue = quarterMarkValue
    this.marksQuizPercent = marksQuizPercent
    this.examPercent = examPercent
    this.totalPercent = totalPercent
    this.totalAbsenceCount = totalAbsenceCount
    this.delayAttendanceCount = delayAttendanceCount
    this.reasonAbsenceCount = reasonAbsenceCount
  }

  static serialize({
    uuid,
    subject,
    student_marks: studentMarks,
    quiz_mark_students: quizMarks,
    quarter_mark: quarterMarkValue,
    marks_and_quiz_marks_percentage: marksQuizPercent,
    examine_marks_percentage: examPercent,
    all_marks_percentage: totalPercent,
    all_absences_count: totalAbsenceCount,
    attended_with_delay_count: delayAttendanceCount,
    absences_with_reason_count: reasonAbsenceCount,
  }) {
    return new QuarterMark({
      uuid,
      subject: Subject.serialize(subject),
      studentMarks: MarkDetailed.serializeList(studentMarks),
      quizMarks: QuizMark.serializeList(quizMarks),
      quizMarksList: QuizMark.serializeListFilterQuiz(quizMarks),
      examineMarksList: QuizMark.serializeListFilterExamine(quizMarks),
      quarterMarkValue: quarterMarkValue
        ? SchoolYearMark.serialize(quarterMarkValue)
        : {},
      marksQuizPercent,
      examPercent,
      totalPercent,
      totalAbsenceCount,
      delayAttendanceCount,
      reasonAbsenceCount,
    })
  }

  static serializeList(marks) {
    if (marks === null || marks.length === 0 || marks === undefined) {
      return []
    }
    return marks.map(QuarterMark.serialize)
  }
}

export class MarkDetailed {
  constructor({ uuid, markValue, markInfo, comment }) {
    this.uuid = uuid
    this.markValue = markValue
    this.markInfo = markInfo
    this.comment = comment
  }

  static serialize({ uuid, mark_value: markValue, mark: markInfo, comment }) {
    return new MarkDetailed({
      uuid,
      markValue,
      markInfo: MarkInfo.serialize(markInfo),
      comment,
    })
  }

  static serializeList(marks) {
    return marks && marks.length ? marks.map(MarkDetailed.serialize) : []
  }
}

export class MarkInfo {
  constructor({ uuid, maxMarkValue, date }) {
    this.uuid = uuid
    this.maxMarkValue = maxMarkValue
    this.date = date
  }

  static serialize({ uuid, max_mark_value: maxMarkValue, date }) {
    return new MarkInfo({
      uuid,
      maxMarkValue,
      date,
    })
  }

  static serializeList(marks) {
    if (marks === null || marks.length === 0 || marks === undefined) {
      return []
    }
    return marks.map(MarkInfo.serialize)
  }
}

export class QuizMark {
  constructor({ uuid, markValue, markType }) {
    this.uuid = uuid
    this.markValue = markValue
    this.markType = markType
  }

  static serialize({ uuid, mark_value: markValue, quiz_mark: markType }) {
    return new QuizMark({
      uuid,
      markValue,
      markType: QuizMarkType.serialize(markType),
    })
  }

  static serializeList(marks) {
    if (marks === null || marks.length === 0 || marks === undefined) {
      return []
    }
    return marks.map(QuizMark.serialize)
  }

  static serializeListFilterQuiz(marks) {
    if (marks === null || marks.length === 0 || marks === undefined) {
      return []
    }
    return marks
      .map(QuizMark.serialize)
      .filter((item) => item.markType.type === 'quiz')
  }

  static serializeListFilterExamine(marks) {
    return marks && marks.length
      ? marks
          .map(QuizMark.serialize)
          .filter((item) => item.markType.type === 'examine')
      : []
  }
}

export class QuizMarkType {
  constructor({ uuid, maxMarkValue, type }) {
    this.uuid = uuid
    this.maxMarkValue = maxMarkValue
    this.type = type
  }

  static serialize({
    uuid,
    max_mark_value: maxMarkValue,
    quiz_mark_type: type,
  }) {
    return new QuizMarkType({
      uuid,
      maxMarkValue,
      type,
    })
  }
}

export class YearMark {
  constructor({
    uuid,
    finalMarkStudent,
    quarterMarks,
    schoolYearMark,
    studentExamMark,
    subject,
  }) {
    this.uuid = uuid
    this.finalMarkStudent = finalMarkStudent
    this.quarterMarks = quarterMarks
    this.schoolYearMark = schoolYearMark
    this.studentExamMark = studentExamMark
    this.subject = subject
  }

  static serialize({
    uuid,
    final_mark_student: finalMarkStudent,
    quarter_marks: quarterMarks,
    school_year_mark: schoolYearMark,
    student_exam_mark: studentExamMark,
    subject,
  }) {
    return new YearMark({
      uuid,
      finalMarkStudent: finalMarkStudent
        ? SchoolYearMark.serialize(finalMarkStudent)
        : {},
      quarterMarks: quarterMarks
        ? QuarterMarkYear.serializeList(quarterMarks)
        : [],
      schoolYearMark: schoolYearMark
        ? SchoolYearMark.serialize(schoolYearMark)
        : {},
      studentExamMark: studentExamMark
        ? StudentExamMark.serialize(studentExamMark)
        : {},
      subject: Subject.serialize(subject),
    })
  }

  static serializeList(marks) {
    if (marks === null || marks.length === 0 || marks === undefined) {
      return []
    }
    return marks.map(YearMark.serialize)
  }
}

export class QuarterMarkYear {
  constructor({ uuid, markValue, maxMarkValue, quarter, markStateValue }) {
    this.uuid = uuid
    this.markValue = markValue
    this.maxMarkValue = maxMarkValue
    this.quarter = quarter
    this.markStateValue = markStateValue
  }

  static serialize({
    uuid,
    mark_value: markValue,
    max_mark_value: maxMarkValue,
    quarter,
    mark_state_value: markStateValue,
  }) {
    return new QuarterMarkYear({
      uuid,
      markValue,
      maxMarkValue,
      quarter,
      markStateValue,
    })
  }

  static serializeList(marks) {
    if (marks === null || marks.length === 0 || marks === undefined) {
      return []
    }
    return marks.map(QuarterMarkYear.serialize)
  }
}

export class SchoolYearMark {
  constructor({ uuid, markValue, maxMarkValue, markStateValue }) {
    this.uuid = uuid
    this.markValue = markValue
    this.maxMarkValue = maxMarkValue
    this.markStateValue = markStateValue
  }

  static serialize({
    uuid,
    mark_value: markValue,
    max_mark_value: maxMarkValue,
    mark_state_value: markStateValue,
  }) {
    return new SchoolYearMark({
      uuid,
      markValue,
      maxMarkValue,
      markStateValue,
    })
  }
}

export class StudentExamMark {
  constructor({ uuid, scoreValue, markValue }) {
    this.uuid = uuid
    this.scoreValue = scoreValue
    this.markValue = markValue
  }

  static serialize({ uuid, score_value: scoreValue, mark_value: markValue }) {
    return new StudentExamMark({
      uuid,
      scoreValue,
      markValue,
    })
  }
}

export class SubjectMarks {
  constructor({ uuid, studentMarks, attendance }) {
    this.uuid = uuid
    this.studentMarks = studentMarks
    this.attendance = attendance
  }

  static serialize({
    uuid,
    student_marks: studentMarks,
    attendances: attendance,
  }) {
    return new SubjectMarks({
      uuid,
      studentMarks: MarkDetailed.serializeList(studentMarks),
      attendance,
    })
  }
}
