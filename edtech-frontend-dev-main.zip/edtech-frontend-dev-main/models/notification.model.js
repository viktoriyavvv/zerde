import { User } from './user.model'

export class Notification {
  constructor({ userAccount, title, description, image, created }) {
    this.userAccount = userAccount
    this.title = title
    this.description = description
    this.image = image
    this.created = created
  }

  static serialize({
    user_account: userAccount,
    title,
    description,
    image,
    created,
  }) {
    return new Notification({
      userAccount: User.serialize(userAccount),
      title,
      description,
      image,
      created,
    })
  }

  static serializeList(notificats) {
    return notificats.map(Notification.serialize)
  }
}
