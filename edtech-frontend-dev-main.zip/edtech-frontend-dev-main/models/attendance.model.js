import { Subject } from '~/models/subject.model'
export class AttendanceQuarter {
  constructor({
    uuid,
    quarterAbsenceDayCount,
    quarterAbsencesWithReasonCount,
    quarterAllAbsencesCount,
    quarterAttendedWithDelayCount,
  }) {
    this.uuid = uuid
    this.quarterAbsenceDayCount = quarterAbsenceDayCount
    this.quarterAbsencesWithReasonCount = quarterAbsencesWithReasonCount
    this.quarterAllAbsencesCount = quarterAllAbsencesCount
    this.quarterAttendedWithDelayCount = quarterAttendedWithDelayCount
  }

  static serialize({
    uuid,
    quarter_absence_day_count: quarterAbsenceDayCount,
    quarter_absences_with_reason_count: quarterAbsencesWithReasonCount,
    quarter_all_absences_count: quarterAllAbsencesCount,
    quarter_attended_with_delay_count: quarterAttendedWithDelayCount,
  }) {
    return new AttendanceQuarter({
      uuid,
      quarterAbsenceDayCount,
      quarterAbsencesWithReasonCount,
      quarterAllAbsencesCount,
      quarterAttendedWithDelayCount,
    })
  }

  static serializeList(attendanceList) {
    return attendanceList.map(AttendanceQuarter.serialize)
  }
}

export class AttendanceYear {
  constructor({
    yearAbsenceDayCount,
    yearAbsencesWithReasonCount,
    yearAllAbsencesCount,
    yearAttendedWithDelayCount,
  }) {
    this.yearAbsenceDayCount = yearAbsenceDayCount
    this.yearAbsencesWithReasonCount = yearAbsencesWithReasonCount
    this.yearAllAbsencesCount = yearAllAbsencesCount
    this.yearAttendedWithDelayCount = yearAttendedWithDelayCount
  }

  static serialize({
    absence_day_count: yearAbsenceDayCount,
    absences_with_reason_count: yearAbsencesWithReasonCount,
    all_absences_count: yearAllAbsencesCount,
    attended_with_delay_count: yearAttendedWithDelayCount,
  }) {
    return new AttendanceYear({
      yearAbsenceDayCount,
      yearAbsencesWithReasonCount,
      yearAllAbsencesCount,
      yearAttendedWithDelayCount,
    })
  }
}

export class AttendanceTotal {
  constructor({ uuid, quartersAttendance, yearAttendance }) {
    this.uuid = uuid
    this.quartersAttendance = quartersAttendance
    this.yearAttendance = yearAttendance
  }

  static serialize({
    uuid,
    quarters: quartersAttendance,
    school_year_attendance: yearAttendance,
  }) {
    return new AttendanceTotal({
      uuid,
      quartersAttendance: AttendanceQuarter.serializeList(quartersAttendance),
      yearAttendance: AttendanceYear.serialize(yearAttendance),
    })
  }
}

export class Attendance {
  constructor({ subject, comment, state, date }) {
    this.subject = subject
    this.comment = comment
    this.state = state
    this.date = date
  }

  static serialize({ subject, comment, state, date }) {
    return new Attendance({
      subject: Subject.serialize(subject),
      comment,
      state,
      date: date.replace(/T.*/, '').split('-').reverse().join('.'),
    })
  }

  static serializeList(attendList) {
    return attendList.map(Attendance.serialize)
  }
}

export class AttendanceFull {
  constructor({ countNum, subjectsCount, attendanceList }) {
    this.countNum = countNum
    this.subjectsCount = subjectsCount
    this.attendanceList = attendanceList
  }

  static serialize({
    count: countNum,
    scheduled_subjects_count: subjectsCount,
    results: attendanceList,
  }) {
    return new AttendanceFull({
      countNum,
      subjectsCount,
      attendanceList: attendanceList
        ? Attendance.serializeList(attendanceList)
        : [],
    })
  }
}
