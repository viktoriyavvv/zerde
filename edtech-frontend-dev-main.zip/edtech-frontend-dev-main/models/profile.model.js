import { User } from './user.model'
import { Subject } from './subject.model'
import { StudentGrade } from './grade.model.js'

export class StudentProfile {
  constructor({
    userAccount,
    grade,
    address,
    phone,
    dateOfBirth,
    image,
    parent,
    parentPhone,
  }) {
    this.userAccount = userAccount
    this.grade = grade
    this.address = address
    this.phone = phone
    this.dateOfBirth = dateOfBirth
    this.image = image
    this.parent = parent
    this.parentPhone = parentPhone
  }

  /**
   * @param {Object} data
   * @returns {StudentProfile}
   */
  static serialize({
    user_account: userAccount,
    grade,
    address,
    phone,
    date_of_birth: dateOfBirth,
    image,
    parent_name: parent,
    parent_phone: parentPhone,
  }) {
    return new StudentProfile({
      userAccount: User.serialize(userAccount),
      grade: grade ? StudentGrade.serialize(grade) : {},
      address: address ? Address.serialize(address) : {},
      phone,
      dateOfBirth,
      image,
      parent,
      parentPhone,
    })
  }

  static serializeList(profiles) {
    return profiles.map(StudentProfile.serialize) || []
  }

  static deserialize({
    userAccount,
    grade,
    address,
    phone,
    dateOfBirth,
    image,
  }) {
    return {
      user_account: userAccount,
      grade,
      address,
      phone,
      date_of_birth: dateOfBirth,
      image,
    }
  }
}

export class Address {
  constructor({ city, street, apartment, floor, entrance, fullAddress }) {
    this.city = city
    this.street = street
    this.apartment = apartment
    this.floor = floor
    this.floor = entrance
    this.fullAddress = fullAddress
  }

  static serialize({ city, street, apartment, floor, entrance, fullAddress }) {
    return new Address({
      city: city || '',
      street: street || '',
      apartment: apartment || '',
      floor: floor || '',
      entrance: entrance || '',
      fullAddress: city + ', ' + street + ' ' + apartment,
    })
  }
}

export class TeacherProfile {
  constructor({ userAccount, subjects, image, phone }) {
    this.userAccount = userAccount
    this.subjects = subjects
    this.image = image
    this.phone = phone
  }

  static serialize({ user_account: userAccount, subjects, image, phone }) {
    return new TeacherProfile({
      userAccount: User.serialize(userAccount) || {},
      subjects: subjects ? Subject.serializeList(subjects) : [],
      image,
      phone,
    })
  }

  static serializeList(profiles) {
    return profiles.map(TeacherProfile.serialize) || []
  }
}
