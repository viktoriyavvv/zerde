export class Journal {
  constructor({ uuid, studentMarkBooks, grade, marks, quizMarks, byTerm }) {
    this.uuid = uuid
    this.studentMarkBooks = studentMarkBooks
    this.grade = grade
    this.marks = marks
    this.byTerm = byTerm
    this.quizMarks = quizMarks
  }

  static serialize({
    uuid,
    student_mark_books: studentMarkBooks,
    grade,
    marks,
    quiz_marks: quizMarks,
    by_term: byTerm,
  }) {
    return new Journal({
      uuid,
      studentMarkBooks: StudentMarkBook.serializeList(studentMarkBooks),
      grade: grade ? Grade.serialize(grade) : '',
      marks: Marks.serializeList(marks),
      quizMarks: QuizMarks.serializeList(quizMarks),
      byTerm,
    })
  }
}

export class StudentMarkBook {
  constructor({
    uuid,
    studentProfile,
    studentMarks,
    quizMarkStudents,
    quarterMark,
    marksAndQuizMarksPercentage,
    examineMarksPercentage,
    allMarksPercentage,
    recommendedMark,
  }) {
    this.uuid = uuid
    this.studentProfile = studentProfile
    this.studentMarks = studentMarks
    this.quizMarkStudents = quizMarkStudents
    this.quarterMark = quarterMark
    this.marksAndQuizMarksPercentage = marksAndQuizMarksPercentage
    this.examineMarksPercentage = examineMarksPercentage
    this.allMarksPercentage = allMarksPercentage
    this.recommendedMark = recommendedMark
  }

  static serialize({
    uuid,
    student_profile: studentProfile,
    student_marks: studentMarks,
    quiz_mark_students: quizMarkStudents,
    quarter_mark: quarterMark,
    marks_and_quiz_marks_percentage: marksAndQuizMarksPercentage,
    examine_marks_percentage: examineMarksPercentage,
    all_marks_percentage: allMarksPercentage,
    recommended_mark: recommendedMark,
  }) {
    return new StudentMarkBook({
      uuid,
      studentProfile: studentProfile
        ? StudentProfileJournal.serialize(studentProfile)
        : '',
      studentMarks: studentMarks
        ? StudentMarks.serializeList(studentMarks)
        : '',
      quizMarkStudents: quizMarkStudents
        ? QuizMarkStudents.serializeList(quizMarkStudents)
        : '',
      quarterMark: quarterMark ? QuarterMark.serialize(quarterMark) : '',
      marksAndQuizMarksPercentage,
      examineMarksPercentage,
      allMarksPercentage,
      recommendedMark,
    })
  }

  static serializeList(studentBooks) {
    return studentBooks ? studentBooks.map(StudentMarkBook.serialize) : []
  }
}

export class StudentProfileJournal {
  constructor({ uuid, userAccount }) {
    this.uuid = uuid
    this.userAccount = userAccount
  }

  static serialize({ uuid, user_account: userAccount }) {
    return new StudentProfileJournal({
      uuid,
      userAccount: UserAccount.serialize(userAccount),
    })
  }
}

export class StudentMarks {
  constructor({ uuid, markValue, mark, comment }) {
    this.uuid = uuid
    this.markValue = markValue
    this.mark = mark
    this.comment = comment
  }

  static serialize({ uuid, mark_value: markValue, mark, comment }) {
    return new StudentMarks({
      uuid,
      markValue,
      mark: MarkJournal.serialize(mark),
      comment,
    })
  }

  static serializeList(studentMarks) {
    return studentMarks.map(StudentMarks.serialize)
  }
}

export class MarkJournal {
  constructor({ uuid, maxMarkValue, date }) {
    this.uuid = uuid
    this.maxMarkValue = maxMarkValue
    this.date = date
  }

  static serialize({ uuid, max_mark_value: maxMarkValue, date }) {
    return new MarkJournal({ uuid, maxMarkValue, date })
  }
}

export class QuizMarkStudents {
  constructor({ uuid, markValue, quizMark }) {
    this.uuid = uuid
    this.markValue = markValue
    this.quizMark = quizMark
  }

  static serialize({ uuid, mark_value: markValue, quiz_mark: quizMark }) {
    return new QuizMarkStudents({
      uuid,
      markValue,
      quizMark: QuizMark.serialize(quizMark),
    })
  }

  static serializeList(someMark) {
    return someMark.map(QuizMarkStudents.serialize)
  }
}

export class QuizMark {
  constructor({ uuid, maxMarkValue, quizMarkType }) {
    this.uuid = uuid
    this.maxMarkValue = maxMarkValue
    this.quizMarkType = quizMarkType
  }

  static serialize({
    uuid,
    max_mark_value: maxMarkValue,
    quiz_mark_type: quizMarkType,
  }) {
    return new QuizMark({
      uuid,
      maxMarkValue,
      quizMarkType,
    })
  }
}

export class QuarterMark {
  constructor({ uuid, markValue, maxMarkValue }) {
    this.uuid = uuid
    this.markValue = markValue
    this.maxMarkValue = maxMarkValue
  }

  static serialize({
    uuid,
    mark_value: markValue,
    max_mark_value: maxMarkValue,
  }) {
    return new QuarterMark({
      uuid: uuid || '',
      markValue: markValue || 0,
      maxMarkValue: maxMarkValue || 0,
    })
  }
}

export class Marks {
  constructor({ uuid, markType, date }) {
    this.uuid = uuid
    this.markType = markType
    this.date = date
  }

  static serialize({ uuid, mark_type: markType, date }) {
    return new Marks({
      uuid,
      markType: MarkTypeObject.serialize(markType),
      date,
    })
  }

  static serializeList(justMarks) {
    return justMarks ? justMarks.map(Marks.serialize) : []
  }
}

export class Grade {
  constructor({ uuid, name, classTeacherProfile }) {
    this.uuid = uuid
    this.name = name
    this.classTeacherProfile = classTeacherProfile
  }

  static serialize({ uuid, name, class_teacher_profile: classTeacherProfile }) {
    return new Grade({
      uuid: uuid || '',
      name,
      classTeacherProfile: ClassTeacherProfile.serialize(classTeacherProfile),
    })
  }
}

export class ClassTeacherProfile {
  constructor({ userAccount }) {
    this.userAccount = userAccount
  }

  static serialize({ user_account: userAccount }) {
    return new ClassTeacherProfile({
      userAccount: UserAccount.serialize(userAccount),
    })
  }
}

export class UserAccount {
  constructor({ email, firstName, lastName }) {
    this.email = email
    this.firstName = firstName
    this.lastName = lastName
  }

  static serialize({ email, first_name: firstName, last_name: lastName }) {
    return new UserAccount({
      email,
      firstName,
      lastName,
    })
  }
}

export class QuizMarks {
  constructor({ uuid, maxMarkValue, quizMarkType }) {
    this.uuid = uuid
    this.maxMarkValue = maxMarkValue
    this.quizMarkType = quizMarkType
  }

  static serialize({
    uuid,
    max_mark_value: maxMarkValue,
    quiz_mark_type: quizMarkType,
  }) {
    return new QuizMarks({
      uuid,
      maxMarkValue,
      quizMarkType,
    })
  }

  static serializeList(quizMarks) {
    return quizMarks ? quizMarks.map(QuizMarks.serialize) : []
  }
}

export class MarkTypeResults {
  constructor({ uuid, title, shortTitle, maxMarkValue }) {
    this.uuid = uuid
    this.title = title
    this.shortTitle = shortTitle
    this.maxMarkValue = maxMarkValue
  }

  static serialize({
    uuid,
    title,
    short_title: shortTitle,
    max_mark_value: maxMarkValue,
  }) {
    return new MarkTypeResults({
      uuid,
      title,
      shortTitle,
      maxMarkValue,
    })
  }

  static serializeList(markType) {
    return markType ? markType.map(MarkTypeResults.serialize) : []
  }
}

export class MarkTypeObject {
  constructor({ uuid, title, shortTitle, maxMarkValue }) {
    this.uuid = uuid
    this.title = title
    this.shortTitle = shortTitle
    this.maxMarkValue = maxMarkValue
  }

  static serialize({
    uuid,
    title,
    short_title: shortTitle,
    max_mark_value: maxMarkValue,
  }) {
    return new MarkTypeObject({
      uuid,
      title,
      shortTitle,
      maxMarkValue,
    })
  }
}
