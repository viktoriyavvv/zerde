export class Bellrang {
  constructor({ uuid, startTime, endTime, breakTime }) {
    this.uuid = uuid
    this.startTime = startTime
    this.endTime = endTime
    this.breakTime = breakTime
  }

  static serialize({
    uuid,
    start_time: startTime,
    end_time: endTime,
    break_time: breakTime,
  }) {
    return new Bellrang({
      uuid,
      startTime,
      endTime,
      breakTime,
    })
  }

  static serializeList(bellrangList) {
    return bellrangList.map(Bellrang.serialize)
  }
}
