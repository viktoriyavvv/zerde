<template>
  <div class="main-component subjectMarks">
    <div v-if="displayMarks" class="main-component-text subjectMarks__table">
      <div class="subj-wrap table-wrap">
        <div class="subjectMarks__header">№</div>
        <div class="subjectMarks__header">Дата</div>
        <div class="subjectMarks__header">Отметки</div>
        <div class="subjectMarks__header">Присутствие</div>
        <div class="subjectMarks__header">Комментарий учителя</div>
      </div>
      <div
        v-for="(mark, index) in subjectMarkList.studentMarks"
        :key="index"
        class="subj-wrap table-wrap"
      >
        <div class="subjectMarks__cell">
          {{ index + 1 }}
        </div>
        <div class="subjectMarks__cell">
          {{ mark.markInfo.date }}
        </div>
        <div class="subjectMarks__cell subjectMarks__cell_mark-values">
          <div
            :class="{
              good: parseInt(mark.markValue, mark.markInfo.maxMarkValue) > 7,
              satisfactorily:
                parseInt(mark.markValue, mark.markInfo.maxMarkValue) > 4 ||
                parseInt(mark.markValue, mark.markInfo.maxMarkValue) <= 7,
              bad: parseInt(mark.markValue, mark.markInfo.maxMarkValue) <= 4,
            }"
            class="markDiv"
          >
            {{ mark.markValue }}
          </div>
        </div>
        <div class="subjectMarks__cell"></div>
        <div class="subjectMarks__cell">{{ mark.comment }}</div>
      </div>
    </div>
    <div v-else-if="displayError" class="text-center errorMessage">
      Результаты, соответствующие параметрам вашего запроса, не найдены
    </div>
    <div v-else-if="displayMsg" class="text-center infoMessage">
      Выберите предмет и четверть для отображения оценок
    </div>
    <v-skeleton-loader
      v-else-if="displayLoading"
      class="mx-auto"
      type="table-tbody"
    ></v-skeleton-loader>
  </div>
</template>

<script>
import { mapState } from 'pinia'
import { useMarksStore, useSubjectStore } from '~/store'
import { SubjectMarks } from '~/models/mark.model'
import { Subject } from '~/models/subject.model'
export default {
  name: 'SubjectMarks',
  computed: {
    ...mapState(useMarksStore, {
      subjectMarkList: (store) => SubjectMarks.serialize(store.subjectMarks),
      errorStatus: (store) => store.errorStatus,
      messageStatus: (store) => store.messageStatus,
      loading: (store) => store.loading,
    }),
    ...mapState(useSubjectStore, {
      subjectList: (store) => Subject.serializeList(store.subjects),
    }),
    displayMarks() {
      return (
        !this.errorStatus &&
        !this.loading &&
        !this.messageStatus &&
        this.subjectMarkList.studentMarks.length
      )
    },
    displayError() {
      return (
        this.errorStatus &&
        !this.loading &&
        !this.subjectMarkList.studentMarks.length
      )
    },
    displayMsg() {
      return (
        this.messageStatus &&
        !this.loading &&
        !this.subjectMarkList.studentMarks.length
      )
    },
    displayLoading() {
      return !this.errorStatus && this.loading
    },
  },
}
</script>
