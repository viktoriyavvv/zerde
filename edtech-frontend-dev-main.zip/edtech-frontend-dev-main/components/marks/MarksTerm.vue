<template>
  <div class="main-component termMarks">
    <div
      v-if="!loading && quarterMarkList.length > 0"
      class="main-component-text termMarks__table"
    >
      <div class="term-wrap table-wrap">
        <div class="termMarks__header">№</div>
        <span class="termMarks__header"> Предмет </span>
        <div class="termMarks__header">Отметки</div>
        <div class="termMarks__header"><span>Опоздания</span></div>
        <div class="termMarks__header termMarks__header_absense">
          <span class="termMarks__header">Пропуски</span>
          <div class="termMarks__double-cell double-cell">
            <span class="double-cell__value"> Всего </span>
            <span class="double-cell__value"> По болезни </span>
          </div>
        </div>
        <div class="termMarks__header">СОр 1</div>
        <div class="termMarks__header">СОр 2</div>
        <div class="termMarks__header">СОр 3</div>
        <div class="termMarks__header">СОр 4</div>
        <div class="termMarks__header">СОч</div>
        <div class="termMarks__header">%&#40;СОр + ФО&#41;</div>
        <div class="termMarks__header">% СОч</div>
        <div class="termMarks__header">Сумма %</div>
        <div class="termMarks__header">Оценка</div>
      </div>
      <div
        v-for="(mark, index) in quarterMarkList"
        :key="index"
        class="term-wrap table-wrap"
      >
        <div class="termMarks__cell">
          {{ index + 1 }}
        </div>
        <div class="termMarks__cell">
          {{ mark.subject.name }}
        </div>
        <div class="termMarks__cell termMarks__cell_mark-values">
          <v-tooltip
            v-for="(markVal, markValIdx) in mark.studentMarks"
            :key="markValIdx"
            bottom
            color="#F5F6FA"
          >
            <template #activator="{ on, attrs }">
              <div
                :class="{
                  good:
                    parseInt(markVal.markValue, markVal.markInfo.maxMarkValue) >
                    7,
                  satisfactorily:
                    parseInt(markVal.markValue, markVal.markInfo.maxMarkValue) >
                      4 &&
                    parseInt(
                      markVal.markValue,
                      markVal.markInfo.maxMarkValue
                    ) <= 7,
                  bad:
                    parseInt(
                      markVal.markValue,
                      markVal.markInfo.maxMarkValue
                    ) <= 4,
                }"
                class="markDiv"
                v-bind="attrs"
                v-on="on"
              >
                <span>{{ markVal.markValue }}</span>
              </div>
            </template>
            <span>{{ markVal.markInfo.date }}</span>
          </v-tooltip>
        </div>
        <div class="termMarks__cell">
          {{ mark.delayAttendanceCount }}
        </div>
        <div class="termMarks__cell termMarks__double-cell double-cell">
          <div class="double-cell__value">
            <span>{{ mark.totalAbsenceCount }}</span>
          </div>
          <div class="double-cell__value">
            <span>{{ mark.reasonAbsenceCount }}</span>
          </div>
        </div>
        <div
          v-for="(quizMark, quizMarkIdx) in mark.quizMarksList"
          :key="'quizMark' + quizMarkIdx"
          class="termMarks__cell"
        >
          {{ quizMark.markValue }}
        </div>
        <div
          v-for="(hyphen, hyphenIdx) in calculateQuizMarksCells(mark)"
          :key="'hyphen' + hyphenIdx"
          class="termMarks__cell"
        >
          -
        </div>
        <div class="termMarks__cell">
          <span v-if="mark.examineMarksList.length > 0">{{
            mark.examineMarksList[0].markValue
          }}</span>
          <span v-else>-</span>
        </div>
        <div class="termMarks__cell">
          {{ mark.marksQuizPercent }}
        </div>
        <div class="termMarks__cell">
          {{ mark.examPercent }}
        </div>
        <div class="termMarks__cell">
          {{ mark.totalPercent }}
        </div>
        <div class="termMarks__cell">
          <span
            v-if="
              mark.quarterMarkValue.uuid &&
              mark.subject.markCriteria === 'by_mark_value'
            "
            >{{ mark.quarterMarkValue.markValue }}</span
          >
          <span
            v-else-if="
              mark.quarterMarkValue.uuid &&
              mark.subject.markCriteria === 'by_mark_state_value'
            "
            ><span v-if="mark.quarterMarkValue.markStateValue === 'pass'"
              >Зачет</span
            ><span v-if="mark.quarterMarkValue.markStateValue === 'fail'"
              >Незачет</span
            ></span
          >
          <span v-else>-</span>
        </div>
      </div>
    </div>
    <v-skeleton-loader
      v-else
      class="mx-auto"
      type="table-tbody"
    ></v-skeleton-loader>
  </div>
</template>

<script>
import { mapState } from 'pinia'
import { useMarksStore } from '~/store'
import { QuarterMark } from '~/models/mark.model'
export default {
  name: 'QuarterMarks',
  computed: {
    ...mapState(useMarksStore, {
      quarterMarkList: (store) => QuarterMark.serializeList(store.quarterMarks),
      loading: (store) => store.loading,
    }),
  },
  methods: {
    calculateQuizMarksCells(mark) {
      return 4 - mark.quizMarksList.length
    },
    isObjectEmpty(object) {
      return Object.keys(object).length === 0
    },
    calculateQuarterYearMarksCells(mark) {
      return 4 - mark.quarterMarks.length
    },
  },
}
</script>
