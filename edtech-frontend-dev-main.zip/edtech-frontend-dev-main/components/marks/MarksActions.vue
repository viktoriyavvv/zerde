<template>
  <div class="main-component main-component-text">
    <div class="main-component-title">Действия</div>
    <div
      v-if="tabMode == 'quarter'"
      class="d-flex flex-column mt-4 quarterMarksActions"
    >
      <div
        class="d-flex justify-space-between flex-column mb-5"
        style="gap: 20px"
      >
        <button
          v-for="(quarter, quarterIdx) in quarters"
          :key="'quarterButton' + quarterIdx"
          :class="{
            buttonActive: quarter.uuid === currentTerm,
            button_disabled: quarter.uuid === 'fill',
          }"
          class="borderRadius buttonBlueBorder quarterMarkFilter"
          :disabled="quarter.uuid === 'fill'"
          @click="loadQuarterMarks(quarter.uuid)"
        >
          {{ romanNum[quarterIdx] }} четверть
        </button>
        <button
          class="borderRadius blueColor buttonBlueBorder d-flex align-center justify-center printPdfButton"
          @click="downloadPdf"
        >
          <img src="~/assets/images/printer-icon.svg" />
        </button>
      </div>
    </div>
    <div
      v-else-if="tabMode === 'subjects'"
      class="d-flex flex-column mt-4 subjectMarksActions"
    >
      <div
        class="d-flex justify-space-between flex-column mb-5"
        style="gap: 20px"
      >
        <drop-down-element
          type="subjects"
          :options="subjects"
          default="Выберите предмет"
          @input="filterOnSubject"
        ></drop-down-element>
        <drop-down-element
          type="quarters"
          :options="quarterList"
          default="Выберите четверть"
          @input="filterOnQuarter"
        ></drop-down-element>
        <button
          class="sidebar__button sidebar__button_dark"
          :class="{
            button_disabled: !subjectCheck || !quarterCheck,
          }"
          :disabled="!subjectCheck || !quarterCheck"
          @click="filterList"
        >
          Применить
        </button>
        <button
          class="borderRadius blueColor buttonBlueBorder d-flex align-center justify-center printPdfButton"
          :disabled="!subjectCheck || !quarterCheck"
          @click="downloadPdf"
        >
          <img src="~/assets/images/printer-icon.svg" />
        </button>
      </div>
    </div>
    <div v-else class="d-flex flex-column mt-4 yearMarksActions">
      <div
        class="d-flex justify-space-between flex-column mb-5"
        style="gap: 20px"
      >
        <button
          class="borderRadius blueColor buttonBlueBorder d-flex align-center justify-center printPdfButton"
          @click="downloadPdf"
        >
          <img src="~/assets/images/printer-icon.svg" />
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'pinia'
import DropDownElement from '~/components/main/DropDownElement'
import { useMarksStore } from '~/store'

export default {
  name: 'MarksActions',
  components: {
    DropDownElement,
  },

  props: {
    tabMode: {
      type: String,
      default: '',
    },
    quarterList: {
      type: Array,
      default() {
        return []
      },
    },
    subjects: {
      type: Array,
      default() {
        return []
      },
    },
  },

  data() {
    return {
      selectedQuarter: '',
      selectedSubject: '',
      romanNum: ['I', 'II', 'III', 'IV'],
    }
  },
  computed: {
    subjectCheck() {
      return this.subjects.some((e) => e.uuid === this.selectedSubject)
    },
    quarterCheck() {
      return this.quarterList.some((e) => e.uuid === this.selectedQuarter)
    },
    ...mapState(useMarksStore, {
      currentTerm: (store) => store.currentQuarter,
    }),
    quarters() {
      const quarterFiller = {
        uuid: 'fill',
        name: '0000',
        startDate: '2022-06-09',
        endDate: '2022-08-31',
      }
      const counter = 4 - this.quarterList.length
      const quarters = [...this.quarterList]
      for (let i = 0; i < counter; i++) {
        quarters.push(quarterFiller)
      }
      return quarters
    },
    test() {
      return true
    },
  },
  methods: {
    loadQuarterMarks(quarterId) {
      this.$emit('loadQuarterMarks', quarterId)
    },
    filterOnQuarter(selected) {
      this.selectedQuarter = selected.uuid
    },
    filterOnSubject(selected) {
      this.selectedSubject = selected.uuid
    },
    filterList() {
      this.$emit('filterList', this.selectedSubject, this.selectedQuarter)
    },
    downloadPdf() {
      this.$emit('downloadPdf')
    },
  },
}
</script>

<style lang="scss">
.buttonGrid {
  display: grid;
  grid-template-columns: repeat(2, 45%);
  justify-content: space-between;
}

.buttonActive {
  background-color: #003a70;
  color: #ffffff !important;

  &:hover {
    color: #003a70 !important;
  }
}

.button_disabled {
  opacity: 0.2;
  pointer-events: none;
}
</style>
