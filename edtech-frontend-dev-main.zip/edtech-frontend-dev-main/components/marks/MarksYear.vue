<template>
  <div class="main-component yearMarks">
    <div v-if="!loading" class="main-component-text yearMarks__table">
      <div class="overall-wrap table-wrap">
        <div class="yearMarks__header">№</div>
        <div class="yearMarks__header">Предмет</div>
        <div class="yearMarks__header">I четверть</div>
        <div class="yearMarks__header">
          II четверть<br />
          (I полугодие)
        </div>
        <div class="yearMarks__header">III четверть</div>
        <div class="yearMarks__header">
          IV четверть<br />
          (II полугодие)
        </div>
        <div class="yearMarks__header">Год</div>
        <div class="yearMarks__header">Экзамен</div>
        <div class="yearMarks__header">Итог</div>
      </div>
      <div
        v-for="(mark, idx) in yearMarkList"
        :key="'yearMark' + idx"
        class="overall-wrap table-wrap"
      >
        <div class="yearMarks__cell">
          {{ idx + 1 }}
        </div>
        <div class="yearMarks__cell">
          {{ mark.subject.name }}
        </div>
        <div
          v-for="quarter in quarterList"
          :key="quarter.uuid"
          class="yearMarks__cell"
        >
          <span
            v-if="
              mark.quarterMarks.some((e) => e.quarter.uuid === quarter.uuid) &&
              mark.subject.markCriteria === 'by_mark_value'
            "
          >
            {{
              mark.quarterMarks.find((e) => e.quarter.uuid === quarter.uuid)
                .markValue
            }}
          </span>

          <span
            v-else-if="
              mark.quarterMarks.some((e) => e.quarter.uuid === quarter.uuid) &&
              mark.subject.markCriteria === 'by_mark_state_value'
            "
          >
            {{
              mark.quarterMarks.find((e) => e.quarter.uuid === quarter.uuid)
                .markStateValue
            }}
          </span>

          <span v-else>&nbsp;—&nbsp;</span>
        </div>
        <div
          v-for="(placeholder, placeholderIndex) in blankCells"
          :key="'blank' + placeholderIndex"
          class="yearMarks__cell yearMarks__cell_placeholder"
        >
          &nbsp;—&nbsp;
        </div>
        <div class="yearMarks__cell">
          <span v-if="mark.schoolYearMark.markValue">
            {{ mark.schoolYearMark.markValue }}
          </span>
          <span v-else>&nbsp;—&nbsp;</span>
        </div>
        <div class="yearMarks__cell">
          <span v-if="mark.studentExamMark.scoreValue">
            {{ mark.studentExamMark.scoreValue }}
          </span>
          <span v-else>&nbsp;—&nbsp;</span>
        </div>
        <div
          v-if="isObjectEmpty(mark.finalMarkStudent)"
          class="yearMarks__cell"
        >
          &nbsp;—&nbsp;
        </div>
        <div
          v-else-if="mark.subject.markCriteria === 'by_mark_value'"
          class="yearMarks__cell"
        >
          {{ mark.finalMarkStudent.markValue }}
        </div>
        <div
          v-else-if="mark.subject.markCriteria === 'by_mark_state_value'"
          class="yearMarks__cell"
        >
          {{ mark.finalMarkStudent.markStateValue }}
        </div>
      </div>
      <div
        class="yearMarks__attendance-row absense-wrap table-wrap main-component-text"
      >
        <div class="yearMarks__attendance-cell">
          Пропущено полных дней всего
        </div>
        <div
          v-for="(attendanceQuarter, idx) in attendanceQuarters"
          :key="'quarterAbsenceDayCount' + idx"
          class="yearMarks__attendance-cell"
        >
          {{ attendanceQuarter.quarterAbsenceDayCount }}
        </div>
        <div
          v-for="(placeholder, placeholderIndex) in blankCells"
          :key="'blankAttOverall' + placeholderIndex"
          class="yearMarks__attendance-cell yearMarks__cell_placeholder"
        >
          &nbsp;—&nbsp;
        </div>
        <div class="yearMarks__attendance-cell">
          {{ attendanceYear.yearAbsenceDayCount }}
        </div>
        <div
          v-for="count in 2"
          :key="'quarterAbsenceDayCountCell' + count"
          class="yearMarks__attendance-cell"
        ></div>
      </div>
      <div
        class="yearMarks__attendance-row absense-wrap table-wrap main-component-text"
      >
        <div class="yearMarks__attendance-cell">В т.ч. по болезни</div>
        <div
          v-for="(attendanceQuarter, idx) in attendanceQuarters"
          :key="'quarterAbsencesWithReasonCount' + idx"
          class="yearMarks__attendance-cell"
        >
          {{ attendanceQuarter.quarterAbsencesWithReasonCount }}
        </div>
        <div
          v-for="(placeholder, placeholderIndex) in blankCells"
          :key="'blankAttReason' + placeholderIndex"
          class="yearMarks__attendance-cell yearMarks__cell_placeholder"
        >
          &nbsp;—&nbsp;
        </div>
        <div class="yearMarks__attendance-cell">
          {{ attendanceYear.yearAbsencesWithReasonCount }}
        </div>
        <div
          v-for="count in 2"
          :key="'quarterAbsencesWithReasonCountCell' + count"
          class="yearMarks__attendance-cell"
        ></div>
      </div>
      <div
        class="yearMarks__attendance-row absense-wrap table-wrap main-component-text"
      >
        <div class="yearMarks__attendance-cell">Пропущено уроков всего</div>
        <div
          v-for="(attendanceQuarter, idx) in attendanceQuarters"
          :key="'quarterAllAbsencesCount' + idx"
          class="yearMarks__attendance-cell"
        >
          {{ attendanceQuarter.quarterAllAbsencesCount }}
        </div>
        <div
          v-for="(placeholder, placeholderIndex) in blankCells"
          :key="'blankAttClass' + placeholderIndex"
          class="yearMarks__attendance-cell yearMarks__cell_placeholder"
        >
          &nbsp;—&nbsp;
        </div>
        <div class="yearMarks__attendance-cell">
          {{ attendanceYear.yearAllAbsencesCount }}
        </div>
        <div
          v-for="count in 2"
          :key="'quarterAllAbsencesCountCell' + count"
          class="yearMarks__attendance-cell"
        ></div>
      </div>
      <div
        class="yearMarks__attendance-row absense-wrap table-wrap main-component-text"
      >
        <div class="yearMarks__attendance-cell">Количество опозданий</div>
        <div
          v-for="(attendanceQuarter, idx) in attendanceQuarters"
          :key="'quarterAttendedWithDelayCount' + idx"
          class="yearMarks__attendance-cell"
        >
          {{ attendanceQuarter.quarterAttendedWithDelayCount }}
        </div>
        <div
          v-for="(placeholder, placeholderIndex) in blankCells"
          :key="'blankAttDelay' + placeholderIndex"
          class="yearMarks__attendance-cell yearMarks__cell_placeholder"
        >
          &nbsp;—&nbsp;
        </div>
        <div class="yearMarks__attendance-cell">
          {{ attendanceYear.yearAttendedWithDelayCount }}
        </div>
        <div
          v-for="count in 2"
          :key="'quarterAttendedWithDelayCountCell' + count"
          class="yearMarks__attendance-cell"
        ></div>
      </div>
    </div>
    <v-skeleton-loader
      v-else
      class="mx-auto"
      type="table-tbody"
    ></v-skeleton-loader>
  </div>
</template>

<script>
import { mapState } from 'pinia'
import { useTermStore, useMarksStore, useAttendanceStore } from '~/store'
import { Term } from '~/models/term.model'
import { AttendanceQuarter, AttendanceYear } from '~/models/attendance.model'
import { YearMark } from '~/models/mark.model'
export default {
  name: 'YearMarks',
  computed: {
    ...mapState(useTermStore, {
      quarterList: (store) => Term.serializeList(store.terms),
    }),
    ...mapState(useAttendanceStore, {
      attendanceQuarters: (store) =>
        AttendanceQuarter.serializeList(store.attendanceQuarters),
      attendanceYear: (store) => AttendanceYear.serialize(store.attendanceYear),
    }),
    ...mapState(useMarksStore, {
      yearMarkList: (store) => YearMark.serializeList(store.yearMarks),
      loading: (store) => store.loading,
    }),
    blankCells() {
      return 4 - this.quarterList.length
    },
  },
  methods: {
    isObjectEmpty(object) {
      return Object.keys(object).length === 0
    },
  },
}
</script>
