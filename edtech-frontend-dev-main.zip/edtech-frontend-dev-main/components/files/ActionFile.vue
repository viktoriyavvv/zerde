<template>
  <div class="action">
    <div class="block__title">
      <p class="name">Действия</p>
      <hr />
    </div>
    <div class="action__text">
      <input class="search" type="text" placeholder="Поиск по странице" />
      <v-container fluid>
        <v-row align="center">
          <v-col class="d-flex" cols="12" sm="6">
            <v-select :items="items" label="Выбор предмета" solo></v-select>
          </v-col>
        </v-row>
        <v-row align="center">
          <v-col class="d-flex" cols="12" sm="6">
            <v-select :items="items2" label="Выбор раздела" solo></v-select>
          </v-col>
        </v-row>
      </v-container>
      <div class="switch-button">
        <input class="switch-button-checkbox" type="checkbox" />
        <label class="switch-button-label" for=""
          ><span class="switch-button-label-span">Таблица</span></label
        >
      </div>
      <v-btn>Применить</v-btn>
      <v-container fluid>
        <v-row align="center">
          <v-col class="d-flex" cols="12" sm="6">
            <v-select :items="items3" label="Сортировка по" solo></v-select>
          </v-col>
        </v-row>
      </v-container>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ActionFile',
  data: () => ({
    items: ['Физика', 'Математика'],
    items2: ['первый', 'второй'],
    items3: ['алфавиту', 'дате'],
  }),
}
</script>

<style lang="scss">
.action {
  border-radius: 8px;
  background-color: #ffffff;
  padding: 25px;
  box-shadow: 0px 4px 25px 0px #0000000a;
  &__text {
    font-size: 14px;
    font-weight: 500;
  }

  .search {
    width: 100%;
    outline: none;
    background-color: #f1f2f3;
    border-radius: 10px;
    box-shadow: 0px 4px 25px 0px #0000000a;
    margin: 15px 0;
    padding: 12px 20px;
  }
  .row {
    display: block;
    .d-flex {
      max-width: none;
      padding: 0;
      .v-input__control {
        & label {
          color: #003a70;
        }
        .v-input__slot {
          border: 1px #003a70 solid;
          border-radius: 10px;
          .v-select__selection {
            color: #003a70;
          }
        }
      }
    }
  }
  .v-btn {
    color: #fff;
    background-color: #003a70 !important;
    width: 100%;
    margin: 20px 0;
    border-radius: 10px;
    text-transform: unset;
  }
}

// SWITCH
.switch-button {
  margin: 0 auto;
  background: #cdcecf;
  border-radius: 10px;
  overflow: hidden;
  width: 100%;
  height: 42px;
  text-align: center;

  color: #fff;
  position: relative;
  position: relative;

  &:before {
    content: 'Плитка';
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    width: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 3;
    pointer-events: none;
  }

  &-checkbox {
    cursor: pointer;
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    z-index: 2;

    &:checked + .switch-button-label:before {
      transform: translateX(100%);
      transition: transform 300ms linear;
    }

    & + .switch-button-label {
      position: relative;
      padding: 10px 0;
      display: block;
      user-select: none;
      width: 50%;
      pointer-events: none;

      &:before {
        content: '';
        background: #003a70;
        height: 100%;
        width: 100%;
        position: absolute;
        left: 0;
        top: 0;
        border-radius: 10px;
        transform: translateX(0);
        transition: transform 300ms;
      }

      .switch-button-label-span {
        position: relative;
      }
    }
  }
}
</style>
