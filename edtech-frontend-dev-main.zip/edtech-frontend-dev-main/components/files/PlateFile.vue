<template>
  <v-expansion-panels focusable>
    <v-expansion-panel v-for="(item, i) in 5" :key="i">
      <v-expansion-panel-header>Русский язык</v-expansion-panel-header>
      <v-expansion-panel-content>
        <v-simple-table>
          <template #default>
            <thead>
              <tr>
                <th class="text-left">Название</th>
                <th class="text-left">Дата загрузки</th>
                <th class="text-left">Размер</th>
                <th class="text-left">Действие</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="itembox in desserts" :key="itembox.name">
                <td>{{ itembox.name }}</td>
                <td>{{ itembox.calories }}</td>
                <td>{{ itembox.size }}</td>
                <td>
                  <button><img src="~/assets/images/Star.svg" alt="" /></button
                  ><button>
                    <img src="~/assets/images/Download.svg" alt="" /></button
                  ><button>
                    <img src="~/assets/images/Delete.svg" alt="" />
                  </button>
                </td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-expansion-panel-content>
    </v-expansion-panel>
  </v-expansion-panels>
</template>

<script>
export default {
  name: 'PlateFile',
  data() {
    return {
      desserts: [
        {
          name: 'Параграф 1Б.pdf',
          calories: '30 октября 2021 г.',
          size: '1,5 Mb',
        },
        {
          name: 'Ice cream sandwich',
          calories: 237,
        },
        {
          name: 'Eclair',
          calories: 262,
        },
      ],
    }
  },
}
</script>

<style lang="scss">
.v-expansion-panel-header {
  font-size: 14px;
  font-weight: 600;
}
th {
  font-size: 14px !important;
  color: #000 !important;
}
td {
  font-weight: 500;
  button {
    width: 32px;
    height: 32px;
    background-color: #f5f6fa;
    border-radius: 6px;
    margin-right: 6px;
    &:last-child {
      margin-right: 0;
    }
  }
}
</style>
