<template>
  <div class="table">
    <div class="grid">
      <div
        v-for="(file, index) in files"
        :key="index"
        @click="$router.push(`/folderFiles`)"
      >
        <img alt="" src="~/assets/images/folder.svg" />
        <p>{{ file.name }}</p>
        <span>{{ file.amount }}</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TableFile',
  props: {
    files: {
      required: true,
      type: Array,
    },
  },
}
</script>

<style lang="scss">
.table {
  .grid {
    display: grid;
    grid-template-columns: auto auto auto auto auto;
    row-gap: 46px;
    text-align: center;
    padding-top: 40px;
    div {
      cursor: pointer;
    }
    img {
      width: 80px;
      height: 62px;
    }
    p {
      font-weight: 700;
    }
    span {
      font-size: 14px;
      font-weight: 500;
      color: #b5b5c3;
    }
  }
}
</style>
