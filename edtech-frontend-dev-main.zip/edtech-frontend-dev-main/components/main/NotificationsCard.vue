<template>
  <div class="notificationWrap">
    <div
      v-for="(item, index) in notifications"
      :key="index"
      class="notificationCard"
    >
      <div class="d-flex">
        <div class="main-component-text font-weight-bold">{{ item.title }}</div>
        <div class="main-component-text grayColor ml-auto">
          {{
            new Date(Date.parse(item.created)).toLocaleDateString(
              'ru-RU',
              options
            )
          }}
        </div>
      </div>
      <div
        class="backImg"
        :style="{ 'background-image': 'url(' + item.image + ')' }"
      ></div>
      <div class="describe main-component-text truncate-text">
        {{ item.description }}
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions, mapStores, mapState } from 'pinia'
import { useNotificationStore } from '~/store/notification'
import { Notification } from '~/models'

export default {
  name: 'NotificationsCard',
  data() {
    return {
      options: { day: '2-digit', month: '2-digit', year: 'numeric' },
    }
  },

  computed: {
    ...mapStores(useNotificationStore),
    ...mapState(useNotificationStore, {
      notifications: (store) => Notification.serializeList(store.notifications),
    }),
  },

  mounted() {
    this.loadNotifications()
  },

  methods: {
    ...mapActions(useNotificationStore, ['loadNotifications']),
  },
}
</script>

<style lang="scss">
@import '/assets/main';
.notificationCard {
  background: #ffffff;
  border: 1px solid #e8e8e8;
  box-sizing: border-box;
  border-radius: 10px;
  padding: 20px 20px 15px;
  width: 363px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.backImg {
  height: 90px;
  width: 220px;
  background-position: center;
  background-size: cover;
  border-radius: 10px;
}

.notificationWrap {
  display: flex;
  flex-direction: column;
  gap: 15px;
  max-height: 70vh;
  width: fit-content;
  padding-right: 10px;
  overflow-x: hidden;
  overflow-x: auto;
}

.truncate-text {
  height: 68px;
  text-overflow: ellipsis;
  overflow: hidden;
}

::-webkit-scrollbar {
  width: 3px;
}

::-webkit-scrollbar-track {
  background: #e8e8e8;
  border-radius: 40px;
}

::-webkit-scrollbar-thumb {
  background: #313131;
  border-radius: 40px;
}
</style>
