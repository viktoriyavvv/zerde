<template>
  <div class="main-component">
    <div class="main-component-title">
      <p class="name">Успеваемость</p>
    </div>
    <div v-if="assignments.length" class="under perfomTable">
      <p class="main-component-text-little grayColor subj py-4">Предмет</p>
      <p class="main-component-text-little grayColor task py-4">Задание</p>
      <p class="main-component-text-little grayColor mark py-4">Оценка</p>
    </div>
    <div v-if="!loading && assignments.length" class="overflow">
      <div v-if="!loading" id="academPerformance" class="overflow">
        <div
          v-for="(item, index) in assignments"
          :key="index"
          class="perfomTable under py-4"
        >
          <div>
            <p class="main">{{ item.assignment.subject }}</p>
            <p class="grayColor main-component-text-little">
              {{ item.assignment.teacherName.lastName }}
              {{ item.assignment.teacherName.firstName.substring(0.1) }}.
            </p>
          </div>
          <div>
            <p class="main">ФО1</p>
            <p class="grayColor main-component-text-little">
              {{ item.assignment.deadline }}
            </p>
          </div>
          <div>
            <p class="grayColor main-component-text-little pb-4">
              {{ item.markValue }} / {{ item.maxMark }}
            </p>
            <v-progress-linear
              rounded
              :color="colors(item)"
              :value="percentage(item)"
              style="width: 50%"
            ></v-progress-linear>
          </div>
        </div>
      </div>
    </div>
    <div v-if="!assignments.length" class="ml-5 my-4 subtitle-text">
      Вы не получили ни одной оценки
    </div>
    <v-skeleton-loader
      v-if="loading"
      class="overflow"
      type="table-tbody"
    ></v-skeleton-loader>
  </div>
</template>

<script>
import { mapActions, mapState, mapStores } from 'pinia'
import { AssignmentMark } from '~/models/assignment.model'
import { useAssignmentStore } from '~/store/assignment'

export default {
  name: 'AcademicPerformance',
  computed: {
    ...mapStores(useAssignmentStore),
    ...mapState(useAssignmentStore, {
      assignments: (store) => AssignmentMark.serializeList(store.assignments),
      loading: (store) => store.loading,
    }),
  },

  mounted() {
    this.loadAssignment()
  },

  methods: {
    ...mapActions(useAssignmentStore, ['loadAssignment']),

    percentage(item) {
      return (item.markValue / item.maxMark) * 100
    },

    colors(item) {
      const percent = this.percentage(item)
      if (percent <= 50) {
        return '#FF2E2E'
      } else if (percent > 50 && percent <= 75) {
        return '#FFC72C'
      } else return '#0BB783'
    },
  },
}
</script>

<style lang="scss">
.perfomTable {
  display: grid;
  grid-template-columns: 1fr 0.5fr 1fr;
  align-items: center;
}

.overflow {
  height: 150px;
  overflow-y: auto;
  overflow-x: hidden;
}

.main {
  font-size: 14px;
  font-weight: 600;
}

.under {
  border-bottom: 1px solid #e5e5e5;
}
</style>
