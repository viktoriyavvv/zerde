<template>
  <div class="profile">
    <div v-if="!loading">
      <div class="profile__info">
        <div class="profile__pic">
          <img v-if="profilePic" :src="profilePic" />
          <img v-else src="~/assets/images/avatar-placeholder.png" alt="" />
          <p>{{ profile.fullName }}</p>
        </div>
        <div>
          <p v-if="profileDataReady">
            {{ profile.userAccount.firstName }}
            {{ profile.userAccount.lastName }}
          </p>

          <p v-if="profileDataReady">
            Класс: <span>{{ profile.grade.name }}</span>
          </p>
        </div>
      </div>
      <v-divider />
      <router-link
        to="/student/myClass"
        class="blueColor borderRadius buttonBlueBorder d-flex align-center justify-center main-component-text"
      >
        Мой класс
      </router-link>
    </div>
    <v-skeleton-loader v-else type="card"></v-skeleton-loader>
  </div>
</template>

<script>
import { mapState, mapStores } from 'pinia'
import { useProfileStore } from '~/store'
import { StudentProfile } from '~/models'

export default {
  name: 'StudentProfile',
  props: {
    profileDataReady: Boolean,
  },
  computed: {
    ...mapStores(useProfileStore),
    ...mapState(useProfileStore, {
      profile: (store) => StudentProfile.serialize(store.profile),
      profilePic: (store) => store.profilePic,
      loading: (store) => store.loading,
    }),
  },
}
</script>

<style lang="scss">
.profile {
  padding: 25px;
  font-size: 14px;
  background-color: #fff;
  border-radius: 10px;

  &__info {
    display: flex;
    align-items: center;
  }

  img {
    width: 64px;
    height: 64px;
    margin-right: 20px;
    border-radius: 99px;
  }

  p:first-child {
    font-weight: 600;
    margin-bottom: 5px;
  }

  p:last-child {
    font-weight: 500;

    span {
      font-weight: 400;
    }
  }

  hr {
    background-color: #313131;
    margin: 15px 0;
  }
}
</style>
