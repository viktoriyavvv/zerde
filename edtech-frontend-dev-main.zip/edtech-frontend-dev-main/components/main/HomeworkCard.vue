<template>
  <div class="main-component">
    <div class="main-component-title">
      <div class="options">
        <p class="name">Домашние задания</p>
        <div>
          <button
            class="subtitle-text"
            :class="{ chosen: whichHome === 'all' }"
            @click="
              whichHome = 'all'
              setHomework()
            "
          >
            Все
          </button>
          <button
            class="subtitle-text"
            :class="{ chosen: whichHome === 'done' }"
            @click="
              whichHome = 'done'
              setHomework('done')
            "
          >
            Выполнены
          </button>
          <button
            class="subtitle-text"
            :class="{ chosen: whichHome === 'not' }"
            @click="
              whichHome = 'not'
              setHomework('not_done')
            "
          >
            Не выполены
          </button>
        </div>
      </div>
    </div>
    <div v-if="!loading">
      <div class="d-flex under">
        <p class="subj main-component-text-little grayColor py-4">Предмет</p>
        <p class="task main-component-text-little grayColor py-4">Задание</p>
        <p class="endline main-component-text-little grayColor py-4">
          Срок выполнения
        </p>
        <p class="status main-component-text-little grayColor py-4">Статус</p>
        <p class="mark main-component-text-little grayColor py-4">Оценка</p>
      </div>
      <div class="overflow">
        <div
          v-for="(subj, index) in homeworkList"
          :key="index"
          class="d-flex under align-center py-2"
        >
          <div class="subj">
            <p class="main-component-text font-weight-bold">
              {{ subj.subject.name }}
            </p>
            <p class="main-component-text grayColor">
              {{ subj.teacherName.lastName }}
              {{ subj.teacherName.firstName.substring(0, 1) }}.
            </p>
          </div>
          <div class="task">
            <p
              v-if="subj.homeworkType"
              class="main-component-text font-weight-bold"
            >
              {{ subj.homeworkType }}
            </p>
          </div>
          <div class="endline">
            <p class="main-component-text font-weight-bold">
              {{ subj.deadline }}
            </p>
          </div>
          <div class="status">
            <p class="main-component-text font-weight-bold">
              {{ subj.state === 'done' ? 'Выполнено' : 'Не выполнено' }}
            </p>
          </div>
          <div v-if="subj.mark[0]" class="mark">
            <p
              v-if="subj.mark[0].markValue"
              class="main-component-text-little font-weight-bold grayColor"
            >
              {{ subj.mark[0].markValue }}/{{ subj.mark[0].maxMarkValue }}
            </p>
            <v-progress-linear
              rounded
              color="#0BB783"
              :value="subj.mark[0].markPercentValue"
            >
            </v-progress-linear>
          </div>
        </div>
      </div>
    </div>
    <v-skeleton-loader
      v-else
      class="mx-auto overflow"
      type="table-tbody"
    ></v-skeleton-loader>
  </div>
</template>

<script>
import { mapActions, mapStores, mapState } from 'pinia'
import { useHomeworkStore } from '~/store'
import { HomeworkStudent } from '~/models/homework.model'

export default {
  name: 'HomeworkCard',
  data: () => ({
    whichHome: 'all',
    options: { year: 'numeric', month: 'long', day: 'numeric' },
    doneCount: 0,
    notDoneCount: 0,
    allCount: 0,
  }),
  computed: {
    ...mapStores(useHomeworkStore),
    ...mapState(useHomeworkStore, {
      homeworkList: (store) => HomeworkStudent.serializeList(store.homeworks),
      loading: (store) => store.loading,
    }),
  },

  mounted() {
    this.setHomework()
    this.counter()
  },
  methods: {
    ...mapActions(useHomeworkStore, ['setHomework']),
    counter() {
      const temp = this.homeworkList
      this.allCount = this.homeworkList.length
      temp.forEach((item) => {
        if (item.state === 'done') {
          this.doneCount++
        } else if (item.state === 'not_done') {
          this.notDoneCount++
        }
      })
    },
  },
}
</script>

<style lang="scss">
.options {
  display: flex;
  justify-content: space-between;

  button {
    font-weight: 500;
    color: #8b8b8b;
    margin-right: 15px;
    transition: 0.3s;
  }

  .chosen {
    text-decoration: underline;
    color: #003a70;
    transition: 0.3s;
  }
}

.under {
  border-bottom: 1px solid #e5e5e5;
}

.overflow {
  height: 190px;
  overflow-y: auto;
  overflow-x: hidden;
}

.subj {
  width: 25%;
}

.task {
  width: 10%;
}

.endline {
  width: 25%;
}

.status {
  width: 15%;
}

.mark {
  width: 25%;

  div {
    width: 50%;
    height: 5px !important;
  }
}
</style>
