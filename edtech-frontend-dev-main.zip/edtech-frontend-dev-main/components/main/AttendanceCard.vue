<template>
  <div class="main-component">
    <div class="main-component-title">Посещаемость</div>
    <div class="d-flex">
      <div ref="progressWrap" class="progressWrap">
        <svg width="90" height="90" viewBox="0 0 90 90">
          <circle
            cx="45"
            cy="45"
            r="40"
            fill="none"
            stroke="#e6e6e6"
            stroke-width="10"
          />
          <circle
            ref="percentLine"
            class="percent fifty"
            cx="45"
            cy="45"
            r="40"
            fill="none"
            stroke="#003A70"
            stroke-width="10"
            pathLength="100"
          />
          <text
            ref="textPercent"
            x="50%"
            y="50%"
            dominant-baseline="middle"
            text-anchor="middle"
            class="main-component-text font-weight-bold"
          ></text>
        </svg>
      </div>
      <div class="tableWrapper">
        <div
          v-if="attendance.attendanceList.length"
          class="d-flex tableRow-head borderBot"
        >
          <div class="main-component-text-little grayColor customFlex">
            Предмет
          </div>
          <div class="main-component-text-little grayColor customFlex">
            Пропуски
          </div>
        </div>
        <div v-if="!loading && attendance.attendanceList.length">
          <div
            v-for="(item, index) in attendance.attendanceList"
            :key="index"
            class="tableRow-body d-flex borderBot"
          >
            <div
              class="main-component-text blueColor font-weight-bold customFlex"
            >
              {{ item.subject.name }}
            </div>
            <div class="main-component-text blueColor customFlex">
              {{ item.state === 'attended' ? 'Был' : 'Не был' }} -
              {{ item.date }}
            </div>
          </div>
        </div>
        <div v-if="!attendance.attendanceList.length" class="subtitle-text">
          Вам не выставляли посещаемость
        </div>
        <v-skeleton-loader
          v-if="loading"
          class="mx-auto overflow"
          type="table-tbody"
        ></v-skeleton-loader>
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState, mapStores } from 'pinia'
import { useAttendanceStore } from '~/store/attendance'
import { AttendanceFull } from '~/models/attendance.model'

export default {
  name: 'AttendanceCard',

  computed: {
    ...mapStores(useAttendanceStore),
    ...mapState(useAttendanceStore, {
      attendance: (store) => AttendanceFull.serialize(store.attendance),
      loading: (store) => store.loading,
    }),
  },

  watch: {
    attendance() {
      this.fillPercent()
    },
  },

  async mounted() {
    await this.loadAttendance()
  },

  methods: {
    ...mapActions(useAttendanceStore, ['loadAttendance']),

    fillPercent() {
      let percentage = 0
      if (this.attendance.countNum !== 0) {
        percentage = Math.round(
          100 - (this.attendance.countNum / this.attendance.subjectsCount) * 100
        )
        this.$refs.textPercent.textContent = percentage + ' %'
        this.$refs.percentLine.style.setProperty('--percent', percentage)
      } else {
        this.$refs.progressWrap.style.display = 'none'
      }
    },
  },
}
</script>
<style lang="scss">
@import '/assets/main';

:root {
  --percent: 0;
}

.percent {
  stroke-dasharray: 100;
  stroke-dashoffset: calc(100 - var(--percent));
}

.tableWrapper {
  margin: 15px 0 0 15px;
  max-height: 200px;
  overflow: auto;
  padding: 0 5px 0 0;
  width: 100%;
}

.customFlex {
  flex: 1 1 50%;
}

.tableRow-head {
  padding: 0px 0px 15px 5px;
}

.tableRow-body {
  padding: 10px 5px;
}

.borderBot {
  border-bottom: 1px solid #e5eaee;
}

::-webkit-scrollbar {
  width: 3px;
}

::-webkit-scrollbar-track {
  background: #e8e8e8;
  border-radius: 40px;
}

::-webkit-scrollbar-thumb {
  background: #313131;
  border-radius: 40px;
}

.progressWrap {
  display: flex;
  align-items: center;
  height: 24vh;
}
</style>
