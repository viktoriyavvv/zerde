<template>
  <v-simple-table>
    <thead class="text-no-wrap">
      <tr>
        <th
          v-for="(header, i) in headers"
          :key="i"
          class="text-left list-header"
        >
          {{ header }}
        </th>
      </tr>
    </thead>
    <tbody
      v-if="type === 'homework' && displayList"
      class="student-homework list-body"
    >
      <tr
        v-for="homework in list"
        :key="homework.uuid"
        class="student-homework__row"
        @click="selectHW(homework.uuid)"
      >
        <td>
          <div class="list__subject">{{ homework.subject.name }}</div>
          <div>
            {{ homework.teacherName.lastName }}&nbsp;{{
              homework.teacherName.firstName
            }}
          </div>
        </td>
        <td>{{ homework.homeworkType }}</td>
        <td>{{ homework.deadline }}</td>
        <td>{{ homework.state }}</td>
        <td>
          <span v-if="homework.mark[0].markValue !== ''"
            >{{ homework.mark[0].markValue }} /
            {{ homework.mark[0].maxMarkValue }}</span
          >
          <span v-else-if="homework.mark[0].markValue === ''"
            >&nbsp;—&nbsp;</span
          >
          <v-progress-linear
            v-if="homework.mark[0]"
            background-color="#D7F9EF"
            color="#0BB783"
            rounded
            :value="homework.mark[0].markPercentValue"
          ></v-progress-linear>
        </td>
      </tr>
    </tbody>
    <tbody
      v-if="type.includes('homework-teacher') && displayList"
      class="teacher-homework list-body"
    >
      <tr
        v-for="(homework, i) in list"
        :key="homework.uuid"
        class="teacher-homework__row"
        @click="openHw(homework)"
      >
        <td>{{ i + numberModifier + 1 }}</td>
        <td>
          {{ homework.subject }}
        </td>
        <td>{{ homework.grade }}</td>
        <td v-if="homework.gradeGroup">{{ homework.gradeGroup }}</td>
        <td v-else>-</td>
        <td class="list__description">{{ homework.description }}</td>
        <td>{{ homework.deadline }}</td>
        <td>
          <span
            >{{ homework.repliedStudents }} / {{ homework.totalStudents }}</span
          >
          <v-progress-linear
            background-color="#D7F9EF"
            color="#0BB783"
            rounded
            :value="homework.studentStats"
          ></v-progress-linear>
        </td>
      </tr>
    </tbody>

    <tbody
      v-if="type.includes('students') && displayList"
      class="student-list list-body"
    >
      <tr
        v-for="(student, i) in list"
        :key="'student' + i"
        class="student-list__row"
        @click="showProfile(i)"
      >
        <td>{{ i + numberModifier + 1 }}</td>
        <td>
          {{ getFullName(student.userAccount) }}
        </td>
        <td v-if="type !== 'students'">{{ student.dateOfBirth }}</td>
        <td>{{ student.phone }}</td>
        <td v-if="type === 'students'">{{ student.userAccount.email }}</td>
        <td v-if="type === 'students'">
          {{ student.address.fullAddress }}
        </td>
      </tr>
    </tbody>
    <tbody v-if="type === 'teachers'" class="teacher-list list-body">
      <tr
        v-for="(teacher, i) in list"
        :key="'teacher' + i"
        class="teacher-list__row overflow-y-auto"
      >
        <td>{{ i + numberModifier + 1 }}</td>
        <td>{{ getFullName(teacher.userAccount) }}</td>
        <td class="d-flex flex-wrap overflow-y-auto">
          <span
            v-for="(subject, j) in teacher.subjects"
            :key="'teacherSubjects' + j"
            >{{ subject.name
            }}<span
              v-if="
                teacher.subjects.length > 1 && j !== teacher.subjects.length - 1
              "
              >,&nbsp;</span
            ></span
          >
        </td>
      </tr>
    </tbody>
    <tbody v-if="displayLoading || displayMessage" class="text-center">
      <p v-if="displayMessage" class="message__text">
        Результаты, соответствующие параметрам вашего запроса, не найдены
      </p>
      <v-skeleton-loader
        v-else-if="displayLoading || !displayMessage"
        class="mx-auto loader"
        type="table-tbody"
      ></v-skeleton-loader>
    </tbody>
  </v-simple-table>
</template>

<script>
export default {
  name: 'DefaultList',
  props: {
    type: {
      type: String,
      default: '',
    },
    list: {
      type: Array,
      default() {
        return []
      },
    },
    headers: {
      type: Array,
      default() {
        return []
      },
    },
    loading: {
      type: Boolean,
      default: true,
    },
    page: {
      type: Number,
      default: 1,
    },
  },
  data() {
    return {
      dialog: false,
    }
  },
  computed: {
    displayList() {
      return this.list.length > 0 && !this.loading
    },
    displayLoading() {
      return this.loading
    },
    displayMessage() {
      return !this.loading && this.list.length === 0
    },
    numberModifier() {
      return this.page * 20 - 20
    },
  },

  methods: {
    openHw(homework) {
      this.$router.push(`/teacher/Homework/${homework.uuid}`)
    },
    showProfile(studentIndex) {
      this.$emit('showProfile', studentIndex)
    },
    getFullName(user) {
      return `${user.firstName} ${user.lastName}`
    },
    selectHW(hw) {
      this.$emit('selectHW', hw)
    },
  },
}
</script>
