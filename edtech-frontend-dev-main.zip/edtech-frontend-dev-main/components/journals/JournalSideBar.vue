<template>
  <div class="journalSideBar">
    <div class="journalSideBar__container">
      <h3 class="title-component">Действия</h3>
      <form class="main-component-text" @submit.prevent>
        <div class="journalSideBar__mb pt-4">
          <drop-down-element
            type="grade"
            :default="'Выберите класс'"
            :options="grades"
            @input="selectGrade"
          ></drop-down-element>
        </div>
        <div class="journalSideBar__mb">
          <drop-down-element
            :default="'Выберите предмет'"
            :options="subjects"
            @input="selectSubject"
          ></drop-down-element>
        </div>
        <div class="journalSideBar__mb">
          <drop-down-element
            :default="'Выберите четверть'"
            :options="quarterName"
            @input="getTermValue"
          ></drop-down-element>
        </div>
        <button
          :disabled="!checkEmpty"
          type="submit"
          class="journalSideBar__btn journalSideBar__btn_whiteBack mb-15"
          @click="submitSelection"
        >
          Применить
        </button>

        <div class="journalSideBar__mb">
          <button
            v-if="valueTermDropDown.uuid !== 'total'"
            type="button"
            :class="
              isHideMonthsClicked
                ? 'journalSideBar__btn  journalSideBar__btn_blue'
                : 'journalSideBar__btn journalSideBar__btn_whiteBack'
            "
            @click="showSumMarks"
          >
            Только суммативные оценки
          </button>
        </div>
        <div class="d-flex justify-space-between journalSideBar__gap">
          <div class="journalSideBar__btn">
            <button class="journalSideBar__btn journalSideBar__btn_whiteBack">
              <img src="~assets/images/exel-icon.svg" width="24" height="24" />
            </button>
          </div>
          <div class="journalSideBar__btn">
            <button
              class="journalSideBar__btn journalSideBar__btn_whiteBack journalSideBar__img"
            ></button>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import DropDownElement from '@/components/main/DropDownElement'
import { useJournalStore } from '~/store/journal'
import { StudentGrade, Subject } from '@/models'
import { Term } from '@/models/term.model'
import { SchoolYear } from '@/models/journalYear.model'
import { Journal } from '@/models/journal.model'

export default {
  name: 'JournalSideBar',
  components: { DropDownElement },
  props: {
    term: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      quarterName: [],
      valueTermDropDown: [],
      selection: {
        grade: null,
        subjects: null,
        quarters: null,
      },
      gradeName: '',
      isHideMonthsClicked: false,
    }
  },
  computed: {
    ...mapState(useJournalStore, {
      grades: (store) => StudentGrade.serializeList(store.grades),
      subjects: (store) => Subject.serializeList(store.subjects),
      quarters: (store) => Term.serializeList(store.quarters),
      schoolYear: (store) => SchoolYear.serialize(store.schoolYear),
      journal: (store) => Journal.serialize(store.journal),
    }),
    checkEmpty() {
      return (
        !!this.selection.quarters &&
        !!this.selection.subjects &&
        !!this.selection.grade
      )
    },
  },
  async beforeMount() {
    if (this.$nuxt.$auth.user.role === 'teacher') {
      await this.getGrades()
      await this.getSubjects()
      await this.getQuarters().then(() => {
        const temp = [
          ...this.quarters,

          { name: 'Итоговые (за год)', uuid: 'total' },
        ]
        this.quarterName = temp
      })
    } else {
      await this.getSubjectsClassTeacher()
      await this.getGradesClassTeacher()
      await this.getQuarters().then(() => {
        const temp = [
          ...this.quarters,

          { name: 'Итоговые (за год)', uuid: 'total' },
        ]
        this.quarterName = temp
      })
    }
  },
  methods: {
    showSumMarks() {
      this.isHideMonthsClicked = !this.isHideMonthsClicked
      this.$emit('showSumMarks', this.isHideMonthsClicked)
    },
    selectGrade(grade) {
      this.selection.grade = grade.uuid
      this.gradeName = grade.name
    },
    selectSubject(subjects) {
      this.selection.subjects = subjects.uuid
    },
    getTermValue(e) {
      this.valueTermDropDown = e

      this.selection.quarters = e.uuid
    },
    async submitSelection() {
      const quarter = this.valueTermDropDown
      this.$emit('getGradeName', this.gradeName)
      if (
        quarter.name === this.quarterName[0].name ||
        quarter.name === this.quarterName[2].name
      ) {
        await this.loadJournal(
          this.selection.grade,
          this.selection.subjects,
          this.selection.quarters
        )
        if (this.$nuxt.$auth.user.role === 'teacher') {
          await this.getMarkType()
        }

        const journalData = {
          grade: this.selection.grade,
          subjects: this.selection.subjects,
          quarter: this.selection.quarters,
        }
        this.$emit('getJournalData', journalData)
      }
      if (
        quarter.name === this.quarterName[1].name ||
        quarter.name === this.quarterName[3].name
      ) {
        await this.loadJournal(
          this.selection.grade,
          this.selection.subjects,
          this.selection.quarters
        )
        if (this.$nuxt.$auth.user.role === 'teacher') {
          await this.getMarkType()
        }
        const journalData = {
          grade: this.selection.grade,
          subjects: this.selection.subjects,
          quarter: this.selection.quarters,
        }
        this.$emit('getJournalData', journalData)
      }

      if (quarter.name === this.quarterName[4].name) {
        await this.getSchoolYear(this.selection.grade, this.selection.subjects)
        const kek = {
          grade: this.selection.grade,
          subjects: this.selection.subjects,
        }
        this.$emit('getFinals', true, kek)
        this.$emit('getSwitchStateFromSideBar', this.schoolYear.byTerm)
      }

      this.quarterName.forEach((el) => {
        if (el.name === quarter.name) {
          this.$emit('getTermName', quarter)
        }
      })
    },
    ...mapActions(useJournalStore, [
      'getGrades',
      'getSubjects',
      'getQuarters',
      'getSchoolYear',
      'loadJournal',
      'getMarkType',
      'getSubjectsClassTeacher',
      'getGradesClassTeacher',
    ]),
  },
}
</script>
