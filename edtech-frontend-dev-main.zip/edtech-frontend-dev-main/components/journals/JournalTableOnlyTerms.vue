<template>
  <div class="journalTableOnlyTerms__container container">
    <MarkModalSor
      :is-modal-clicked="isModalClicked"
      :modal-options="modalOptions"
      :is-modal-clicked-term="isModalClickedTerm"
      @closeModal="closeModal"
    ></MarkModalSor>
    <div class="d-flex justify-space-between">
      <div class="d-flex journalTableOnlyTerms__title">
        <div class="journalTableOnlyTerms__title_margin">
          Класс: {{ gradeName }}
        </div>
        <div>
          Классный руководитель:
          {{ getClassTeacherName }}
          {{ getClassTeacherLastName }}
        </div>
      </div>
      <div class="d-flex journalTableOnlyTerms__title align-center">
        <NewHalfYearSwitcher
          :by-term="schoolYear.byTerm"
          :grade-finals="gradeFinals"
          :subject-finals="subjectFinals"
          :mark-book-uuid="schoolYear.uuid"
          @getSwitchData="getSwitchData"
          @getSwitchState="getSwitchState"
        ></NewHalfYearSwitcher>
      </div>
    </div>
    <div class="journalTableOnlyTerms__border"></div>
    <div class="d-flex justify-center">
      <div class="journalTableOnlyTerms__table">
        <div class="journalTableOnlyTerms__headers">
          <div class="journalTableOnlyTerms__gridNum">
            <div>№</div>
          </div>
          <div class="journalTableOnlyTerms__gridName">ФИО</div>
          <div class="journalTableOnlyTerms__gridTerm">
            <div class="d-flex journalTableOnlyTerms__gridTerm_h88">
              <div v-for="(quarter, index) in schoolYear.quarters" :key="index">
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_h88"
                >
                  {{ quarter.name }}
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_h88"
                >
                  Реком. оценка
                  <img
                    src="@/assets/images/Group819.svg"
                    title="Рекомендуемая оценка рассчитана на основании утвержденных МОН РК формул. Для выставления оценки учащемуся - введите оценку в столбце 'Выстав. оценка' самостоятельно"
                  />
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_h88"
                >
                  Год
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_h88 journalTableOnlyTerms__gridTerm_examMark"
                >
                  <div class="journalTableOnlyTerms__gridTerm_examWrapper">
                    <p class="journalTableOnlyTerms__gridTerm_w55">
                      Балл за экзамен
                    </p>
                  </div>
                  <div class="journalTableOnlyTerms__gridTerm_maxMark">
                    <div class="d-flex justify-space-between align-center">
                      <div class="journalTableOnlyTerms__gridTerm_maxMarkRed">
                        Макс. балл
                      </div>
                      <div
                        class="d-flex align-center journalTableOnlyTerms__relative"
                      >
                        <input
                          class="journalTableOnlyTerms__gridTerm_maxMarkNumber"
                          :disabled="readonlyForClassteacher"
                          :value="schoolYear.examMark.maxScoreValue"
                          :max="schoolYear.examMark.maxScoreValue"
                          @input="getMaxScoreValue"
                          @change="
                            patchCreateExamMarkMethod(
                              newMaxScoreValue,
                              schoolYear.examMark.uuid,
                              schoolYear.examMark.maxScoreValue,
                              schoolYear.uuid
                            )
                          "
                        />
                        <button
                          v-if="schoolYear.examMark.maxScoreValue > 0"
                          type="button"
                          title="Delete"
                          class="journalTableOnlyTerms__delBtn journalTableOnlyTerms__delBtn_max"
                          @click="
                            deleteExamMarkMethod(schoolYear.examMark.uuid)
                          "
                        >
                          <img
                            src="@/assets/images/delete-stop-svgrepo-com.svg"
                            alt=""
                            height="8"
                            width="8"
                          />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_h88 journalTableOnlyTerms__gridTerm_w109"
                >
                  Оценка за экзамен
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_h88 journalTableOnlyTerms__gridTerm_w107"
                >
                  Итог
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          v-for="(element, studentIndex) in schoolYear.studentMarkBooks"
          :key="'element' + studentIndex"
          class="journalTableOnlyTerms__subheader"
        >
          <div class="journalTableOnlyTerms__subheader_gridNum1">
            <div>{{ studentIndex + 1 }}</div>
          </div>
          <div class="journalTableOnlyTerms__subheader_gridName1">
            {{ element.studentProfile.userAccount.firstName }}
          </div>
          <div class="journalTableOnlyTerms__subheader_gridTerm1">
            <div class="d-flex">
              <div>
                <div class="d-flex">
                  <div
                    v-for="quarterElement in quarters"
                    :key="quarterElement.uuid"
                    class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_itemsHeight"
                  >
                    <div
                      v-if="
                        element.quarterMarks.some(
                          (e) => e.quarter.uuid === quarterElement.uuid
                        )
                      "
                      class="d-flex align-center journalTableOnlyTerms__relative"
                    >
                      <input
                        type="number"
                        class="journalsTable__input"
                        :value="
                          element.quarterMarks.find(
                            (e) => e.quarter.uuid === quarterElement.uuid
                          ).markValue
                        "
                        :max="element.quarterMarks.maxMarkValue"
                        disabled
                      />
                    </div>
                    <div v-else>
                      <input
                        disabled
                        class="journalsTable__input"
                        :max="element.quarterMarks.maxMarkValue"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="journalTableOnlyTerms__subheader_gridTerm2">
            <div class="d-flex">
              <div>
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_itemsHeight"
                >
                  <input
                    type="number"
                    min="1"
                    class="journalsTable__input"
                    :value="element.recommendedYearMark"
                    disabled
                  />
                </div>
              </div>

              <div>
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_itemsHeight"
                >
                  <div
                    class="d-flex align-center journalTableOnlyTerms__relative"
                  >
                    <input
                      :id="element.schoolYearMark.uuid"
                      type="number"
                      min="1"
                      :max="element.schoolYearMark.maxMarkValue"
                      class="journalsTable__input"
                      :disabled="readonlyForClassteacher"
                      :value="element.schoolYearMark.markValue"
                      @input="getYearMarkValue"
                      @change="
                        patchCreateYearMarkMethod(
                          newYearMark,
                          element.schoolYearMark.uuid,
                          element.schoolYearMark.markValue,
                          element.uuid
                        )
                      "
                    />

                    <button
                      v-if="element.schoolYearMark.markValue > 0"
                      type="button"
                      title="Delete"
                      class="journalTableOnlyTerms__delBtn"
                      @click="deleteYearMarkMethod(element.schoolYearMark.uuid)"
                    >
                      <img
                        src="@/assets/images/delete-stop-svgrepo-com.svg"
                        alt=""
                        height="8"
                        width="8"
                      />
                    </button>
                  </div>
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_itemsHeight journalTableOnlyTerms__gridTerm_w108"
                >
                  <div
                    class="d-flex align-center journalTableOnlyTerms__relative"
                  >
                    <input
                      type="number"
                      min="1"
                      class="journalsTable__input"
                      :value="element.studentExamMark.scoreValue"
                      :disabled="readonlyForClassteacher"
                      @input="getScoreValue"
                      @change="
                        patchCreateStudentExamMarkMethod(
                          schoolYear.examMark.uuid,
                          element.uuid,
                          element.studentExamMark.markValue
                            ? element.studentExamMark.markValue
                            : 0,
                          newScoreValue,
                          '',
                          element.studentExamMark.uuid,
                          element.studentExamMark.scoreValue
                        )
                      "
                    />
                    <button
                      v-if="element.studentExamMark.scoreValue > 0"
                      type="button"
                      title="Delete"
                      class="journalTableOnlyTerms__delBtn"
                      @click="
                        deleteStudentExamMarkMethod(
                          element.studentExamMark.uuid
                        )
                      "
                    >
                      <img
                        src="@/assets/images/delete-stop-svgrepo-com.svg"
                        alt=""
                        height="8"
                        width="8"
                      />
                    </button>
                  </div>
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_itemsHeight journalTableOnlyTerms__gridTerm_w109"
                >
                  <div
                    class="d-flex align-center journalTableOnlyTerms__relative"
                  >
                    <input
                      type="number"
                      min="1"
                      class="journalsTable__input"
                      :disabled="readonlyForClassteacher"
                      :value="element.studentExamMark.markValue"
                      @input="getMarkValue"
                      @change="
                        patchCreateStudentExamMarkMethod(
                          schoolYear.examMark.uuid,
                          element.uuid,
                          newMarkValue,
                          element.studentExamMark.scoreValue
                            ? element.studentExamMark.scoreValue
                            : 0,
                          '',
                          element.studentExamMark.uuid,
                          element.studentExamMark.markValue
                        )
                      "
                    />
                    <button
                      v-if="element.studentExamMark.markValue > 0"
                      type="button"
                      title="Delete"
                      class="journalTableOnlyTerms__delBtn"
                      @click="
                        deleteStudentExamMarkMethod(
                          element.studentExamMark.uuid
                        )
                      "
                    >
                      <img
                        src="@/assets/images/delete-stop-svgrepo-com.svg"
                        alt=""
                        height="8"
                        width="8"
                      />
                    </button>
                  </div>
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyTerms__gridTerm_items journalTableOnlyTerms__gridTerm_itemsHeight journalTableOnlyTerms__gridTerm_w107"
                >
                  <div
                    class="d-flex align-center journalTableOnlyTerms__relative"
                  >
                    <input
                      type="number"
                      min="1"
                      :disabled="readonlyForClassteacher"
                      :max="element.finalMarkStudent.maxMarkValue"
                      class="journalsTable__input"
                      :value="element.finalMarkStudent.markValue"
                      @input="getFinalMarkValue"
                      @change="
                        patchCreateFinalMarks(
                          element.uuid,
                          newFinalMarkValue,
                          element.finalMarkStudent.uuid,
                          element.finalMarkStudent.markValue
                        )
                      "
                    />
                    <button
                      v-if="element.finalMarkStudent.markValue > 0"
                      type="button"
                      title="Delete"
                      class="journalTableOnlyTerms__delBtn"
                      @click="
                        deleteFinalMarksMethod(element.finalMarkStudent.uuid)
                      "
                    >
                      <img
                        src="@/assets/images/delete-stop-svgrepo-com.svg"
                        alt=""
                        height="8"
                        width="8"
                      />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import { useJournalStore } from '~/store/journal'
import NewHalfYearSwitcher from '@/components/journals/NewHalfYearSwitcher'
import { SchoolYear } from '@/models/journalYear.model'
import { Term } from '@/models/term.model'
import MarkModalSor from '@/components/journals/MarkModalSor'

export default {
  name: 'JournalTableOnlyTerms',
  components: { NewHalfYearSwitcher, MarkModalSor },
  props: {
    gradeName: {
      type: String,
      default: '',
    },
    gradeFinals: {
      type: String,
      default: '',
    },
    subjectFinals: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      currentQuarterUuid: '',
      newQuarterMark: '',
      newYearMark: '',
      newScoreValue: '',
      newMaxScoreValue: '',
      newFinalMarkValue: '',
      newMarkValue: '',
      targetId: '',
      isModalClicked: false,
      isModalClickedTerm: false,
      modalOptions: [
        'Невозможно изменить вид оценивания журнала так как уже создан СОч или более 2-х СОр.',
      ],
    }
  },

  computed: {
    ...mapState(useJournalStore, {
      schoolYear: (store) => SchoolYear.serialize(store.schoolYear),
      schoolYearGetter: (store) => store.schoolYearGetter,
      quarters: (store) => Term.serializeList(store.quarters),
    }),
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
    getClassTeacherName() {
      return this.schoolYear.grade.classTeacherProfile.userAccount.firstName
    },
    getClassTeacherLastName() {
      return this.schoolYear.grade.classTeacherProfile.userAccount.lastName
    },
  },
  methods: {
    getYearMarkValue(event) {
      this.newYearMark = Number(event.target.value)
    },
    getScoreValue(event) {
      this.newScoreValue = Number(event.target.value)
    },
    getMaxScoreValue(event) {
      this.newMaxScoreValue = Number(event.target.value)
    },
    getFinalMarkValue(event) {
      this.newFinalMarkValue = Number(event.target.value)
    },
    getMarkValue(event) {
      this.newMarkValue = Number(event.target.value)
    },
    async deleteYearMarkMethod(yearMarkUuid) {
      await this.deleteYearMark(yearMarkUuid)
      await useJournalStore().getSchoolYear(
        this.gradeFinals,
        this.subjectFinals
      )
    },
    async patchCreateYearMarkMethod(
      newMarkValue,
      uuid,
      oldMarkValue,
      markBook
    ) {
      if (
        (oldMarkValue === null ||
          oldMarkValue === '' ||
          oldMarkValue === 0 ||
          oldMarkValue === undefined) &&
        (uuid === null || uuid === '' || uuid === 0 || uuid === undefined)
      ) {
        await this.createYearMark(markBook, newMarkValue)
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      } else {
        await this.patchYearMark(newMarkValue, uuid)
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      }
    },
    async deleteExamMarkMethod(examMarkUuid) {
      await this.deleteExamMarks(examMarkUuid)
      await useJournalStore().getSchoolYear(
        this.gradeFinals,
        this.subjectFinals
      )
    },
    async patchCreateExamMarkMethod(
      maxScoreValue,
      uuid,
      oldMaxScoreValue,
      gradeBook
    ) {
      if (
        (oldMaxScoreValue === null ||
          oldMaxScoreValue === '' ||
          oldMaxScoreValue === 0 ||
          oldMaxScoreValue === undefined) &&
        (uuid === null || uuid === '' || uuid === 0 || uuid === undefined)
      ) {
        await this.createExamMarks(maxScoreValue, gradeBook)
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      } else {
        await this.patchExamMarks(maxScoreValue, uuid)
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      }
    },
    async deleteStudentExamMarkMethod(uuid) {
      await this.deleteStudentExamMark(uuid)
      useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
    },
    async patchCreateStudentExamMarkMethod(
      examMark,
      studentMarkBook,
      markValue,
      scoreValue,
      comment,
      patchId,
      oldScoreValue
    ) {
      if (
        (oldScoreValue === null ||
          oldScoreValue === '' ||
          oldScoreValue === 0 ||
          oldScoreValue === undefined) &&
        (patchId === null ||
          patchId === '' ||
          patchId === 0 ||
          patchId === undefined)
      ) {
        await this.createStudentExamMarkScore(
          examMark,
          studentMarkBook,
          markValue,
          scoreValue,
          comment
        )
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      } else {
        await this.patchStudentExamMarkScore(
          scoreValue,
          markValue,
          comment,
          patchId
        )
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      }
    },
    async deleteFinalMarksMethod(uuid) {
      await this.deleteFinalMarks(uuid)
      useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
    },
    async patchCreateFinalMarks(
      studentMarkBook,
      markValue,
      uuid,
      oldMarkValue
    ) {
      if (
        (oldMarkValue === null ||
          oldMarkValue === '' ||
          oldMarkValue === 0 ||
          oldMarkValue === undefined) &&
        (uuid === null || uuid === '' || uuid === 0 || uuid === undefined)
      ) {
        await this.createFinalMarks(studentMarkBook, markValue)
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      } else {
        await this.patchFinalMarks(markValue, uuid)
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      }
    },
    getSwitchData() {
      this.isModalClickedTerm = true
      this.isModalClicked = true
    },
    getSwitchState(switcherState) {
      this.$emit('getSwitchState', switcherState)
    },
    closeModal() {
      this.isModalClicked = false
    },
    ...mapActions(useJournalStore, [
      'createQuarterMark',
      'deleteQuarterMark',
      'patchQuarterMark',
      'createYearMark',
      'patchYearMark',
      'deleteYearMark',
      'createStudentExamMarkScore',
      'createExamMarks',
      'patchExamMarks',
      'deleteExamMarks',
      'createFinalMarks',
      'patchFinalMarks',
      'deleteFinalMarks',
      'patchStudentExamMarkScore',
      'deleteStudentExamMark',
      'getSchoolYear',
      'setSchoolYear',
      'patchMarkGradeBooks',
    ]),
  },
}
</script>
