<template>
  <div class="journalsTable__container container" style="height: 92vh">
    <div class="d-flex justify-space-between">
      <div class="d-flex journalsTable__title">
        <div class="journalsTable__title_margin mb-3">Не выбран журнал</div>
      </div>
      <div class="d-flex journalsTable__title"></div>
    </div>
    <div class="journalsTable__border"></div>
    <div class="journalsTable__table">
      <div class="journalsTable__headers">
        <div class="journalsTable__gridNum">
          <div>№</div>
        </div>
        <div class="journalsTable__gridName">ФИО</div>
        <div class="journalsTable__gridMonthes"></div>
        <div class="journalsTable__gridTerm">
          <div class="journalsTable__gridTerm_name">-</div>
          <div class="d-flex">
            <div class="d-flex">
              <div></div>
            </div>
            <div>
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_w66 journalsTable__gridTerm_h69"
              >
                %(CОр + ФО)
              </div>
            </div>
            <div>
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_w47 journalsTable__gridTerm_h69"
              >
                %<br />CОч
              </div>
            </div>

            <div>
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_w63 journalsTable__gridTerm_h69"
              >
                Сумма %
              </div>
            </div>
            <div>
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_w126 journalsTable__gridTerm_h69"
              >
                Рекомендуемая оценка
              </div>
            </div>
            <div>
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_w70 journalsTable__gridTerm_h69"
              >
                Оценка
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="journalsTable__subheader">
        <div class="journalsTable__subheader_gridNum1">
          <div>-</div>
        </div>
        <div class="journalsTable__subheader_gridName1">-</div>
        <div class="journalsTable__subheader_gridTerm1">
          <div class="d-flex">
            <div>
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_itemsHeight journalsTable__gridTerm_w66"
              >
                <input class="journalsTable__input" disabled value="-" />
              </div>
            </div>
            <div>
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_itemsHeight journalsTable__gridTerm_w47"
              >
                <input class="journalsTable__input" disabled value="-" />
              </div>
            </div>

            <div>
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_itemsHeight journalsTable__gridTerm_w63"
              >
                <input
                  min="1"
                  class="journalsTable__input"
                  disabled
                  value="-"
                />
              </div>
            </div>
            <div>
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_itemsHeight journalsTable__gridTerm_w126"
              >
                <input
                  min="1"
                  class="journalsTable__input"
                  disabled
                  value="-"
                />
              </div>
            </div>
            <div>
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_itemsHeight journalsTable__gridTerm_w70"
              >
                <div
                  class="d-flex align-center journalTableOnlyTerms__relative"
                >
                  <input
                    min="1"
                    disabled
                    class="journalsTable__input"
                    value="-"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'JournalTableEmpty',
}
</script>
