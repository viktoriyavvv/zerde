<template>
  <div :class="readonlyForClassteacher ? 'marksDropdown__btn_disabled' : ''">
    <div
      :class="
        isOpen
          ? 'marksDropdown__background_changed'
          : 'marksDropdown__background'
      "
      tabindex="0"
      @blur="isOpen = false"
    >
      <div
        :class="
          readonlyForClassteacher
            ? 'd-flex justify-space-between marksDropdown__btn marksDropdown__btn_disabled'
            : 'd-flex justify-space-between marksDropdown__btn'
        "
        @click="isOpen = !isOpen"
      >
        <div>{{ currentMarkType.shortTitle }}</div>
        <div v-if="isOpen">
          <img src="@/assets/images/Arrow-Right4.svg" />
        </div>
        <div v-else>
          <img src="@/assets/images/Arrow-Right3.svg" />
        </div>
      </div>
      <div v-if="isOpen" class="marksDropdown__open">
        <div
          v-for="(item, index) in list"
          :key="index"
          class="marksDropdown__div"
          @click="chooseMark(item.shortTitle, item.uuid)"
        >
          <div class="marksDropdown__div">
            {{ item.shortTitle }} - {{ item.title }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MarksDropdown',
  props: {
    list: {
      type: Array,
      default() {
        return []
      },
    },
    currentMarkType: {
      type: Object,
      default() {
        return {}
      },
    },
    dateUuid: {
      type: String,
      default: '',
    },
    default: {
      type: String,
      required: false,
      default: '',
    },
  },
  data() {
    return {
      isOpen: false,
    }
  },
  computed: {
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
  },
  methods: {
    async chooseMark(element, markTypeUuid) {
      await this.patchMarkType(markTypeUuid, this.dateUuid).then(() => {
        this.$emit('updateMarkTypes')
      })
      this.isOpen = false
    },
  },
}
</script>

<style lang="scss"></style>
