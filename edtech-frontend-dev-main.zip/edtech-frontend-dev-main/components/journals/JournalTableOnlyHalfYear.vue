<template>
  <div
    class="journalTableOnlyHalfYear__container container"
    style="height: 92vh"
  >
    <MarkModalSor
      :is-modal-clicked="isModalClicked"
      :modal-options="modalOptions"
      :is-modal-clicked-term="isModalClickedTerm"
      @closeModal="closeModal"
    ></MarkModalSor>
    <div class="d-flex justify-space-between">
      <div class="d-flex journalTableOnlyHalfYear__title">
        <div class="journalTableOnlyHalfYear__title_margin">
          Класс: {{ gradeName }}
        </div>
        <div>
          Классный руководитель:
          {{ getClassTeacherName }}
          {{ getClassTeacherLastName }}
        </div>
      </div>
      <div class="d-flex journalTableOnlyHalfYear__title">
        <NewHalfYearSwitcher
          :by-term="schoolYear.byTerm"
          :grade-finals="gradeFinals"
          :subject-finals="subjectFinals"
          :mark-book-uuid="schoolYear.uuid"
          @getSwitchData="getSwitchData"
          @getSwitchState="getSwitchState"
        ></NewHalfYearSwitcher>
      </div>
    </div>
    <div class="journalTableOnlyHalfYear__border"></div>
    <div class="d-flex justify-center">
      <div class="journalTableOnlyHalfYear__table">
        <div class="journalTableOnlyHalfYear__headers">
          <div class="journalTableOnlyHalfYear__gridNum">
            <div>№</div>
          </div>
          <div class="journalTableOnlyHalfYear__gridName">ФИО</div>
          <div class="journalTableOnlyHalfYear__gridTerm">
            <div class="d-flex journalTableOnlyHalfYear__gridTerm_h65">
              <div>
                <div
                  class="journalTableOnlyHalfYear__gridTerm_items journalTableOnlyHalfYear__gridTerm_h65"
                >
                  1-е полугодие
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyHalfYear__gridTerm_items journalTableOnlyHalfYear__gridTerm_65"
                >
                  2-е полугодие
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyHalfYear__gridTerm_items journalTableOnlyHalfYear__gridTerm_65"
                >
                  Год
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          v-for="(element, studentIndex) in schoolYear.studentMarkBooks"
          :key="studentIndex"
          class="journalTableOnlyHalfYear__subheader"
        >
          <div class="journalTableOnlyHalfYear__subheader_gridNum1">
            <div>{{ studentIndex + 1 }}</div>
          </div>
          <div class="journalTableOnlyHalfYear__subheader_gridName1">
            {{ element.studentProfile.userAccount.firstName }}
          </div>
          <div class="journalTableOnlyHalfYear__subheader_gridTerm1">
            <div class="d-flex">
              <div>
                <div
                  class="journalTableOnlyHalfYear__gridTerm_items journalTableOnlyHalfYear__gridTerm_itemsHeight"
                >
                  <div
                    v-if="
                      element.quarterMarks.some(
                        (e) => e.quarter.uuid === quarters[1].uuid
                      )
                    "
                    class="d-flex align-center journalTableOnlyTerms__relative"
                  >
                    <input
                      type="number"
                      class="journalsTable__input"
                      :disabled="readonlyForClassteacher"
                      :value="
                        element.quarterMarks.find(
                          (e) => e.quarter.uuid === quarters[1].uuid
                        ).markValue
                      "
                      :max="element.quarterMarks.maxMarkValue"
                    />
                    <button
                      v-if="
                        element.quarterMarks.find(
                          (e) => e.quarter.uuid === quarters[1].uuid
                        ).markValue > 0
                      "
                      type="button"
                      title="Delete"
                      class="journalTableOnlyTerms__delBtn"
                      @click="
                        deleteQuarterMarkMethod(
                          element.quarterMarks.find(
                            (e) => e.quarter.uuid === quarters[1].uuid
                          ).uuid
                        )
                      "
                    >
                      <img
                        src="@/assets/images/delete-stop-svgrepo-com.svg"
                        alt=""
                        height="8"
                        width="8"
                      />
                    </button>
                  </div>
                  <div v-else>
                    <input
                      type="number"
                      class="journalsTable__input"
                      :disabled="readonlyForClassteacher"
                      @input="getQuarterMarkValue"
                      @change="
                        createHalfYearMethod(
                          element.uuid,
                          newQuarterMark,
                          quarters[1].uuid
                        )
                      "
                    />
                  </div>
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyHalfYear__gridTerm_items journalTableOnlyHalfYear__gridTerm_itemsHeight"
                >
                  <div
                    v-if="
                      element.quarterMarks.some(
                        (e) => e.quarter.uuid === quarters[3].uuid
                      )
                    "
                    class="d-flex align-center journalTableOnlyTerms__relative"
                  >
                    <input
                      type="number"
                      class="journalsTable__input"
                      :disabled="readonlyForClassteacher"
                      :value="
                        element.quarterMarks.find(
                          (e) => e.quarter.uuid === quarters[3].uuid
                        ).markValue
                      "
                      :max="element.quarterMarks.maxMarkValue"
                      @change="
                        patchCreateQuarterMarkMethod(
                          element.uuid,
                          newQuarterMark,
                          quarterJournal,
                          element.quarterMarks.find(
                            (e) => e.quarter.uuid === quarters[3].uuid
                          ).uuid,
                          element.quarterMarks.find(
                            (e) => e.quarter.uuid === quarters[3].uuid
                          ).markValue
                        )
                      "
                      @input="getQuarterMarkValue"
                    />
                    <button
                      v-if="
                        element.quarterMarks.find(
                          (e) => e.quarter.uuid === quarters[3].uuid
                        ).markValue > 0
                      "
                      type="button"
                      title="Delete"
                      class="journalTableOnlyTerms__delBtn"
                      @click="
                        deleteQuarterMarkMethod(
                          element.quarterMarks.find(
                            (e) => e.quarter.uuid === quarters[3].uuid
                          ).uuid
                        )
                      "
                    >
                      <img
                        src="@/assets/images/delete-stop-svgrepo-com.svg"
                        alt=""
                        height="8"
                        width="8"
                      />
                    </button>
                  </div>
                  <div v-else>
                    <input
                      type="number"
                      class="journalsTable__input"
                      :disabled="readonlyForClassteacher"
                      @input="getQuarterMarkValue"
                      @change="
                        createHalfYearMethod(
                          element.uuid,
                          newQuarterMark,
                          quarters[3].uuid
                        )
                      "
                    />
                  </div>
                </div>
              </div>
              <div>
                <div
                  class="journalTableOnlyHalfYear__gridTerm_items journalTableOnlyHalfYear__gridTerm_itemsHeight"
                >
                  <div
                    class="d-flex align-center journalTableOnlyTerms__relative"
                  >
                    <input
                      :id="element.schoolYearMark.uuid"
                      class="journalsTable__input"
                      type="number"
                      min="1"
                      :disabled="readonlyForClassteacher"
                      :max="element.schoolYearMark.maxMarkValue"
                      :value="element.schoolYearMark.markValue"
                      @input="getYearMarkValue"
                      @change="
                        patchCreateYearMarkMethod(
                          newYearMark,
                          element.schoolYearMark.uuid,
                          element.schoolYearMark.markValue,
                          element.uuid
                        )
                      "
                    />
                    <button
                      v-if="element.schoolYearMark.markValue > 0"
                      type="button"
                      title="Delete"
                      class="journalTableOnlyTerms__delBtn"
                      @click="deleteYearMarkMethod(element.schoolYearMark.uuid)"
                    >
                      <img
                        src="@/assets/images/delete-stop-svgrepo-com.svg"
                        alt=""
                        height="8"
                        width="8"
                      />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import { useJournalStore } from '~/store/journal'
import NewHalfYearSwitcher from '@/components/journals/NewHalfYearSwitcher'
import { SchoolYear } from '@/models/journalYear.model'
import { Term } from '@/models/term.model'

export default {
  name: 'JournalTableOnlyHalfYear',
  components: { NewHalfYearSwitcher },
  props: {
    gradeFinals: {
      type: String,
      default: '',
    },
    subjectFinals: {
      type: String,
      default: '',
    },
    gradeName: {
      type: String,
      default: '',
    },
    quarterJournal: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      newYearMark: '',
      newQuarterMark: '',
      isModalClicked: false,
      isModalClickedTerm: false,
      modalOptions: [
        'Невозможно изменить вид оценивания журнала так как уже создан СОч или более 2-х СОр.',
      ],
    }
  },
  computed: {
    ...mapState(useJournalStore, {
      schoolYear: (store) => SchoolYear.serialize(store.schoolYear),
      schoolYearGetter: (store) => store.schoolYearGetter,
      quarters: (store) => Term.serializeList(store.quarters),
    }),
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
    getClassTeacherName() {
      return this.schoolYear.grade.classTeacherProfile.userAccount.firstName
    },
    getClassTeacherLastName() {
      return this.schoolYear.grade.classTeacherProfile.userAccount.lastName
    },
  },
  methods: {
    getYearMarkValue(event) {
      this.newYearMark = Number(event.target.value)
    },
    closeModal() {
      this.isModalClicked = false
    },
    getQuarterMarkValue(event) {
      this.newQuarterMark = Number(event.target.value)
    },
    async deleteYearMarkMethod(yearMarkUuid) {
      await this.deleteYearMark(yearMarkUuid)
      await useJournalStore().getSchoolYear(
        this.gradeFinals,
        this.subjectFinals
      )
    },
    async patchCreateYearMarkMethod(
      newMarkValue,
      uuid,
      oldMarkValue,
      markBook
    ) {
      if (
        (oldMarkValue === null ||
          oldMarkValue === '' ||
          oldMarkValue === 0 ||
          oldMarkValue === undefined) &&
        (uuid === null || uuid === '' || uuid === 0 || uuid === undefined)
      ) {
        await this.createYearMark(markBook, newMarkValue)
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      } else {
        await this.patchYearMark(newMarkValue, uuid)
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      }
    },
    async patchCreateQuarterMarkMethod(
      studentMarkBook,
      markValue,
      quarter,
      uuid,
      oldMarkValue
    ) {
      if (
        (oldMarkValue === null ||
          oldMarkValue === '' ||
          oldMarkValue === 0 ||
          oldMarkValue === undefined) &&
        (uuid === null || uuid === '' || uuid === 0 || uuid === undefined)
      ) {
        await this.createQuarterMark(studentMarkBook, markValue, quarter)
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      } else {
        await this.patchQuarterMark(markValue, uuid)
        useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      }
    },
    async deleteQuarterMarkMethod(uuid) {
      await this.deleteQuarterMark(uuid)
      useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
    },
    async createHalfYearMethod(studentMarkBook, markValue, quarter) {
      await this.createQuarterMark(studentMarkBook, markValue, quarter)
      useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
    },
    getSwitchData() {
      this.isModalClickedTerm = true
      this.isModalClicked = true
    },
    getSwitchState(switcherState) {
      this.$emit('getSwitchState', switcherState)
    },
    ...mapActions(useJournalStore, [
      'createQuarterMark',
      'deleteQuarterMark',
      'patchQuarterMark',
      'createYearMark',
      'patchYearMark',
      'deleteYearMark',
      'createStudentExamMarkScore',
      'createExamMarks',
      'patchExamMarks',
      'deleteExamMarks',
      'createFinalMarks',
      'patchFinalMarks',
      'deleteFinalMarks',
      'patchStudentExamMarkScore',
      'deleteStudentExamMark',
      'getSchoolYear',
      'setSchoolYear',
    ]),
  },
}
</script>
