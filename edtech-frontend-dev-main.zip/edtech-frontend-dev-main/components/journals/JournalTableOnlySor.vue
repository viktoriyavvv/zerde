<template>
  <div class="journalTableOnlySor__container container" style="height: 92vh">
    <MarkModalSor
      :is-modal-clicked="isModalClicked"
      :modal-options="modalOptions"
      :is-modal-clicked-term="isModalClickedTerm"
      @closeModal="closeModal"
    ></MarkModalSor>
    <div class="d-flex justify-space-between">
      <div class="d-flex journalTableOnlySor__title">
        <div class="journalTableOnlySor__title_margin">
          Класс: {{ journal.grade.name }}
        </div>
        <div>
          Классный руководитель:
          {{ getClassTeacherName }}
          {{ getClassTeacherLastName }}
        </div>
      </div>
      <div class="d-flex journalTableOnlySor__title">
        <HalfYearSwitcher
          :by-term="journal.byTerm"
          :grade-journal="gradeJournal"
          :subject-journal="subjectJournal"
          :quarter-journal="quarterJournal"
          @getSwitchData="getSwitchData"
          @getSwitchState="getSwitchState"
        >
        </HalfYearSwitcher>
        <div class="journalsTable__dropDownWidth">
          <DropDownElementSorSoch
            v-if="!readonlyForClassteacher"
            :options="
              (journal.byTerm && term.name === 'I четверть') ||
              (journal.byTerm && term.name === 'III четверть')
                ? [options[0]]
                : options
            "
            :default="'Добавить CОр/Соч'"
            @input="getDropdownValue"
          ></DropDownElementSorSoch>
        </div>
      </div>
    </div>
    <div class="journalTableOnlySor__border"></div>
    <div class="journalTableOnlySor__table">
      <div class="journalTableOnlySor__headers">
        <div class="journalTableOnlySor__gridNum">
          <div>№</div>
        </div>
        <div class="journalTableOnlySor__gridName">ФИО</div>
        <div class="journalTableOnlySor__gridTerm">
          <div class="journalTableOnlySor__gridTerm_name">{{ term.name }}</div>
          <div class="d-flex">
            <div class="d-flex">
              <div v-for="(sorMark, index) in journal.quizMarks" :key="index">
                <MarkAddSor
                  class="journalsTable__markAddSor"
                  :prop-max-mark-value="sorMark.maxMarkValue"
                  :prop-quiz-mark-type="sorMark.quizMarkType"
                  :prop-quiz-mark-uuid="sorMark.uuid"
                  @editSorMark="editSorMark"
                  @deleteSorMark="deleteSorMark"
                ></MarkAddSor>
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalTableOnlySor__gridTerm_items journalTableOnlySor__gridTerm_h69 journalTableOnlySor__gridTerm_sorFo"
              >
                %(CОр + ФО)
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalTableOnlySor__gridTerm_items journalTableOnlySor__gridTerm_h69 journalTableOnlySor__gridTerm_w111"
              >
                %<br />CОч
              </div>
            </div>

            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalTableOnlySor__gridTerm_items journalTableOnlySor__gridTerm_h69 journalTableOnlySor__gridTerm_w127"
              >
                Сумма %
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalTableOnlySor__gridTerm_items journalTableOnlySor__gridTerm_h69 journalTableOnlySor__gridTerm_w226"
              >
                Рекомендуемая оценка
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalTableOnlySor__gridTerm_items journalTableOnlySor__gridTerm_h69 journalTableOnlySor__gridTerm_w120"
              >
                Оценка
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        v-for="(element, studentIndex) in journal.studentMarkBooks"
        :key="studentIndex"
        class="journalTableOnlySor__subheader"
      >
        <div class="journalTableOnlySor__subheader_gridNum1">
          <div>{{ studentIndex + 1 }}</div>
        </div>
        <div class="journalTableOnlySor__subheader_gridName1">
          {{ element.studentProfile.userAccount.firstName }}
        </div>
        <div class="journalTableOnlySor__subheader_gridTerm1">
          <div class="d-flex">
            <div v-for="(item, index) in journal.quizMarks" :key="index">
              <div
                v-if="
                  element.quizMarkStudents.some(
                    (e) => e.quizMark.uuid === item.uuid
                  )
                "
              >
                <MarkAddSorStudent
                  class="journalsTable__markAddSor"
                  :mark-book="element.uuid"
                  :quiz-mark-shower="
                    element.quizMarkStudents.find(
                      (e) => e.quizMark.uuid === item.uuid
                    ).markValue
                  "
                  :quiz-mark-uuid="item.uuid"
                  :quiz-max-mark="item.maxMarkValue"
                  :quiz-mark-student-uuid="
                    element.quizMarkStudents.find(
                      (e) => e.quizMark.uuid === item.uuid
                    ).uuid
                  "
                  @patchSorForStudent="patchSorForStudent"
                  @deleteStudentQuizMarkMethod="deleteStudentQuizMarkMethod"
                ></MarkAddSorStudent>
              </div>

              <div v-else>
                <MarkAddSorStudent
                  class="journalsTable__markAddSor"
                  :mark-book="element.uuid"
                  :quiz-mark-shower="null"
                  :quiz-max-mark="item.maxMarkValue"
                  :quiz-mark-uuid="item.uuid"
                  @createSorForStudent="createSorForStudent"
                ></MarkAddSorStudent>
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalTableOnlySor__gridTerm_items journalTableOnlySor__gridTerm_itemsHeight journalTableOnlySor__gridTerm_w156px"
              >
                <input
                  class="journalsTable__input"
                  disabled
                  :value="element.marksAndQuizMarksPercentage + '%'"
                />
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalTableOnlySor__gridTerm_items journalTableOnlySor__gridTerm_itemsHeight journalTableOnlySor__gridTerm_w111"
              >
                <input
                  class="journalsTable__input"
                  disabled
                  :value="element.examineMarksPercentage + '%'"
                />
              </div>
            </div>

            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalTableOnlySor__gridTerm_items journalTableOnlySor__gridTerm_itemsHeight journalTableOnlySor__gridTerm_w127"
              >
                <input
                  class="journalsTable__input"
                  disabled
                  :value="element.allMarksPercentage + '%'"
                />
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalTableOnlySor__gridTerm_items journalTableOnlySor__gridTerm_itemsHeight journalTableOnlySor__gridTerm_w226"
              >
                <input
                  class="journalsTable__input"
                  disabled
                  :value="element.recommendedMark"
                />
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalTableOnlySor__gridTerm_items journalTableOnlySor__gridTerm_itemsHeight journalTableOnlySor__gridTerm_w120"
              >
                <div
                  class="d-flex align-center journalTableOnlyTerms__relative"
                >
                  <input
                    :disabled="readonlyForClassteacher"
                    type="number"
                    min="1"
                    class="journalsTable__input"
                    :max="element.quarterMark.value"
                    :value="element.quarterMark.markValue"
                    @change="
                      patchCreateQuarterMarkMethod(
                        element.uuid,
                        newQuarterMark,
                        quarterJournal,
                        element.quarterMark.uuid,
                        element.quarterMark.markValue
                      )
                    "
                    @input="getQuarterMarkValue"
                  />
                  <button
                    v-if="
                      element.quarterMark.markValue > 0 &&
                      !readonlyForClassteacher
                    "
                    type="button"
                    title="Delete"
                    class="journalTableOnlyTerms__delBtn"
                    @click="deleteQuarterMarkMethod(element.quarterMark.uuid)"
                  >
                    <img
                      src="@/assets/images/delete-stop-svgrepo-com.svg"
                      alt=""
                      height="8"
                      width="8"
                    />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import { useJournalStore } from '~/store/journal'
import { Journal } from '@/models/journal.model'
import MarkAddSor from '@/components/journals/MarkAddSor'
import MarkAddSorStudent from '@/components/journals/MarkAddSorStudent'
import MarkModalSor from '@/components/journals/MarkModalSor'
import HalfYearSwitcher from '@/components/journals/HalfYearSwitcher'
import DropDownElementSorSoch from '@/components/journals/DropDownElementSorSoch'

export default {
  name: 'JournalTableOnlySor',
  components: {
    HalfYearSwitcher,
    MarkModalSor,
    MarkAddSorStudent,
    MarkAddSor,
    DropDownElementSorSoch,
  },
  props: {
    term: {
      type: Object,
      default() {
        return {}
      },
    },
    gradeJournal: {
      type: String,
      default: '',
    },
    quarterJournal: {
      type: String,
      default: '',
    },
    subjectJournal: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      inputValue: '',
      newQuarterMark: '',
      isModalClickedTerm: false,
      modalOptions: [
        'Невозможно изменить вид оценивания журнала так как уже создан СОч или более 2-х СОр.',
      ],
      isModalClicked: false,
      options: ['Добавить СОр', 'Добавить СОч'],
    }
  },
  computed: {
    ...mapState(useJournalStore, {
      journal: (store) => Journal.serialize(store.journal),
      journalGetter: (store) => store.journalGetter,
    }),
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
    getClassTeacherName() {
      return this.journal.grade.classTeacherProfile.userAccount.firstName
    },
    getClassTeacherLastName() {
      return this.journal.grade.classTeacherProfile.userAccount.lastName
    },
  },
  methods: {
    getQuarterMarkValue(event) {
      this.newQuarterMark = Number(event.target.value)
    },
    closeModal() {
      this.isModalClicked = false
    },
    async addSor() {
      await this.createQuizMarks(
        this.journal.uuid,
        'quiz',
        this.quarterJournal,
        0
      ).catch(() => (this.isModalClicked = true))
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async addSoch() {
      await this.createQuizMarks(
        this.journal.uuid,
        'examine',
        this.quarterJournal,
        0
      ).catch(() => (this.isModalClicked = true))

      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async editSorMark({ data }) {
      await this.patchQuizMarks(data.maxMarkValue, data.propQuizMarkUuid)
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async deleteSorMark(uuid) {
      await this.deleteQuizMarks(uuid)
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async patchCreateQuarterMarkMethod(
      studentMarkBook,
      markValue,
      quarter,
      uuid,
      oldMarkValue
    ) {
      if (
        (oldMarkValue === null ||
          oldMarkValue === '' ||
          oldMarkValue === 0 ||
          oldMarkValue === undefined) &&
        (uuid === null || uuid === '' || uuid === 0 || uuid === undefined)
      ) {
        await this.createQuarterMark(studentMarkBook, markValue, quarter)
        useJournalStore().loadJournal(
          this.gradeJournal,
          this.subjectJournal,
          this.quarterJournal
        )
      } else {
        await this.patchQuarterMark(markValue, uuid)
        useJournalStore().loadJournal(
          this.gradeJournal,
          this.subjectJournal,
          this.quarterJournal
        )
      }
    },
    async deleteQuarterMarkMethod(uuid) {
      await this.deleteQuarterMark(uuid)
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    getDropdownValue(e) {
      this.inputValue = e
      if (e === this.options[0]) {
        this.addSor()
      } else if (e === this.options[1]) {
        this.addSoch()
      }
    },
    async createSorForStudent({ data }) {
      await this.createStudentQuizMarks(
        data.markBook,
        data.mark,
        data.quizMark,
        data.comment
      )
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async patchSorForStudent({ anotherData }) {
      await this.patchStudentQuizMarks(
        anotherData.mark,
        anotherData.comment,
        anotherData.uuid
      )
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async deleteStudentQuizMarkMethod(uuid) {
      await this.deleteStudentQuizMarks(uuid)
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    getSwitchData() {
      this.isModalClickedTerm = true
      this.isModalClicked = true
    },
    getSwitchState(switcherState) {
      this.$emit('getSwitchState', switcherState)
    },
    ...mapActions(useJournalStore, [
      'createQuarterMark',
      'patchQuarterMark',
      'deleteQuarterMark',
      'createStudentMark',
      'patchStudentMark',
      'createQuizMarks',
      'deleteQuizMarks',
      'patchQuizMarks',
      'createStudentQuizMarks',
      'patchStudentQuizMarks',
      'deleteStudentQuizMarks',
    ]),
  },
}
</script>
