<template>
  <div v-if="isModalClicked" class="modalSor__modal">
    <div class="modalSor__block">
      <div>
        <div class="d-flex justify-end">
          <button @click="$emit('closeModal')">
            <img src="@/assets/images/bi_x.svg" alt="" />
          </button>
        </div>
        <div class="text-center">
          <div><img src="@/assets/images/DangerSquare.svg" alt="" /></div>
          <h2 class="modalSor__text">Внимание!</h2>
          <h2 v-if="isModalClickedTerm" class="modalSor__text">
            {{ modalOptions[0] }}
          </h2>
          <h2 v-if="isModalMarkClicked" class="modalSor__text">
            Нельзя поставить оценку выше максимального значения, либо не
            заполнено поле комментариев
          </h2>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MarkModalSor',
  props: {
    isModalClicked: Boolean,
    isModalClickedTerm: Boolean,
    isModalMarkClicked: Boolean,
    modalOptions: {
      type: Array,
      default() {
        return []
      },
    },
  },
}
</script>
