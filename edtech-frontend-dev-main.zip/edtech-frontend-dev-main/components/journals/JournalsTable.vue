<template>
  <div class="journalsTable__container container" style="height: 92vh">
    <MarkModalSor
      :is-modal-clicked="isModalClicked"
      :modal-options="modalOptions"
      :is-modal-clicked-term="isModalClickedTerm"
      :is-modal-mark-clicked="isModalMarkClicked"
      @closeModal="closeModal"
    ></MarkModalSor>
    <div class="d-flex justify-space-between">
      <div class="d-flex journalsTable__title">
        <div class="journalsTable__title_margin">
          Класс: {{ journal.grade.name }}
        </div>
        <div>
          Классный руководитель:
          {{ getClassTeacherName }}
          {{ getClassTeacherLastName }}
        </div>
      </div>
      <div class="d-flex journalsTable__title">
        <HalfYearSwitcher
          :by-term="journal.byTerm"
          :grade-journal="gradeJournal"
          :subject-journal="subjectJournal"
          :quarter-journal="quarterJournal"
          @getSwitchData="getSwitchData"
          @getSwitchState="getSwitchState"
        >
        </HalfYearSwitcher>
        <div>
          <div class="journalsTable__dropDownWidth">
            <DropDownElementSorSoch
              v-if="!readonlyForClassteacher"
              :options="
                (journal.byTerm && term.name === 'I четверть') ||
                (journal.byTerm && term.name === 'III четверть')
                  ? [options[0]]
                  : options
              "
              :default="'Добавить CОр/Соч'"
              @input="getDropdownValue"
            ></DropDownElementSorSoch>
          </div>
        </div>
      </div>
    </div>
    <div class="journalsTable__border"></div>
    <div class="journalsTable__table">
      <div class="journalsTable__headers">
        <div class="journalsTable__gridNum">
          <div>№</div>
        </div>
        <div class="journalsTable__gridName">ФИО</div>
        <div class="journalsTable__gridMonthes">
          <div class="journalsTable__gridMonthes_name">
            <div
              v-for="(monthName, monthNum, index) in getMonthNew"
              :key="index"
              style="width: 100%"
            >
              <div class="journalsTable__gridMonthes_nameWithBorder">
                <div v-if="monthNum == 1">Январьь</div>
                <div v-if="monthNum == 2">Февраль</div>
                <div v-if="monthNum == 3">Март</div>
                <div v-if="monthNum == 4">Апрель</div>
                <div v-if="monthNum == 5">Май</div>
                <div v-if="monthNum == 6">Июнь</div>
                <div v-if="monthNum == 7">Июль</div>
                <div v-if="monthNum == 8">Август</div>
                <div v-if="monthNum == 9">Сентябрь</div>
                <div v-if="monthNum == 10">Октябрь</div>
                <div v-if="monthNum == 11">Ноябрь</div>
                <div v-if="monthNum == 12">Декабрь</div>
              </div>
              <div class="journalsTable__gridMonthes_dates">
                <div
                  v-for="(date, indexDate) in monthName"
                  :key="indexDate"
                  class="journalsTable__gridMonthes_datesNoflex"
                >
                  <div class="journalsTable__gridMonthes_datesHeight">
                    {{ new Date(date.date).getDate() }}
                  </div>
                  <MarksDropdown
                    :list="markType"
                    :current-mark-type="date.markType"
                    :date-uuid="date.uuid"
                    @updateMarkTypes="updateMarkTypes"
                  ></MarksDropdown>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="journalsTable__gridTerm">
          <div class="journalsTable__gridTerm_name">{{ term.name }}</div>
          <div class="d-flex">
            <div class="d-flex">
              <div v-for="(sorMark, index) in journal.quizMarks" :key="index">
                <MarkAddSor
                  class="journalsTable__markAddSor"
                  :prop-max-mark-value="sorMark.maxMarkValue"
                  :prop-quiz-mark-type="sorMark.quizMarkType"
                  :prop-quiz-mark-uuid="sorMark.uuid"
                  @editSorMark="editSorMark"
                  @deleteSorMark="deleteSorMark"
                ></MarkAddSor>
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_w66 journalsTable__gridTerm_h69"
              >
                %(CОр + ФО)
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_w47 journalsTable__gridTerm_h69"
              >
                %<br />CОч
              </div>
            </div>

            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_w63 journalsTable__gridTerm_h69"
              >
                Сумма %
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_w126 journalsTable__gridTerm_h69"
              >
                Рекомендуемая оценка
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_w70 journalsTable__gridTerm_h69"
              >
                Оценка
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        v-for="(element, studentIndex) in journal.studentMarkBooks"
        :key="studentIndex"
        class="journalsTable__subheader"
      >
        <div class="journalsTable__subheader_gridNum1">
          <div>{{ studentIndex + 1 }}</div>
        </div>
        <div class="journalsTable__subheader_gridName1">
          {{ element.studentProfile.userAccount.firstName }}
        </div>
        <div class="journalsTable__subheader_gridMarks">
          <div class="journalsTable__gridMonthes_dates">
            <div
              v-for="(monthNames, index) in getMonthNew"
              :key="index"
              class="journalsTable__gridMonthes_dates"
            >
              <div
                v-for="(dateElement, indexDateElement) in monthNames"
                :key="indexDateElement"
                class="journalsTable__gridMonthes_datesNoflex"
              >
                <div
                  class="journalsTable__gridMonthes_datesHeight journalsTable__gridMonthes_datesBigHeight"
                >
                  <div
                    v-if="
                      element.studentMarks.some(
                        (e) => e.mark.uuid === dateElement.uuid
                      )
                    "
                  >
                    <MarksCommentary
                      :student-data="element"
                      :grade-journal="gradeJournal"
                      :subject-journal="subjectJournal"
                      :quarter-journal="quarterJournal"
                      :mark-data="dateElement.uuid"
                      :mark-shower="
                        element.studentMarks.find(
                          (e) => e.mark.uuid === dateElement.uuid
                        ).markValue
                      "
                      :comment-shower="
                        element.studentMarks.find(
                          (e) => e.mark.uuid === dateElement.uuid
                        ).comment
                      "
                      @patchMarkAndComment="
                        patchMarkAndComment(
                          $event,
                          element.studentMarks.find(
                            (e) => e.mark.uuid === dateElement.uuid
                          ).uuid
                        )
                      "
                      @createMarkAndComment="createMarkAndComment"
                    ></MarksCommentary>
                  </div>
                  <div v-else>
                    <MarksCommentary
                      :student-data="element"
                      :grade-journal="gradeJournal"
                      :subject-journal="subjectJournal"
                      :quarter-journal="quarterJournal"
                      :mark-data="dateElement.uuid"
                      :mark-shower="null"
                      :comment-shower="null"
                      @patchMarkAndComment="patchMarkAndComment"
                      @createMarkAndComment="
                        createMarkAndComment(
                          $event,

                          element.uuid,

                          dateElement.uuid
                        )
                      "
                    ></MarksCommentary>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="journalsTable__subheader_gridTerm1">
          <div class="d-flex">
            <div v-for="(item, index) in journal.quizMarks" :key="index">
              <div
                v-if="
                  element.quizMarkStudents.some(
                    (e) => e.quizMark.uuid === item.uuid
                  )
                "
              >
                <MarkAddSorStudent
                  class="journalsTable__markAddSor"
                  :mark-book="element.uuid"
                  :quiz-mark-shower="
                    element.quizMarkStudents.find(
                      (e) => e.quizMark.uuid === item.uuid
                    ).markValue
                  "
                  :quiz-mark-uuid="item.uuid"
                  :quiz-max-mark="item.maxMarkValue"
                  :quiz-mark-student-uuid="
                    element.quizMarkStudents.find(
                      (e) => e.quizMark.uuid === item.uuid
                    ).uuid
                  "
                  @patchSorForStudent="patchSorForStudent"
                  @deleteStudentQuizMarkMethod="deleteStudentQuizMarkMethod"
                ></MarkAddSorStudent>
              </div>

              <div v-else>
                <MarkAddSorStudent
                  class="journalsTable__markAddSor"
                  :mark-book="element.uuid"
                  :quiz-mark-shower="null"
                  :quiz-max-mark="item.maxMarkValue"
                  :quiz-mark-uuid="item.uuid"
                  @createSorForStudent="createSorForStudent"
                ></MarkAddSorStudent>
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_itemsHeight journalsTable__gridTerm_w66"
              >
                <input
                  class="journalsTable__input"
                  disabled
                  :value="element.marksAndQuizMarksPercentage + '%'"
                />
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_itemsHeight journalsTable__gridTerm_w47"
              >
                <input
                  class="journalsTable__input"
                  disabled
                  :value="element.examineMarksPercentage + '%'"
                />
              </div>
            </div>

            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_itemsHeight journalsTable__gridTerm_w63"
              >
                <input
                  min="1"
                  class="journalsTable__input"
                  disabled
                  :value="element.allMarksPercentage + '%'"
                />
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_itemsHeight journalsTable__gridTerm_w126"
              >
                <input
                  min="1"
                  class="journalsTable__input"
                  disabled
                  :value="element.recommendedMark"
                />
              </div>
            </div>
            <div
              v-if="
                (journal.byTerm && term.name === 'II четверть') ||
                (journal.byTerm && term.name === 'IV четверть') ||
                !journal.byTerm
              "
            >
              <div
                class="journalsTable__gridTerm_items journalsTable__gridTerm_itemsHeight journalsTable__gridTerm_w70"
              >
                <div
                  class="d-flex align-center journalTableOnlyTerms__relative"
                >
                  <input
                    :disabled="readonlyForClassteacher"
                    type="number"
                    min="1"
                    class="journalsTable__input"
                    :max="element.quarterMark.value"
                    :value="element.quarterMark.markValue"
                    @change="
                      patchCreateQuarterMarkMethod(
                        element.uuid,
                        newQuarterMark,
                        quarterJournal,
                        element.quarterMark.uuid,
                        element.quarterMark.markValue
                      )
                    "
                    @input="getQuarterMarkValue"
                  />
                  <button
                    v-if="element.quarterMark.markValue > 0"
                    :disabled="readonlyForClassteacher"
                    type="button"
                    title="Delete"
                    class="journalTableOnlyTerms__delBtn"
                    @click="deleteQuarterMarkMethod(element.quarterMark.uuid)"
                  >
                    <img
                      src="@/assets/images/delete-stop-svgrepo-com.svg"
                      alt=""
                      height="8"
                      width="8"
                    />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import { useJournalStore } from '~/store/journal'
import { Journal, MarkTypeResults } from '@/models/journal.model'
import MarkAddSor from '@/components/journals/MarkAddSor'
import MarksDropdown from '@/components/journals/MarksDropdown'
import MarkAddSorStudent from '@/components/journals/MarkAddSorStudent'
import MarkModalSor from '@/components/journals/MarkModalSor'
import MarksCommentary from '@/components/journals/MarksCommentary'
import HalfYearSwitcher from '@/components/journals/HalfYearSwitcher'
import DropDownElementSorSoch from '@/components/journals/DropDownElementSorSoch'

export default {
  name: 'JournalsTable',
  components: {
    DropDownElementSorSoch,
    HalfYearSwitcher,
    MarksCommentary,
    MarkModalSor,
    MarkAddSorStudent,
    MarksDropdown,
    MarkAddSor,
  },
  props: {
    term: {
      type: Object,
      default() {
        return {}
      },
    },
    gradeJournal: {
      type: String,
      default: '',
    },
    quarterJournal: {
      type: String,
      default: '',
    },
    subjectJournal: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      monthTest: {},
      inputValue: '',
      isModalClicked: false,
      isModalClickedTerm: false,
      isModalMarkClicked: false,
      newQuarterMark: '',
      options: ['Добавить СОр', 'Добавить СОч'],
      modalOptions: [
        'Невозможно изменить вид оценивания журнала так как уже создан СОч или более 2-х СОр.',
      ],
    }
  },
  computed: {
    ...mapState(useJournalStore, {
      journal: (store) => Journal.serialize(store.journal),
      journalGetter: (store) => store.journalGetter,
      markType: (store) => MarkTypeResults.serializeList(store.markType),
    }),
    getMonthNew() {
      return this.monthChange(this.journal.marks)
    },
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
    getClassTeacherName() {
      return this.journal.grade.classTeacherProfile.userAccount.firstName
    },
    getClassTeacherLastName() {
      return this.journal.grade.classTeacherProfile.userAccount.lastName
    },
  },
  methods: {
    getQuarterMarkValue(event) {
      this.newQuarterMark = Number(event.target.value)
    },
    closeModal() {
      this.isModalClicked = false
    },
    async addSor() {
      await this.createQuizMarks(
        this.journal.uuid,
        'quiz',
        this.quarterJournal,
        0
      ).catch(() => {
        this.isModalClicked = true
        this.isModalClickedTerm = true
      })
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async addSoch() {
      await this.createQuizMarks(
        this.journal.uuid,
        'examine',
        this.quarterJournal,
        0
      ).catch(() => {
        this.isModalClicked = true
        this.isModalClickedTerm = true
      })
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },

    monthChange(data) {
      const filtered = {}

      data.forEach((month, i) => {
        const date = new Date(month.date).getMonth() + 1

        if (filtered[date]) {
          filtered[date].push(month)
        }
        if (!filtered[date]) {
          filtered[date] = [month]
        }
      })

      return filtered
    },
    async editSorMark({ data }) {
      await this.patchQuizMarks(data.maxMarkValue, data.propQuizMarkUuid)
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async deleteSorMark(uuid) {
      await this.deleteQuizMarks(uuid)
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    getDropdownValue(currentValue) {
      this.inputValue = currentValue
      if (currentValue === this.options[0]) {
        this.addSor()
      } else if (currentValue === this.options[1]) {
        this.addSoch()
      }
    },
    async patchCreateQuarterMarkMethod(
      studentMarkBook,
      markValue,
      quarter,
      uuid,
      oldMarkValue
    ) {
      if (
        (oldMarkValue === null ||
          oldMarkValue === '' ||
          oldMarkValue === 0 ||
          oldMarkValue === undefined) &&
        (uuid === null || uuid === '' || uuid === 0 || uuid === undefined)
      ) {
        await this.createQuarterMark(studentMarkBook, markValue, quarter)
        useJournalStore().loadJournal(
          this.gradeJournal,
          this.subjectJournal,
          this.quarterJournal
        )
      } else {
        await this.patchQuarterMark(markValue, uuid)
        useJournalStore().loadJournal(
          this.gradeJournal,
          this.subjectJournal,
          this.quarterJournal
        )
      }
    },
    async deleteQuarterMarkMethod(uuid) {
      await this.deleteQuarterMark(uuid)
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async createMarkAndComment(newMarkAndComment, studentMarkBook, mark) {
      await this.createStudentMark(
        studentMarkBook,
        newMarkAndComment.mark,
        newMarkAndComment.comment,
        mark
      ).catch(() => {
        this.isModalClicked = true
        this.isModalMarkClicked = true
      })
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async patchMarkAndComment(data, uuid) {
      await this.patchStudentMark(uuid, data.mark, data.comment).catch(() => {
        this.isModalClicked = true
        this.isModalMarkClicked = true
      })
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async createSorForStudent({ data }) {
      await this.createStudentQuizMarks(
        data.markBook,
        data.mark,
        data.quizMark,
        data.comment
      )
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async patchSorForStudent({ anotherData }) {
      await this.patchStudentQuizMarks(
        anotherData.mark,
        anotherData.comment,
        anotherData.uuid
      )
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    async deleteStudentQuizMarkMethod(uuid) {
      await this.deleteStudentQuizMarks(uuid)
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    getSwitchData() {
      this.isModalClickedTerm = true
      this.isModalClicked = true
    },
    getSwitchState(switcherState) {
      this.$emit('getSwitchState', switcherState)
    },
    updateMarkTypes() {
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
    },
    ...mapActions(useJournalStore, [
      'createQuarterMark',
      'patchQuarterMark',
      'deleteQuarterMark',
      'createStudentMark',
      'patchStudentMark',
      'createQuizMarks',
      'deleteQuizMarks',
      'patchQuizMarks',
      'createStudentQuizMarks',
      'patchStudentQuizMarks',
      'deleteStudentQuizMarks',
      'getMarkType',
    ]),
  },
}
</script>
