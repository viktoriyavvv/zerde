<template>
  <div class="journalsTable__gridTerm_Sor" style="height: 57px">
    <div class="d-flex align-center journalTableOnlyTerms__relative">
      <input
        :disabled="readonlyForClassteacher"
        type="number"
        min="1"
        class="journalsTable__input"
        :max="quizMaxMark"
        :value="(mark = quizMarkShower)"
        @input="getCurrentMark"
        @change="patchOrCreateQuizMark"
      />
      <button
        v-if="quizMarkShower > 0"
        :disabled="readonlyForClassteacher"
        type="button"
        title="Delete"
        class="journalTableOnlyTerms__delBtn"
        @click="deleteStudentQuizMarkMethod"
      >
        <img
          src="@/assets/images/delete-stop-svgrepo-com.svg"
          alt=""
          height="8"
          width="8"
        />
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MarkAddSorStudent',
  props: {
    markBook: {
      type: String,
      default: '',
    },
    quizMarkUuid: {
      type: String,
      default: '',
    },
    quizMarkShower: {
      type: Number,
      default: 0,
    },
    quizMaxMark: {
      type: Number,
      default: 0,
    },
    quizMarkStudentUuid: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      mark: Number,
    }
  },
  computed: {
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
  },
  methods: {
    getCurrentMark(event) {
      this.mark = event.target.value
    },
    patchOrCreateQuizMark() {
      if (
        this.quizMarkShower === 0 ||
        this.quizMarkShower === null ||
        this.quizMarkShower === undefined
      ) {
        const data = {
          markBook: this.markBook,
          mark: this.mark,
          quizMark: this.quizMarkUuid,
          comment: '',
        }
        this.$emit('createSorForStudent', { data })
      } else {
        const anotherData = {
          mark: this.mark,
          comment: '',
          uuid: this.quizMarkStudentUuid,
        }
        this.$emit('patchSorForStudent', { anotherData })
      }
    },
    deleteStudentQuizMarkMethod() {
      this.$emit('deleteStudentQuizMarkMethod', this.quizMarkStudentUuid)
    },
  },
}
</script>
