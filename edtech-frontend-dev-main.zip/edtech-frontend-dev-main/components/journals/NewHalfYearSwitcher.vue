<template>
  <div class="d-flex justify-center align-center mr-3">
    <div
      :class="
        byTerm === false
          ? 'journalTableOnlyTerms__halfYearSwitcher mx-3'
          : 'journalTableOnlyTerms__halfYearSwitcher journalTableOnlyTerms__halfYearSwitcher_gray mx-3'
      "
    >
      Четверть
    </div>
    <v-switch v-model="byTerm" :disabled="readonlyForClassteacher"></v-switch>
    <div
      :class="
        byTerm
          ? 'journalTableOnlyTerms__halfYearSwitcher mx-3'
          : 'journalTableOnlyTerms__halfYearSwitcher journalTableOnlyTerms__halfYearSwitcher_gray mx-3'
      "
    >
      Полугодие
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import { useJournalStore } from '~/store/journal'
import { SchoolYear } from '@/models/journalYear.model'

export default {
  name: 'NewHalfYearSwitcher',
  props: {
    gradeFinals: {
      type: String,
      default: '',
    },
    subjectFinals: {
      type: String,
      default: '',
    },
    markBookUuid: {
      type: String,
      default: '',
    },
  },
  computed: {
    ...mapState(useJournalStore, {
      schoolYear: (store) => SchoolYear.serialize(store.schoolYear),
      schoolYearGetter: (store) => store.schoolYearGetter,
    }),
    byTerm: {
      get() {
        return useJournalStore().$state.by_term
      },
      set(val) {
        this.getSwitchData(val)
      },
    },
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
  },
  methods: {
    async getSwitchData(bytermval) {
      this.changeByTerm(bytermval)
      await this.patchMarkGradeBooks(this.schoolYear.uuid, bytermval)
        .catch(() => {
          this.changeByTerm(false)
          this.$emit('getSwitchData')
        })
        .then(() => {})
      useJournalStore().getSchoolYear(this.gradeFinals, this.subjectFinals)
      this.$emit('getSwitchState', this.byTerm)
    },
    ...mapActions(useJournalStore, ['patchMarkGradeBooks', 'changeByTerm']),
  },
}
</script>

<style lang="scss">
.v-input--selection-controls {
  margin-top: 16px;
  padding-top: 8px;
}
</style>
