<template>
  <div>
    <div class="journalsTable__gridTerm_Sor">
      <div v-if="propQuizMarkType === 'quiz'">СОр</div>
      <div v-if="propQuizMarkType === 'examine'">СОч</div>
      <button :disabled="readonlyForClassteacher" @click="deleteSorMark">
        <img
          src="@/assets/images/bi_x-circle.svg"
          height="12"
          width="12"
          alt="close"
        />
      </button>
    </div>
    <form class="journalsTable__gridTerm_form" @submit.prevent>
      <label for="maxMark" class="journalsTable__gridTerm_max"
        >Макс. балл<input
          id="maxMark"
          min="1"
          :disabled="readonlyForClassteacher"
          name="maxMark"
          type="number"
          :value="(maxMarkValue = propMaxMarkValue)"
          max="10"
          @input="getMaxMarkValue"
          @change="editSorMark"
      /></label>
    </form>
  </div>
</template>

<script>
export default {
  name: 'MarkAddSor',
  props: {
    options: {
      type: String,
      default: '',
    },
    propMaxMarkValue: {
      type: Number,
      default: 0,
    },
    propQuizMarkType: {
      type: String,
      default: '',
    },
    propQuizMarkUuid: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      maxMarkValue: 0,
    }
  },
  computed: {
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
  },
  methods: {
    deleteSorMark() {
      this.$emit('deleteSorMark', this.propQuizMarkUuid)
    },
    editSorMark() {
      const data = {
        maxMarkValue: this.maxMarkValue,
        propQuizMarkUuid: this.propQuizMarkUuid,
      }
      this.$emit('editSorMark', { data })
    },
    getMaxMarkValue(event) {
      this.maxMarkValue = Number(event.target.value)
      console.log(this.maxMarkValue)
    },
  },
}
</script>
