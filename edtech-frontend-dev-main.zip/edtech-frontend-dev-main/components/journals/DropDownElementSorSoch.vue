<template>
  <div class="custom-select" :tabindex="tabindex" @blur="open = false">
    <div class="selected" :class="{ open: open }" @click="open = !open">
      {{ typeof selected === 'string' ? selected : selected.name }}
    </div>
    <div v-if="type" class="items" :class="{ selectHide: !open }">
      <div
        v-for="(option, i) of options"
        :key="i"
        @click="setSelectedGrade(option)"
      >
        {{ typeof option === 'string' ? option : option.name }}
      </div>
    </div>
    <div v-else class="items" :class="{ selectHide: !open }">
      <div
        v-for="(option, i) of options"
        :key="i"
        @click="setSelectedItem(option)"
      >
        {{ typeof option === 'string' ? option : option.name }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'DropDownElementSorSoch',
  props: {
    type: {
      type: String,
      required: false,
      default: '',
    },
    options: {
      type: Array,
      required: true,
    },
    default: {
      type: String,
      required: false,
      default: null,
    },
    tabindex: {
      type: Number,
      required: false,
      default: 0,
    },
    reset: {
      type: Boolean,
      required: false,
    },
  },
  data() {
    return {
      selected: this.default
        ? this.default
        : this.options.length > 0
        ? this.options[0]
        : null,
      open: false,
    }
  },
  computed: {
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
  },
  watch: {
    reset() {
      if (this.reset) {
        this.selected = this.default
      }
    },
  },
  mounted() {
    this.$emit('input', this.selected)
  },
  methods: {
    setSelectedGrade(option) {
      this.selected = option.name
      this.open = false
      this.$emit('input', option)
    },
    setSelectedItem(option) {
      this.selected = option
      this.open = false
      this.$emit('input', option)
    },
  },
}
</script>

<style scoped lang="scss">
.custom-select {
  position: relative;
  width: 100%;
  text-align: left;
  outline: none;
  height: 35px;
  line-height: 42px;
}

.custom-select .selected {
  background-color: transparent;
  border-radius: 10px;
  color: #003a70;
  padding-left: 2em;
  padding-right: 2em;
  cursor: pointer;
  user-select: none;
  text-align: center;
}

.custom-select .selected.open {
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
}

.custom-select .selected:after {
  position: absolute;
  content: '';
  top: 22px;
  right: 10px;
  width: 0;
  height: 0;
  border: 5px solid transparent;
  border-color: #003a70 transparent transparent transparent;
}

.custom-select .items {
  color: #003a70;
  border-radius: 0px 0px 10px 10px;
  overflow: hidden;
  border-top: 1px solid #003a70;
  border-right: 1px solid #003a70;
  border-left: 1px solid #003a70;
  border-bottom: 1px solid #003a70;
  position: absolute;
  background-color: white;
  left: 0;
  right: 0;
  z-index: 1;
  max-height: 255px;
  overflow-y: scroll;
}

.custom-select .items div {
  color: #003a70;
  padding-left: 1em;
  cursor: pointer;
  user-select: none;
  text-align: center;
}

.custom-select .items div:hover {
  background-color: #f5f6fa;
}

.selectHide {
  display: none;
}
</style>
