<template>
  <div class="d-flex justify-center align-center mr-3">
    <div
      :class="
        byTerm === false
          ? 'journalTableOnlyTerms__halfYearSwitcher mx-3'
          : 'journalTableOnlyTerms__halfYearSwitcher journalTableOnlyTerms__halfYearSwitcher_gray mx-3'
      "
    >
      Четверть
    </div>
    <v-switch v-model="byTerm" :disabled="readonlyForClassteacher"></v-switch>
    <div
      :class="
        byTerm
          ? 'journalTableOnlyTerms__halfYearSwitcher mx-3'
          : 'journalTableOnlyTerms__halfYearSwitcher journalTableOnlyTerms__halfYearSwitcher_gray mx-3'
      "
    >
      Полугодие
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import { useJournalStore } from '~/store/journal'
import { Journal } from '@/models/journal.model'

export default {
  name: 'HalfYearSwitcher',
  props: {
    gradeJournal: {
      type: String,
      default: '',
    },
    quarterJournal: {
      type: String,
      default: '',
    },
    subjectJournal: {
      type: String,
      default: '',
    },
  },
  computed: {
    ...mapState(useJournalStore, {
      journal: (store) => Journal.serialize(store.journal),
      journalGetter: (store) => store.journalGetter,
    }),
    byTerm: {
      get() {
        return useJournalStore().$state.by_term
      },
      set(val) {
        this.getSwitchData(val)
      },
    },
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
  },
  methods: {
    async getSwitchData(bytermval) {
      this.changeByTerm(bytermval)
      await this.patchMarkGradeBooks(this.journal.uuid, bytermval)
        .catch(() => {
          this.changeByTerm(false)
          this.$emit('getSwitchData')
        })
        .then(() => {})
      useJournalStore().loadJournal(
        this.gradeJournal,
        this.subjectJournal,
        this.quarterJournal
      )
      this.$emit('getSwitchState', this.byTerm)
    },
    ...mapActions(useJournalStore, ['patchMarkGradeBooks', 'changeByTerm']),
  },
}
</script>

<style lang="scss">
.v-application .mr-3 {
  margin-right: 12px !important;
  height: 20px;
}
</style>
