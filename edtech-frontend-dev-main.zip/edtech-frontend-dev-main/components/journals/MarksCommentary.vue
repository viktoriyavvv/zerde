<template>
  <v-menu
    v-model="showMenu"
    :disabled="readonlyForClassteacher"
    transition="scale-transition"
    :close-on-content-click="false"
  >
    <template #activator="{ on, attrs }">
      <div
        :class="
          readonlyForClassteacher
            ? 'marksCommentary__mark_disabled'
            : 'marksCommentary__mark'
        "
        v-bind="attrs"
        v-on="on"
      >
        <div class="marksCommentary__markShower">{{ marks }}</div>
      </div>
    </template>
    <div class="marksCommentary__block">
      <form class="marksCommentary__wrapper">
        <div class="d-flex justify-space-between align-center">
          <div>
            <label for="mark" class="marksCommentary__text">Оценка:</label>

            <input
              id="mark"
              ref="markRef"
              :disabled="readonlyForClassteacher"
              type="number"
              :value="(marks = markShower)"
              class="marksCommentary__input"
              name="mark"
              min="1"
              @input="getMark"
            />
          </div>
          <div class="marksCommentary__select">
            <label class="marksCommentary__text">Посещаемость:</label>
            <v-select
              :items="marksAndLettersArray"
              label="-"
              hide-selected
              single-line
              solo
              class="marksCommentary__input"
            ></v-select>
          </div>
        </div>
        <label for="commentaries" class="marksCommentary__text"
          >Комментарии:</label
        >
        <textarea
          id="commentaries"
          :disabled="readonlyForClassteacher"
          :value="(comment = commentShower)"
          class="marksCommentary__input marksCommentary__input_area"
          name="commentaries"
          @input="getComment"
        />
        <div class="d-flex justify-space-between">
          <button
            :disabled="readonlyForClassteacher"
            type="submit"
            class="marksCommentary__btn"
            @click.prevent="onSubmitAction(marks, comment)"
          >
            Cохранить
          </button>
          <button
            :disabled="readonlyForClassteacher"
            class="marksCommentary__btn marksCommentary__btn_gray"
            @click.prevent=";(showMenu = false), (marks = ''), (comment = '')"
          >
            Отменить
          </button>
        </div>
      </form>
    </div>
  </v-menu>
</template>

<script>
import { mapState } from 'pinia'
import { useJournalStore } from '~/store/journal'
import { Journal } from '@/models/journal.model'

export default {
  name: 'MarksCommentary',
  props: {
    studentData: {
      type: Object,
      required: true,
    },
    markData: {
      type: String,
      default: '',
      required: true,
    },
    gradeJournal: {
      type: String,
      default: '',
    },
    quarterJournal: {
      type: String,
      default: '',
    },
    subjectJournal: {
      type: String,
      default: '',
    },
    markShower: {
      type: Number,
    },
    commentShower: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      showMenu: false,
      marks: '',
      comment: '',

      marksAndLettersArray: ['н', 'б', 'о'],
    }
  },
  computed: {
    ...mapState(useJournalStore, {
      journal: (store) => Journal.serialize(store.journal),
      journalGetter: (store) => store.journalGetter,
    }),
    readonlyForClassteacher() {
      return this.$nuxt.$auth.user.role === 'class-teacher'
    },
  },
  methods: {
    onSubmitAction(marks, commentary) {
      if (
        this.markShower === 0 ||
        this.markShower === null ||
        this.markShower === undefined
      ) {
        const data = {
          mark: Number(this.marks),
          comment: this.comment,
        }
        this.$emit('createMarkAndComment', data)
        this.showMenu = false
      } else {
        const data = {
          mark: Number(this.marks),
          comment: this.comment,
        }
        this.$emit('patchMarkAndComment', data)
        this.showMenu = false
      }

      if (!commentary && marks) {
        return false
      }
    },
    getMark(event) {
      this.marks = event.target.value
    },
    getComment(event) {
      this.comment = event.target.value
    },
  },
}
</script>

<style lang="scss">
.v-text-field.v-text-field--solo .v-input__control {
  min-height: 42px;
  padding: 0;
  color: #8b8b8b !important;
}
.v-text-field.v-text-field--solo:not(.v-text-field--solo-flat)
  > .v-input__control
  > .v-input__slot {
  box-shadow: none;
}
.v-text-field.v-text-field--solo:not(.v-text-field--solo-flat)
  > .v-input__control
  > .v-input__slot {
  box-shadow: none;
}
.v-select__selection--comma {
  margin: 7px 4px 7px 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 500;
  font-size: 14px;
  color: #8b8b8b !important;
}
</style>
