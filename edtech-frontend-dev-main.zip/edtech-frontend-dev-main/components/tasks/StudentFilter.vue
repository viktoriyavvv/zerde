<template>
  <div class="sidebar">
    <div class="sidebar__container">
      <div class="sidebar__body">
        <h1 class="sidebar__title">Действия</h1>
        <div class="sidebar__items">
          <div class="sidebar__item">
            <drop-down-element
              type="grades"
              :options="grades"
              :default="gradeDefault"
              @input="filterOnGrade"
            ></drop-down-element>
          </div>
          <div class="sidebar__item">
            <button
              class="sidebar__button sidebar__button_dark"
              @click="filterList"
            >
              Применить
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import DropDownElement from '~/components/main/DropDownElement'
export default {
  components: {
    DropDownElement,
  },
  props: {
    grades: {
      type: Array,
      default() {
        return []
      },
      required: false,
    },
  },
  data() {
    return {
      gradeDefault: 'Выбрать класс',
      selectedGrade: '',
    }
  },
  methods: {
    filterOnGrade(selected) {
      this.selectedGrade = selected
    },
    filterList() {
      this.$emit('filterList', this.selectedGrade)
    },
  },
}
</script>
