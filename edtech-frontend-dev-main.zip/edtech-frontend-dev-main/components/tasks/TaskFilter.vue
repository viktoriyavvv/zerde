<template>
  <div class="main-component">
    <div class="main-component-title">Действия</div>
    <div class="d-flex flex-column gap20 mt-4">
      <drop-down-element
        type="subjects"
        :options="subjects"
        :default="subjectDefault"
        :reset="reset"
        class="main-component-text sidebar__dropdown"
        @input="filterOnSubject"
      ></drop-down-element>
      <drop-down-element
        v-if="$auth.user.role !== 'student'"
        type="grades"
        :options="grades"
        :default="gradeDefault"
        :reset="reset"
        class="main-component-text sidebar__dropdown"
        @input="filterOnGrade"
      ></drop-down-element>
      <v-menu
        v-if="$auth.user.role === 'student'"
        ref="menu"
        v-model="menu"
        :close-on-content-click="false"
        transition="scale-transition"
        offset-y
        min-width="auto"
      >
        <template #activator="{ on, attrs }">
          <div
            class="d-flex blueBorder d-flex align-center py-3 px-4 justify-space-between"
            v-bind="attrs"
            v-on="on"
          >
            <div class="main-component-text blueColor">
              <span
                v-if="filterDate.length !== 2"
                class="main-component-text blueColor"
                >Выберите даты</span
              >
              <span v-else class="main-component-text blueColor"
                >{{ formattedDate[0] }} - {{ formattedDate[1] }}</span
              >
            </div>
            <img src="@/assets/images/Calendar.svg" />
          </div>
        </template>
        <v-date-picker
          v-model="filterDate"
          no-title
          scrollable
          range
          locale="ru-RU"
          first-day-of-week="1"
          @change="filterOnDate"
        >
        </v-date-picker>
      </v-menu>
      <button
        class="sidebar__button sidebar__button_dark"
        :class="{
          sidebar__button_disabled: buttonDisabled,
        }"
        :disabled="buttonDisabled"
        @click="filterList"
      >
        Применить
      </button>
      <button
        class="buttonBlueBorder main-component-text sidebar__reset"
        @click="resetFilter"
      >
        Сбросить
      </button>
      <button
        v-if="$auth.user.role === 'teacher' || $auth.user.role === 'admin'"
        class="buttonBlueBorder main-component-text sidebar__createHw"
        @click="setMode(true)"
      >
        Создать задание
      </button>
    </div>
  </div>
</template>

<script>
import DropDownElement from '~/components/main/DropDownElement'

export default {
  components: {
    DropDownElement,
  },
  props: {
    subjects: {
      type: Array,
      default() {
        return []
      },
      required: false,
    },
    grades: {
      type: Array,
      default() {
        return []
      },
      required: false,
    },
  },
  data() {
    return {
      subjectDefault: 'Выбрать предмет',
      gradeDefault: 'Выбрать класс',
      selectedSubject: '',
      selectedGrade: '',
      reset: false,
      createMode: false,
      menu: false,
      filterDate: [],
    }
  },
  computed: {
    formattedDate() {
      const options = {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }
      const firstDate = new Date(
        Date.parse(this.filterDate[0])
      ).toLocaleDateString('ru-RU', options)
      const secondDate = new Date(
        Date.parse(this.filterDate[1])
      ).toLocaleDateString('ru-RU', options)
      return [firstDate, secondDate]
    },
    subjectCheck() {
      return this.subjects.some((e) => e.uuid === this.selectedSubject.uuid)
    },
    gradeCheck() {
      return this.grades.some((e) => e.uuid === this.selectedGrade.uuid)
    },
    buttonDisabled() {
      if (
        this.subjectCheck ||
        this.gradeCheck ||
        this.filterDate.length === 2
      ) {
        return false
      } else return true
    },
  },
  methods: {
    filterOnSubject(selected) {
      this.reset = false
      this.selectedSubject = selected
    },
    filterOnGrade(selected) {
      this.reset = false
      this.selectedGrade = selected
    },
    filterOnDate() {
      this.reset = false
    },
    filterList() {
      if (this.$auth.user.role === 'student') {
        this.$emit(
          'filterListStudent',
          this.selectedSubject,
          this.filterDate,
          this.reset
        )
      } else {
        this.$emit(
          'filterListTeacher',
          this.selectedSubject,
          this.selectedGrade,
          this.reset
        )
      }
    },
    resetFilter() {
      this.reset = true
      this.selectedSubject = this.subjectDefault
      this.selectedGrade = this.gradeDefault
      this.filterDate = []
      this.filterList()
    },

    setMode(value) {
      this.$emit('setMode', value)
    },
  },
}
</script>

<style lang="scss"></style>
