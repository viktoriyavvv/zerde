<template>
  <div class="sidebar main-component-text">
    <div class="sidebar__container">
      <div class="sidebar__body">
        <h1 class="sidebar__title">Действия</h1>
        <div class="sidebar__items">
          <div class="sidebar__item">
            <drop-down-element
              type="grades"
              :options="grades"
              :default="gradeDefault"
              @input="filterOnGrade"
            ></drop-down-element>
          </div>
          <div class="sidebar__item">
            <div class="sidebar__text">Четверть</div>
          </div>
          <div class="sidebar__item">
            <div class="sidebar__button-wrap">
              <button
                v-for="(button, index) in 4"
                :key="'quarterButton' + index"
                class="borderRadius blueColor buttonBlueBorder d-flex align-center justify-center"
              >
                {{ index + 1 }}
              </button>
            </div>
          </div>
          <div class="sidebar__item">
            <button
              class="sidebar__button sidebar__button_dark"
              @click="filterList"
            >
              Применить
            </button>
          </div>
          <div class="sidebar__item">
            <button
              class="borderRadius blueColor buttonBlueBorder sidebar__button"
            >
              Импортировать таблицу
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'pinia'
import DropDownElement from '~/components/main/DropDownElement'
import { useGradeStore } from '~/store'
export default {
  components: {
    DropDownElement,
  },
  data() {
    return {
      gradeDefault: 'Выбрать класс',
      selectedGrade: '',
    }
  },
  computed: {
    ...mapState(useGradeStore, {
      grades: (store) => store.gradeList,
    }),
  },
  methods: {
    filterOnGrade(selected) {
      this.selectedGrade = selected
    },
    filterList() {
      this.$emit('filterList', this.selectedGrade)
    },
  },
}
</script>
