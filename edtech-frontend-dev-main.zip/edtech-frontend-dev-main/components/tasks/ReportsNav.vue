<template>
  <div class="sidebar main-component-text">
    <div class="sidebar__container">
      <div class="sidebar__body">
        <h1 class="sidebar__title">Список отчетов</h1>
        <div class="sidebar__items">
          <div class="sidebar__item">
            <nuxt-link to="/" class="sidebar__text sidebar__text_nav-link"
              >Движение учеников</nuxt-link
            >
            <div class="sidebar__text sidebar__text_report-type">
              Сводный отчет
            </div>
            <div class="sidebar__text sidebar__text_report-type">Прибывшие</div>
            <div class="sidebar__text sidebar__text_report-type">Выбывшие</div>
          </div>
          <div class="sidebar__item">
            <nuxt-link to="/" class="sidebar__text sidebar__text_nav-link"
              >Успеваемость</nuxt-link
            >
            <div class="sidebar__text sidebar__text_report-type">Школа</div>
            <div class="sidebar__text sidebar__text_report-type">Классы</div>
            <div class="sidebar__text sidebar__text_report-type">Ученики</div>
            <div class="sidebar__text sidebar__text_report-type">
              Класс по предмету
            </div>
            <div class="sidebar__text sidebar__text_report-type">
              Учителя по предмету
            </div>
          </div>
          <div class="sidebar__item">
            <nuxt-link to="/" class="sidebar__text sidebar__text_nav-link"
              >Посещаемость</nuxt-link
            >
            <div class="sidebar__text sidebar__text_report-type">
              Сводный отчет
            </div>
            <div class="sidebar__text sidebar__text_report-type">Школа</div>
            <div class="sidebar__text sidebar__text_report-type">Классы</div>
          </div>
          <div class="sidebar__item">
            <nuxt-link to="/" class="sidebar__text sidebar__text_nav-link"
              >Время на домашнее задание</nuxt-link
            >
            <div class="sidebar__text sidebar__text_report-type">Школа</div>
            <div class="sidebar__text sidebar__text_report-type">Классы</div>
          </div>
          <div class="sidebar__item">
            <nuxt-link to="/" class="sidebar__text sidebar__text_nav-link"
              >Активность на портале</nuxt-link
            >
            <div class="sidebar__text sidebar__text_report-type">Общая</div>
            <div class="sidebar__text sidebar__text_report-type">
              Индивидуальная
            </div>
          </div>
          <div class="sidebar__item">
            <nuxt-link to="/" class="sidebar__text sidebar__text_nav-link"
              >История изменений</nuxt-link
            >
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      gradeDefault: 'Выбрать класс',
      selectedGrade: '',
    }
  },
}
</script>
