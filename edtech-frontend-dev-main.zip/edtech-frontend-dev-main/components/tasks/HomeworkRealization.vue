<template>
  <div class="main-component">
    <div class="main-component-title">Выполнение задания</div>
    <div class="mt-4 subtitle-text">{{ details.subject.name }}</div>
    <div class="mt-2 main-component-text grayColor">
      {{ details.teacherName.fullName }}
    </div>
    <div class="mt-4 subtitle-text">Срок выполнения</div>
    <div class="mt-2 main-component-text grayColor">{{ formatDeadline }}</div>
    <div class="mt-4 subtitle-text">Описание:</div>
    <div
      class="mt-2 grayBorder borderRadius pa-2 main-component-text text-break"
    >
      {{ details.description }}
    </div>

    <div v-if="details.attachedFiles.length" class="mt-2">
      <div class="mt-4 subtitle-text">Материалы:</div>
      <div
        class="grayBorder borderRadius mr-2 pa-3 main-component-text d-flex flex-column available mt-2"
      >
        <a
          v-for="(file, index) in details.attachedFiles"
          :key="index"
          :href="file.file"
          target="_blank"
          class="text-break grayColor my-2"
          >{{ file.name }}</a
        >
      </div>
    </div>
    <div
      v-if="!isDeadline && !reply.length"
      id="replyField"
      class="d-flex flex-column mt-6"
    >
      <label for="commentForTeacher" class="subtitle-text">
        Комментарий для учителя:
      </label>
      <textarea
        id="commentForTeacher"
        v-model="commentForTeacher"
        :class="{ errorBorder: commentEmpty }"
        class="grayBorder borderRadius pa-2 mt-2 textarea main-component-text"
      />
      <div
        v-if="commentEmpty"
        class="main-component-text-little text-center mt-2 red-color"
      >
        Это обязательное поле
      </div>
      <label for="attachedFiles" class="mt-4 subtitle-text"
        >Прикладываемые материалы:</label
      >
      <input
        id="attachedFiles"
        ref="attachedFilesStudent"
        type="file"
        name="attachedFiles"
        class="mt-2 inputFile"
        multiple
        @change="previewFiles()"
      />
      <div v-if="attachedFilesStudent.length > 0" class="d-flex mt-2">
        <div
          class="grayBorder borderRadius pa-2 main-component-text grayColor pa-3 available"
        >
          <div
            v-for="(file, index) in attachedFilesStudent"
            :key="file.name"
            class="my-3 d-flex justify-space-between align-center"
          >
            <div class="text-break grayColor">{{ file.name }}</div>
            <button class="ml-4 d-flex" @click="removeFile(index)">
              <img src="@/assets/images/close_little.svg" />
            </button>
          </div>
        </div>
      </div>
      <label
        for="attachedFiles"
        class="buttonBlueBorder blueColor main-component-text noActiveBlueBtn mt-2"
        >Загрузить</label
      >
      <button
        v-if="!replyState"
        id="saveBtn"
        class="mt-6 buttonBlue"
        @click="sendAnswer"
      >
        Сохранить
      </button>
      <button
        v-else-if="replyState"
        id="successMsg"
        class="mt-6 buttonBlue"
        @click="setMode"
      >
        Задание отправлено🥳
      </button>
    </div>
    <div
      v-if="isDeadline && !reply.length"
      id="deadlineWarn"
      class="main-component-text red--text mt-5"
    >
      Вы не можете отправить ответ после дедлайна
    </div>
    <div v-if="reply.length" id="answerWarn">
      <div class="subtitle-text font-weight-bold mt-5">
        Вы уже отправили ответ на задание
      </div>
      <div class="grayBorder borderRadius pa-2 mt-4">
        <div v-if="reply[0].doc.length">
          <div class="main-component-text">Ваши приложенные файлы:</div>
          <div class="my-2 d-flex flex-column available">
            <a
              v-for="(file, index) in reply[0].doc"
              :key="index"
              :href="file.file"
              target="_blank"
              class="text-break blueColor main-component-text d-block mb-2"
              >{{ file.name }}</a
            >
          </div>
        </div>
        <div>
          <div class="main-component-text">Ваш ответ:</div>
          <div class="main-component-text mt-2 grayColor">
            {{ reply[0].comment }}
          </div>
        </div>
      </div>
    </div>
    <div class="d-flex flex-column">
      <button class="mt-6 buttonBlue" @click="setMode">Закрыть</button>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState, mapStores } from 'pinia'
import { useHomeworkStore } from '~/store'
import { HomeworkDetails, StudentAnswer } from '~/models/homework.model'

export default {
  name: 'HomeworkRealizationComponent',
  data() {
    return {
      attachedFilesStudent: [],
      commentForTeacher: '',
      isDeadline: false,
      commentEmpty: false,
    }
  },
  computed: {
    ...mapStores(useHomeworkStore),
    ...mapState(useHomeworkStore, {
      filesID: (store) => store.filesID,
      replyState: (store) => store.successReply,
      details: (store) => HomeworkDetails.serialize(store.selectedHomework),
      reply: (store) => StudentAnswer.serializeList(store.studentReply),
    }),
    formatDeadline() {
      return new Date(Date.parse(this.details.deadline)).toLocaleDateString(
        'ru-RU',
        {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
        }
      )
    },
  },

  mounted() {
    this.checkForDeadline()
  },

  updated() {
    this.checkForDeadline()
  },

  methods: {
    ...mapActions(useHomeworkStore, ['uploadFiles', 'replyStudent', 'setMode']),
    previewFiles(event) {
      for (const file of this.$refs.attachedFilesStudent.files) {
        this.attachedFilesStudent.push(file)
      }
      this.$refs.attachedFilesStudent.input = null
    },
    removeFile(index) {
      this.attachedFilesStudent.splice(index, 1)
    },

    checkForDeadline() {
      const today = new Date().toISOString()
      const deadline = new Date(Date.parse(this.details.deadline)).toISOString()
      if (today > deadline) {
        this.isDeadline = true
      } else this.isDeadline = false
    },

    sendAnswer() {
      let answer = {}
      answer = {
        attached_files: this.attachedFilesStudent,
        assignment: this.details.uuid,
        comment: this.commentForTeacher,
      }
      if (answer.comment === '') {
        this.commentEmpty = true
      } else {
        this.commentEmpty = false
        this.replyStudent(answer)
      }
    },
  },
}
</script>

<style lang="scss">
.textarea {
  resize: none;
  outline: none;
}

.inputFile {
  width: 0.1px;
  height: 0.1px;
  opacity: 0;
  overflow: hidden;
  position: absolute;
  z-index: -1;
}

.available {
  width: available;
  width: -moz-available;
  width: -webkit-fill-available;
}

.errorBorder {
  border: 1px solid #ff2e2e !important;
}

.red-color {
  color: #ff2e2e;
}
</style>
