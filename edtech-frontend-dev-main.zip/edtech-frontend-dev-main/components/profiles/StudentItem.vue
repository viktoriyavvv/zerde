<template>
  <div class="profile">
    <v-expand-transition>
      <v-card
        v-if="reveal"
        class="transition-fast-in-fast-out v-card--reveal"
        style="height: 100%"
      >
        <div class="profile__body">
          <div class="profile__content">
            <h1 class="profile__title">Выбранный ученик</h1>
            <div class="profile__main">
              <div class="profile__image">
                <img v-if="profile.image" :src="profile.image" alt="" />
                <img
                  v-else
                  src="~/assets/images/avatar-placeholder.png"
                  alt=""
                />
              </div>
              <div class="profile__name">
                {{ profile.userAccount.fullName }}
              </div>
            </div>
            <div class="profile__items">
              <div class="profile__item">
                <span>Дата рождения:</span
                ><span class="profile__text">{{ formattedDate }}</span>
              </div>
              <div class="profile__item">
                <span>Родитель:</span
                ><span class="profile__text">{{ profile.parent }}</span>
              </div>
              <div class="profile__item">
                <span>Номер телефона:</span
                ><span class="profile__text">{{ profile.parentPhone }}</span>
              </div>
            </div>
          </div>
          <div class="profole__footer">
            <button class="profile__button" @click="closeProfile(profile)">
              Закрыть
            </button>
          </div>
        </div>
      </v-card>
    </v-expand-transition>
  </div>
</template>

<script>
export default {
  name: 'StudentItem',
  props: {
    profile: {
      type: Object,
      default() {
        return {}
      },
    },
    reveal: {
      type: Boolean,
    },
  },
  computed: {
    formattedDate() {
      const options = {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      }
      return new Date(Date.parse(this.profile.dateOfBirth)).toLocaleDateString(
        'ru-RU',
        options
      )
    },
  },
  methods: {
    closeProfile() {
      this.$emit('closeProfile')
    },
  },
}
</script>

<style lang="scss">
.v-card--reveal {
  width: 100%;
  bottom: 0;
  left: 0;
  padding: 25px;
  opacity: 1 !important;
  position: absolute;
}
.v-sheet.v-card:not(.v-sheet--outlined) {
  box-shadow: none;
}
.v-card > *:last-child:not(.v-btn):not(.v-chip):not(.v-avatar) {
  border-radius: 10px;
}
</style>
