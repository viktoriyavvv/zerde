<template>
  <div class="data__teacher">
    <div class="data__profile block__title">
      <p class="name">Мой классный руководитель</p>
      <hr />
      <div class="data__profile_name">
        <img v-if="profile.image" :src="classTeacherPic" alt="" />
        <img v-else src="~/assets/images/avatar-placeholder.png" alt="" />
        <p>{{ teacherUser.fullName }}</p>
      </div>
      <div class="data__profile_more">
        <p class="data__profile_phone">Телефон: {{ profile.phone }}</p>
        <p class="data__profile_email">
          Почтовый адрес: {{ teacherUser.email }}
        </p>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'pinia'
import { useGradeStore } from '~/store'

export default {
  props: {
    profile: {
      type: Object,
      default() {
        return {}
      },
      required: true,
    },
    teacherUser: {
      type: Object,
      default() {
        return {}
      },
    },
  },
  computed: {
    ...mapState(useGradeStore, {
      classTeacherPic: (store) => store.classTeacherPic,
    }),
  },
}
</script>
