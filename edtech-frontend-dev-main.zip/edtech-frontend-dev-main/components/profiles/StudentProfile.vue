<template>
  <div class="data__profile block__title">
    <p class="name">Мой профиль</p>
    <hr />
    <div class="data__profile_name">
      <img v-if="profile.image" id="avatar" :src="profilePic" alt="" />
      <img
        v-else
        id="avatarPlaceholder"
        src="~/assets/images/avatar-placeholder.png"
        alt=""
      />
      <p>{{ profile.userAccount.fullName }}</p>
    </div>
    <div id="profile" class="data__profile_more">
      <p>Класс: {{ profile.grade.name }}</p>
      <p>Дата рождения: {{ profile.dateOfBirth }}</p>
      <p>Телефон: {{ profile.phone }}</p>
      <p>Почтовый адрес: {{ profile.userAccount.email }}</p>
      <p>Адрес проживания: {{ profile.address.fullAddress }}</p>
    </div>
    <button class="data__profile_button" @click="isModal = true">
      Изменить пароль
    </button>
    <ChangePasswordModal v-if="isModal" @onClose="closeModal" />
  </div>
</template>

<script>
import { mapState, mapActions } from 'pinia'
import { useProfileStore } from '~/store'
import { StudentProfile } from '~/models'
import ChangePasswordModal from '~/components/profiles/ChangePasswordModal.vue'

export default {
  components: { ChangePasswordModal },
  data() {
    return {
      isModal: false,
    }
  },
  computed: {
    ...mapState(useProfileStore, {
      profile: (store) => StudentProfile.serialize(store.profile),
      profilePic: (store) => store.profilePic,
      loading: (store) => store.loading,
    }),
  },
  async mounted() {
    await this.loadProfile()
  },
  methods: {
    ...mapActions(useProfileStore, ['loadProfile']),
    closeModal() {
      this.isModal = false
    },
  },
}
</script>
