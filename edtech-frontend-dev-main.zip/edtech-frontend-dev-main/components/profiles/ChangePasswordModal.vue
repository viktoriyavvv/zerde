<template>
  <transition name="fade">
    <div class="modal" @click.self="closeModal">
      <div class="modal__body">
        <div>
          <h1 class="body__title">Изменить пароль</h1>
        </div>
        <form @submit.prevent="changePassword">
          <div>
            <input
              v-model="passwords.old_password"
              type="password"
              required
              minlength="8"
              placeholder="Текущий пароль"
            />
          </div>
          <div>
            <input
              v-model="passwords.new_password"
              type="password"
              required
              minlength="8"
              placeholder="Новый пароль"
            />
          </div>
          <div>
            <input
              v-model="passwords.confirm_new"
              type="password"
              required
              minlength="8"
              placeholder="Подтвердите новый пароль"
            />
          </div>
          <div class="body__func">
            <button type="button" class="button-cancel" @click="closeModal">
              Отменить
            </button>
            <button type="submit" :disabled="!isMatch" class="button-save">
              Сохранить
            </button>
          </div>
        </form>
        <div v-if="errors.length > 0" class="errors">
          <ul class="errors__list">
            <li v-for="(error, index) in errors" :key="index">
              <p class="errors__list-item">{{ getErrorMsg(error) }}</p>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import { errorNames } from '~/helpers'

export default {
  data() {
    return {
      passwords: {
        old_password: '',
        new_password: '',
        confirm_new: '',
      },
      errors: [],
    }
  },
  computed: {
    isMatch() {
      return (
        this.passwords.new_password === this.passwords.confirm_new &&
        this.passwords.old_password
      )
    },
  },

  methods: {
    closeModal() {
      this.$emit('onClose')
    },
    async changePassword() {
      try {
        const data = this.passwords
        const res = await this.$axios.post('accounts/password/', data)
        if (res.status === 204) {
          this.$emit('onSuccess')
          this.closeModal()
        }
      } catch (error) {
        this.$emit('onError')
        const errorData = error.response.data
        const errors = []
        Object.entries(errorData).forEach(([key]) => {
          errorData[key].forEach(
            (msg) => errors[length - 1] !== msg && errors.push(msg)
          )
        })
        this.errors = errors
      }
    },
    getErrorMsg(e) {
      return errorNames[e] ? errorNames[e] : 'Что-то пошло не так'
    },
  },
}
</script>

<style lang="scss">
.modal {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10;
  background-color: rgba(0, 0, 0, 0.7);
  font-family: 'Montserrat';

  &__body {
    background-color: #fff;
    border-radius: 10px;
    padding: 35px;
    min-width: 400px;

    input {
      background: #f1f2f3;
      border-radius: 10px;
      padding: 12px 20px;
      width: 100%;
      margin: 10px 0;
    }
    .body__title {
      font-style: normal;
      font-weight: 500;
      font-size: 18px;
      line-height: 22px;
    }
    .body__func {
      justify-content: space-between;
      margin-top: 20px;
      display: flex;
      .button-cancel {
        font-weight: 500;
        border-radius: 10px;
        border: #003a70 1px solid;
        color: #003a70;
        height: 42px;
        width: 100%;
        max-width: 150px;
      }
      .button-save {
        font-weight: 500;
        border-radius: 10px;

        color: #fff;
        background-color: #003a70;
        height: 42px;
        width: 100%;
        max-width: 150px;
        &:disabled {
          cursor: not-allowed;
          opacity: 0.7;
        }
      }
    }
  }
}
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}

.errors {
  margin: 10px 0;
  padding: 10px;
  background-color: #fecaca;
  border-radius: 6px;
  font-weight: 600;
  border: 1px solid #f87171;
  &__list {
    &-item {
      color: #dc2626;
    }
  }
}
</style>
