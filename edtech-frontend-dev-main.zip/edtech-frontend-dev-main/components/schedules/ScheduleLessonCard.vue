<template>
  <div>
    <div class="d-flex littleCard" :class="[subject === ' ' ? 'nop' : '']">
      <div
        class="main-component-text font-weight-bold text-no-wrap overflow-hidden"
      >
        {{ subject }}
      </div>
      <div class="main-component-text text-no-wrap overflow-hidden">
        {{ teacher }}
      </div>
      <div class="main-component-text text-no-wrap overflow-hidden">
        {{ cabinet }} каб.
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ScheduleLessonCard',
  props: {
    subject: {
      type: String,
      default: '',
    },
    teacher: {
      type: String,
      default: '',
    },
    cabinet: {
      type: Number,
      default: 0,
    },
  },
}
</script>

<style lang="scss">
@import '/assets/main';

.littleCard {
  flex-direction: column;
  gap: 10px;
  border-radius: 10px;
  padding: 5px;
  background: #d7f9ef;
  width: 90%;
  min-height: 81px;
}

.nop {
  opacity: 0;
}
</style>
