<template>
  <div class="main-component pt-4">
    <v-tabs>
      <v-tab
        v-if="$auth.user.role === 'student' || $auth.user.role === 'teacher'"
        id="scheduleTab"
        @click="
          setActiveSchedule('schedule')
          emitToPage()
          loadSchedule()
        "
        >Расписание</v-tab
      >
      <v-tab
        v-if="
          $auth.user.role === 'admin' || $auth.user.role === 'class-teacher'
        "
        id="gradesTab"
        @click="
          setActiveSchedule('grade')
          emitToPage()
          schedules = []
        "
        >Классы</v-tab
      >
      <v-tab
        id="bellrangTab"
        @click="
          setActiveSchedule('bellRang')
          emitToPage()
        "
        >Звонки</v-tab
      >
      <v-tab
        v-if="$auth.user.role === 'admin'"
        id="roomTab"
        @click="
          setActiveSchedule('classroom')
          emitToPage()
          schedules = []
        "
        >Кабинеты</v-tab
      >
      <v-tab
        v-if="$auth.user.role === 'admin'"
        id="teacherTab"
        @click="
          setActiveSchedule('teacher')
          emitToPage()
          schedules = []
        "
        >Учителя</v-tab
      >
    </v-tabs>
    <v-divider></v-divider>
    <div
      v-if="warn.length != 0 && activeSchedule !== 'bellRang' && !loading"
      id="warn"
      class="d-flex align-center main-component-text font-weight-bold justify-center fill-height"
    >
      {{ warn }}
    </div>
    <div
      v-if="activeSchedule !== 'bellRang' && schedules.length > 0 && !loading"
      class="schedule-overflow"
    >
      <div
        v-if="activeSchedule !== 'bellRang' && schedules.length > 0 && !loading"
        id="scheduleWrapper"
        class="range-wrap"
      >
        <div class="d-flex flex-column">
          <div
            class="main-component-text font-weight-bold py-5 under text-center"
          >
            №
          </div>
          <div
            v-for="(time, index) in timeTemp"
            id="time"
            :key="'time' + index"
            class="under timewrap"
          >
            <div class="div2 main-component-text">
              {{ time.startTime.substr(0, 5) }} <br />
              {{ time.endTime.substr(0, 5) }}
            </div>
            <div class="div1 big-number">{{ index + 1 }}</div>
          </div>
        </div>
        <div
          v-for="(schedule, scheduleIdx) in schedules"
          :key="'schedule' + scheduleIdx"
          class="d-flex flex-column"
        >
          <div class="main-component-text font-weight-bold py-5 under">
            {{
              `${new Date(Date.parse(schedule.date)).toLocaleString('ru-RU', {
                weekday: 'short',
              })}. ${new Date(Date.parse(schedule.date)).toLocaleString(
                'ru-RU',
                {
                  day: '2-digit',
                }
              )} ${new Date(Date.parse(schedule.date)).toLocaleString('ru-RU', {
                month: 'short',
              })}`
            }}
          </div>
          <div
            v-for="(subject, subjectIdx) in schedule.scheduledSubjects"
            id="lesson"
            :key="'subject' + subjectIdx"
            class="py-4 under"
          >
            <schedule-lesson-card
              :cabinet="subject.classroom.name"
              :subject="subject.subject.name"
              :teacher="
                subject.teacherName
                  ? `${
                      subject.teacherName.lastName
                    } ${subject.teacherName.firstName.substring(0, 1)}`
                  : `${
                      subject.teacher.account.lastName
                    } ${subject.teacher.account.firstName.substring(0, 1)}`
              "
            >
            </schedule-lesson-card>
          </div>
        </div>
      </div>
    </div>
    <div v-if="activeSchedule === 'bellRang'">
      <div v-if="activeSchedule === 'bellRang'" id="bellrang">
        <div class="index-wrapper mt-8">
          <div class="table underl py-4">
            <div class="main-component-text font-weight-bold">№</div>
            <div class="main-component-text font-weight-bold">
              Начало занятия
            </div>
            <div class="main-component-text font-weight-bold">
              Конец занятия
            </div>
            <div class="main-component-text font-weight-bold">
              Длительность перемены
            </div>
          </div>
          <div
            v-for="(item, bellrangIdx) in bellrang"
            :key="'bellrang' + bellrangIdx"
            class="table underl py-4"
          >
            <div class="main-component-text">{{ bellrangIdx + 1 }}</div>
            <div class="main-component-text">
              {{ item.startTime.substring(0, 5) }}
            </div>
            <div class="main-component-text">
              {{ item.endTime.substring(0, 5) }}
            </div>
            <div class="main-component-text">
              {{ item.breakTime.substring(3, 5) }} минут
            </div>
          </div>
        </div>
      </div>
      <v-skeleton-loader
        v-else-if="loading"
        class="mx-auto"
        type="table-tbody"
      ></v-skeleton-loader>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'pinia'
import { useScheduleStore, useBellrangSchedule } from '~/store/schedule'
import { Schedule, ScheduledSubjectByDate, ScheduleTime } from '~/models'
import scheduleLessonCard from '~/components/schedules/ScheduleLessonCard'

export default {
  name: 'ScheduleTable',
  components: {
    scheduleLessonCard,
  },

  props: {
    dataRange: {
      type: Array,
      default: () => [],
    },
    selectedOption: {
      type: String,
      default: '',
    },
  },

  data() {
    return {
      schedulesForFunc: [],
      activeSchedule: '',
      timeTemp: [],
      warn: '',
      schedules: [],
    }
  },
  computed: {
    ...mapState(useScheduleStore, {
      scheduleOrdinary: (store) =>
        ScheduledSubjectByDate.serializeList(store.schedule),
      scheduleExten: (store) => Schedule.serializeList(store.scheduleBy),
      loading: (store) => store.loading,
    }),
    ...mapState(useBellrangSchedule, {
      bellrang: (store) => ScheduleTime.serializeList(store.bellrang),
    }),
  },
  watch: {
    dataRange(range) {
      if (!range.length) {
        console.log('range is empty')
      } else if (range.length) {
        if (this.$auth.user.role === 'class-teacher') {
          if (this.selectedOption === '') {
            this.warn = 'Выберите класс'
          } else {
            this.loadScheduleByDates(
              range,
              this.selectedOption,
              this.activeSchedule
            )
          }
        } else if (this.$auth.user.role === 'admin') {
          if (this.activeSchedule === 'grade') {
            if (this.selectedOption === '') {
              this.warn = 'Выберите класс'
            } else {
              this.loadScheduleByDates(
                range,
                this.selectedOption,
                this.activeSchedule
              )
            }
          } else if (this.activeSchedule === 'classroom') {
            if (this.selectedOption === '') {
              this.warn = 'Выберите кабинет'
            } else {
              this.loadScheduleByDates(
                range,
                this.selectedOption,
                this.activeSchedule
              )
            }
          } else if (this.activeSchedule === 'teacher') {
            if (this.selectedOption === '') {
              this.warn = 'Выберите преподователя'
            } else {
              this.loadScheduleByDates(
                range,
                this.selectedOption,
                this.activeSchedule
              )
            }
          }
        } else if (
          this.$auth.user.role === 'teacher' ||
          this.$auth.user.role === 'student'
        ) {
          this.loadScheduleByDates(range)
        }
      }
    },

    selectedOption(uuid) {
      if (uuid && this.activeSchedule === 'grade') {
        if (this.dataRange.length) {
          this.loadScheduleByGrade(uuid, this.dataRange)
        } else {
          this.loadScheduleByGrade(uuid)
        }
      } else if (uuid && this.activeSchedule === 'classroom') {
        if (this.dataRange.length) {
          this.loadScheduleByClassroom(uuid, this.dataRange)
        } else {
          this.loadScheduleByClassroom(uuid)
        }
      } else if (uuid && this.activeSchedule === 'teacher') {
        if (this.dataRange.length) {
          this.loadScheduleByTeacher(uuid, this.dataRange)
        } else {
          this.loadScheduleByTeacher(uuid)
        }
      }
    },
    scheduleOrdinary(schedule) {
      this.schedulesForFunc = schedule
      this.warn = ''
      this.checkForNull()
      this.lessonsTime(this.schedulesForFunc)
      this.filterSchedule(this.schedulesForFunc)
    },
    scheduleExten(schedule) {
      this.schedulesForFunc = schedule
      this.warn = ''
      this.checkForNull()
      this.getTime(this.schedulesForFunc)
      this.sortScheduleByDates(this.schedulesForFunc)
    },
    schedules() {
      this.warn = ''
      this.checkForNull()
    },
  },

  mounted() {
    if (
      this.$auth.user.role === 'student' ||
      this.$auth.user.role === 'teacher'
    ) {
      this.loadSchedule()
    }
    this.checkForNull()
    this.loadBellrang()
    this.getActiveSchedule()
    this.emitToPage()
  },

  methods: {
    ...mapActions(useScheduleStore, [
      'loadSchedule',
      'loadScheduleByDates',
      'loadScheduleByGrade',
      'loadScheduleByClassroom',
      'loadScheduleByTeacher',
    ]),
    ...mapActions(useBellrangSchedule, ['loadBellrang']),

    emitToPage() {
      this.$emit('tableToPage', this.activeSchedule)
    },

    checkForNull() {
      if (!this.schedules.length) {
        this.warn = 'По данным параметрам расписание не найдено'
      }
    },

    lessonsTime(days) {
      this.timeTemp.length = 0
      days.forEach((item) => {
        item.scheduledSubjects.forEach((lesson) => {
          this.timeTemp.push(lesson.scheduleTime)
        })
      })
      this.sortTime()
    },

    sortTime() {
      this.timeTemp.sort((a, b) =>
        a.startTime > b.startTime ? 1 : b.startTime > a.startTime ? -1 : 0
      )
      this.timeTemp = this.timeTemp.filter(
        (value, index, self) =>
          index ===
          self.findIndex(
            (t) =>
              t.startTime === value.startTime && t.endTime === value.endTime
          )
      )
    },

    filterSchedule(schedule) {
      const test = {
        uuid: ' ',
        subject: {
          uuid: ' ',
          name: ' ',
        },
        classroom: {
          uuid: ' ',
          number: null,
        },
        teacherName: {
          lastName: ' ',
          firstName: '',
        },
        scheduleTime: {
          startTime: ' ',
          endTime: ' ',
        },
      }
      schedule.forEach((day) => {
        if (!day.scheduledSubjects.length) {
          for (const hours of this.timeTemp) {
            test.scheduleTime.startTime = hours.startTime
            schedule[schedule.indexOf(day)].scheduledSubjects.splice(
              this.timeTemp.indexOf(hours),
              0,
              test
            )
          }
        } else {
          for (const subj of day.scheduledSubjects) {
            for (const time of this.timeTemp) {
              if (
                subj.scheduleTime.startTime.localeCompare(time.startTime) < 0 &&
                this.timeTemp.length >
                  schedule[schedule.indexOf(day)].scheduledSubjects.length
              ) {
                test.scheduleTime.startTime = time.startTime
                schedule[schedule.indexOf(day)].scheduledSubjects.splice(
                  day.scheduledSubjects.indexOf(subj) + 1,
                  0,
                  test
                )
              } else if (
                subj.scheduleTime.startTime.localeCompare(time.startTime) > 0 &&
                this.timeTemp.length >
                  schedule[schedule.indexOf(day)].scheduledSubjects.length
              ) {
                test.scheduleTime.startTime = time.startTime
                schedule[schedule.indexOf(day)].scheduledSubjects.splice(
                  day.scheduledSubjects.indexOf(subj),
                  0,
                  test
                )
              } else if (
                subj.scheduleTime.startTime.localeCompare(time.startTime) === 0
              ) {
                continue
              }
            }
          }
        }
      })
      this.schedules = schedule
    },

    getActiveSchedule() {
      if (
        this.$auth.user.role === 'student' ||
        this.$auth.user.role === 'teacher'
      ) {
        this.activeSchedule = 'schedule'
      } else {
        this.activeSchedule = 'grade'
      }
    },

    getTime(schedule) {
      this.timeTemp.length = 0
      schedule.forEach((subj) => {
        this.timeTemp.push(subj.scheduleTime)
      })
      this.sortTime()
    },

    sortScheduleByDates(schedule) {
      const dates = []
      let subjects = []
      let daySubj = {
        date: '',
        scheduledSubjects: [],
      }
      const sortedSchedule = []
      schedule.forEach((subj) => {
        if (!dates.includes(subj.date)) {
          dates.push(subj.date)
        }
      })
      dates.forEach((day) => {
        daySubj = {
          date: '',
          scheduledSubjects: [],
        }
        subjects = []
        schedule.forEach((subj) => {
          if (day === subj.date) {
            subjects.push(subj)
          }
        })
        daySubj = { date: day, scheduledSubjects: subjects }
        sortedSchedule.push(daySubj)
      })
      this.schedule = sortedSchedule
      this.filterSchedule(this.schedule)
    },

    setActiveSchedule(value) {
      if (this.$auth.user.role === 'admin') {
        this.schedules = []
      }
      this.warn = ''
      this.activeSchedule = value
    },
  },
}
</script>
