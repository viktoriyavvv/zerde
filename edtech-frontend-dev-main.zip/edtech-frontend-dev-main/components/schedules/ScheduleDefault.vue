<template>
  <div class="main-component -w100">
    <div class="main-component-title">
      Расписание
      <span class="grayColor main-component-title font-weight-medium">{{
        dateNow.replace(/T.*/, '').split('-').reverse().join('.')
      }}</span>
    </div>
    <v-layout v-if="schedule[0]" class="wrapper">
      <v-flex
        v-for="(item, index) in schedule[0].scheduledSubjects"
        :key="index"
        class="lessonWrap"
      >
        <div class="main-component-text font-weight-bold">
          {{ index + 1 }}. {{ item.subject.name }}
        </div>
        <div class="main-component-text">
          {{ item.teacherName.lastName }}
          {{ item.teacherName.firstName.charAt(0) + '.' }}
        </div>
        <div class="main-component-text">
          {{ item.scheduleTime.startTime.substr(0, 5) }} -
          {{ item.scheduleTime.endTime.substr(0, 5)
          }}<span class="room">{{ item.classroom.number }} каб.</span>
        </div>
      </v-flex>
    </v-layout>
    <div v-else id="warn" class="ml-5 my-4 subtitle-text">
      На сегодня расписания нет
    </div>
  </div>
</template>

<script>
import { mapState, mapActions, mapStores } from 'pinia'
import { useScheduleStore } from '~/store/schedule'
import { ScheduledSubjectByDate } from '~/models'

export default {
  name: 'ScheduleDefault',
  data() {
    return {
      dateNow: new Date().toISOString().split('T')[0],
    }
  },

  computed: {
    ...mapStores(useScheduleStore),
    ...mapState(useScheduleStore, {
      schedule: (store) =>
        ScheduledSubjectByDate.serializeList(store.scheduleDay),
    }),
  },

  mounted() {
    this.loadScheduleByDate(this.dateNow)
  },
  methods: {
    ...mapActions(useScheduleStore, ['loadScheduleByDate']),
  },
}
</script>
<style lang="scss">
@import '../../assets/main';

.-w100 {
  width: 100%;
}

.lessonWrap {
  border: 1px solid #e8e8e8;
  box-sizing: border-box;
  border-radius: 10px;
  padding: 15px;
  display: grid;
  gap: 8px;
  grid-auto-columns: max-content;
  max-width: max-content;
}

.wrapper {
  margin-top: 15px;
  gap: 20px;
  overflow: auto;
  padding-bottom: 20px;
}

.room {
  margin-left: 20px;
}

::-webkit-scrollbar {
  height: 3px;
}

::-webkit-scrollbar-track {
  background: #e8e8e8;
  border-radius: 40px;
}

::-webkit-scrollbar-thumb {
  background: #313131;
  border-radius: 40px;
}
</style>
