<template>
  <div id="scheduleActions" class="main-component">
    <div class="title-component">Действия</div>
    <div class="mt-5">
      <div v-if="state !== 'bellRang'">
        <div class="subtitle-text blueColor text-center">Четверть</div>
        <div class="d-flex gap14 mb-5 mt-4 justify-center flex-wrap">
          <button
            class="main-component-text buttonBlueBorder"
            color="transparent"
            :disabled="!terms[0]"
            :class="{
              btnBlueBorderActive: activeTerm === 0,
              grayColor: !terms[0],
              grayBorder: !terms[0],
            }"
            @click="setActiveTerm(0)"
          >
            1
          </button>
          <button
            class="main-component-text buttonBlueBorder"
            color="transparent"
            :disabled="!terms[1]"
            :class="{
              btnBlueBorderActive: activeTerm === 1,
              grayColor: !terms[2],
              grayBorder: !terms[1],
            }"
            @click="setActiveTerm(1)"
          >
            2
          </button>
          <button
            class="main-component-text buttonBlueBorder"
            color="transparent"
            :disabled="!terms[2]"
            :class="{
              btnBlueBorderActive: activeTerm === 2,
              grayColor: !terms[2],
              grayBorder: !terms[2],
            }"
            @click="setActiveTerm(2)"
          >
            3
          </button>
          <button
            class="main-component-text buttonBlueBorder"
            color="transparent"
            :disabled="!terms[3]"
            :class="{
              btnBlueBorderActive: activeTerm === 3,
              grayColor: !terms[3],
              grayBorder: !terms[3],
            }"
            @click="setActiveTerm(3)"
          >
            4
          </button>
        </div>
      </div>
      <v-menu
        v-if="state !== 'bellRang'"
        ref="menu"
        v-model="menu"
        :close-on-content-click="false"
        transition="scale-transition"
        offset-y
        min-width="auto"
      >
        <template #activator="{ on, attrs }">
          <div
            class="d-flex blueBorder d-flex align-center py-3 px-4 justify-space-between mb-4"
            v-bind="attrs"
            v-on="on"
          >
            <div class="main-component-text blueColor">
              <span v-if="!dates.length" class="main-component-text blueColor"
                >Выберите даты</span
              >
              <span v-else class="main-component-text blueColor"
                >{{ formattedDate[0] }} - {{ formattedDate[1] }}</span
              >
            </div>
            <img src="@/assets/images/Calendar.svg" />
          </div>
        </template>
        <v-date-picker
          v-model="dates"
          no-title
          scrollable
          range
          locale="ru-RU"
          first-day-of-week="1"
        >
        </v-date-picker>
      </v-menu>
      <div class="d-flex flex-column gap20">
        <drop-down-element
          v-show="
            state === 'grade' ||
            ($nuxt.$auth.user.role === 'class-teacher' && state === 'schedule')
          "
          class="main-component-text"
          type="grades"
          :options="grades"
          :default="classDefault"
          :reset="state === 'grade' ? false : true"
          @input="receiveOption"
        ></drop-down-element>
        <drop-down-element
          v-show="state === 'classroom'"
          class="main-component-text"
          type="numbers"
          :options="rooms"
          :default="classroomDefault"
          :reset="state === 'classroom' ? false : true"
          @input="receiveOption"
        ></drop-down-element>
        <drop-down-element
          v-show="state === 'teacher'"
          class="main-component-text"
          type="teacher"
          :options="teachers"
          :default="teacherDefault"
          :reset="state === 'teacher' ? false : true"
          @input="receiveOption"
        ></drop-down-element>
        <div class="buttonGrid">
          <button
            class="borderRadius blueColor buttonBlueBorder d-flex align-center justify-center"
          >
            <img src="~/assets/images/exel-icon.svg" />
          </button>
          <button
            class="borderRadius blueColor buttonBlueBorder d-flex align-center justify-center"
            @click="pressPrint"
          >
            <img src="~/assets/images/printer-icon.svg" />
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapStores, mapActions } from 'pinia'
import { useTermStore } from '~/store/term'
import {
  useClassTeacherGradesStore,
  useTeacherListStore,
  useClassroomStore,
} from '~/store'
import { Term } from '~/models/term.model'
import { Classroom, StudentGrade, TeacherProfileList } from '~/models'
import DropDownElement from '~/components/main/DropDownElement'

export default {
  name: 'ScheduleActions',
  components: { DropDownElement },
  props: {
    state: {
      type: String,
      default: '',
    },
  },
  data: () => ({
    dates: [],
    menu: false,
    classDefault: 'Выберите класс',
    teacherDefault: 'Выберите преподователя',
    classroomDefault: 'Выберите кабинет',
    selectedOption: '',
    activeTerm: '',
  }),

  computed: {
    ...mapStores(useTermStore),
    ...mapStores(useClassroomStore),
    ...mapStores(useClassTeacherGradesStore),
    ...mapStores(useTeacherListStore),
    ...mapState(useTermStore, {
      terms: (store) => Term.serializeList(store.terms),
    }),
    ...mapState(useClassTeacherGradesStore, {
      grades: (store) => StudentGrade.serializeList(store.gradeList),
    }),
    ...mapState(useClassroomStore, {
      rooms: (store) => Classroom.serializeList(store.classroomList),
    }),
    ...mapState(useTeacherListStore, {
      teachers: (store) => TeacherProfileList.serializeList(store.teacherList),
    }),
    formattedDate() {
      const options = {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }
      const firstDate = new Date(Date.parse(this.dates[0])).toLocaleDateString(
        'ru-RU',
        options
      )
      const secondDate = new Date(Date.parse(this.dates[1])).toLocaleDateString(
        'ru-RU',
        options
      )
      return [firstDate, secondDate]
    },
  },

  watch: {
    dates() {
      this.emitToTable()
    },
    selectedOption() {
      if (this.selectedOption || this.selectedOption === '') {
        this.$emit('getSelected', this.selectedOption)
      }
    },
    state() {
      this.dates.length = 0
      this.activeTerm = ''
      this.selectedOption = ''
    },
  },

  mounted() {
    this.loadTerms()
    if (
      this.$nuxt.$auth.user.role === 'class-teacher' ||
      this.$nuxt.$auth.user.role === 'admin'
    ) {
      this.loadGrade()
    }
    if (this.$nuxt.$auth.user.role !== 'student') {
      this.loadClassroom()
    }
    if (this.$nuxt.$auth.user.role === 'admin') {
      this.loadTeachers()
    }
  },

  methods: {
    ...mapActions(useTermStore, ['loadTerms']),
    ...mapActions(useClassTeacherGradesStore, ['loadGrade']),
    ...mapActions(useClassroomStore, ['loadClassroom']),
    ...mapActions(useTeacherListStore, ['loadTeachers']),

    emitToTable() {
      this.$emit('actionToTable', this.dates)
    },

    changeDates(index) {
      this.dates.length = 0
      this.dates.push(this.terms[index].startDate)
      this.dates.push(this.terms[index].endDate)
    },

    receiveOption(value) {
      this.selectedOption = value.uuid
    },

    setActiveTerm(index) {
      if (this.activeTerm === index) {
        this.dates.length = 0
        this.activeTerm = ''
      } else {
        this.changeDates(index)
        this.activeTerm = index
      }
    },

    pressPrint() {
      window.print()
    },
  },
}
</script>

<style lang="scss">
@import '/assets/main';
</style>
