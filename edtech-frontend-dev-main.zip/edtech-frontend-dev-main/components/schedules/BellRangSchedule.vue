<template>
  <div class="index-wrapper mt-8">
    <div class="main-component inner">
      <div class="table underl py-4">
        <div class="main-component-text">№</div>
        <div class="main-component-text">Начало занятия</div>
        <div class="main-component-text">Конец занятия</div>
        <div class="main-component-text">Длительность перемены</div>
      </div>
      <div class="table underl py-4">
        <div class="main-component-text">1</div>
        <div class="main-component-text">07:35</div>
        <div class="main-component-text">08:15</div>
        <div class="main-component-text">5 минут</div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions, mapStores } from 'pinia'
import { useBellrangSchedule } from '~/store'
import { Bellrang } from '~/models/bellrang.model'

export default {
  name: 'BellRangSchedule',
  computed: {
    ...mapStores(useBellrangSchedule),
    ...mapState(useBellrangSchedule, {
      bellrangSchedule: (store) => Bellrang.serializeList(store.bellrang),
    }),
  },

  mounted() {
    this.loadBellrang()
  },

  methods: {
    ...mapActions(useBellrangSchedule, ['loadBellrang']),
  },
}
</script>

<style lang="scss">
@import '/assets/main';

.table {
  display: grid;
  grid-template-columns: 0.4fr repeat(4, 1fr);
}

.underl {
  border-bottom: 1px solid #e5e5e5;
}

.index-wrapper {
  position: relative;
  z-index: 1;
}

.inner {
  position: relative;
}

.inner:before {
  content: '';
  display: inline-block;
  width: 100%;
  height: 25px;
  background: #e5e5e5;
  position: absolute;
  z-index: -1;
  border-radius: 10px 10px 0 0;
  left: 0;
  top: -15px;
}
</style>
