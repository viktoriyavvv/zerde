<template>
  <main>
    <div v-if="!loading" id="replies">
      <div class="list-table py-4">
        <div class="main-component-text font-weight-bold">№</div>
        <div class="main-component-text font-weight-bold">ФИО</div>
        <div class="main-component-text font-weight-bold">Материалы</div>
        <div class="main-component-text font-weight-bold">
          Комментарий ученика
        </div>
        <div class="main-component-text font-weight-bold">
          Комментарий к работе
        </div>
        <div class="main-component-text font-weight-bold">Оценка</div>
        <div
          v-if="!readonly"
          class="main-component-text font-weight-bold text-center"
        >
          Действия
        </div>
      </div>
      <div class="over-flow">
        <div
          v-for="(answer, index) in homework.replies"
          :key="index"
          class="list-table py-3"
          :class="selectedLine === answer.uuid ? 'collapse' : 'align-center'"
        >
          <div class="main-component-text">{{ index + 1 }}</div>
          <div class="main-component-text">
            {{ answer.userAccount.firstName }}
            {{ answer.userAccount.lastName.substring(0, 1) }}
          </div>
          <div
            v-if="answer.studentAssignmentReplies.length > 0"
            class="main-component-text d-flex"
          >
            <a
              v-for="(item, fileIndex) in answer.studentAssignmentReplies[0]
                .attached_files"
              :key="'attachFile' + fileIndex"
              class="gray-bg pa-2 mr-2 flex-wrap"
              :href="item.file"
              target="_blank"
            >
              <img src="@/assets/images/Document.svg" />
            </a>
          </div>
          <div v-else class="main-component-text"></div>
          <div
            v-if="answer.studentAssignmentReplies.length > 0"
            class="main-component-text mr-10"
            :class="
              selectedLine === answer.uuid
                ? 'focus-change'
                : 'overflow-ellipsis'
            "
          >
            <div
              v-for="(file, answerIndex) in answer.studentAssignmentReplies"
              :key="'answer' + answerIndex"
            >
              {{ file.comment }}
            </div>
          </div>
          <div v-else class="main-component-text mr-10 overflow-ellipsis"></div>
          <div
            class="main-component-text overflow-y-auto"
            @click="collapse(answer.uuid)"
          >
            <div
              ref="comment"
              class="mr-10"
              :class="
                selectedLine === answer.uuid
                  ? 'focus-change'
                  : 'overflow-ellipsis'
              "
              :contenteditable="selectedLine === answer.uuid && !readonly"
            >
              {{ answer.mark.comment }}
            </div>
          </div>
          <div class="main-component-text" @click="collapse(answer.uuid)">
            <span
              ref="mark"
              class="focus-change"
              :contenteditable="selectedLine === answer.uuid && !readonly"
              @keypress="checkForMark"
              >{{ answer.mark.markValue }}</span
            >

            / 10
          </div>
          <div
            v-if="!readonly"
            id="postMark"
            class="main-component-text d-flex justify-center"
            @click="getData(index, answer.mark.uuid, answer.uuid)"
          >
            <div class="gray-bg pa-2">
              <img src="@/assets/images/TickSquare.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <v-skeleton-loader
      v-else
      class="mx-auto"
      type="table-tbody"
    ></v-skeleton-loader>
  </main>
</template>

<script>
import { mapActions, mapStores, mapState } from 'pinia'
import { useHomeworkStore } from '~/store'
import { SelectedHomeworkTeacher } from '~/models/homework.model'

export default {
  name: 'HomeworkListCheck',
  data() {
    return {
      isActive: false,
      replyStudList: [],
      selectedLine: '',
    }
  },

  computed: {
    ...mapStores(useHomeworkStore),
    ...mapState(useHomeworkStore, {
      homework: (store) =>
        SelectedHomeworkTeacher.serialize(store.selectedHomework),
      loading: (store) => store.loading,
    }),
    readonly() {
      if (
        this.homework.state === 'issued' &&
        (this.$nuxt.$auth.user.role === 'teacher' ||
          this.$nuxt.$auth.user.role === 'admin')
      ) {
        return false
      } else {
        return true
      }
    },
  },

  async mounted() {
    await this.setSelectedHomework(this.$route.params.id)
  },

  methods: {
    ...mapActions(useHomeworkStore, [
      'setSelectedHomework',
      'rateHomework',
      'editHomeworkMark',
    ]),

    collapse(id) {
      if (
        this.$nuxt.$auth.user.role === 'teacher' ||
        this.$nuxt.$auth.user.role === 'admin'
      ) {
        this.selectedLine = id
      }
    },

    closeLine() {
      this.selectedLine = ' '
    },

    getData(index, id, studentId) {
      this.closeLine()
      if (id) {
        const comment = this.$refs.comment[index].textContent
        const mark = this.$refs.mark[index].textContent
        const answerID = id
        this.editHomeworkMark(comment, mark, answerID)
      } else {
        const student = studentId
        const comment = this.$refs.comment[index].textContent
        const mark = this.$refs.mark[index].textContent
        const homework = this.homework.uuid
        if (mark !== '') {
          this.rateHomework(student, comment, mark, homework)
        }
      }
    },

    checkForMark(e) {
      const mark = e.target.innerText
      const keyCode = e.keyCode ? e.keyCode : e.which
      if (keyCode < 48 || keyCode > 57 || mark.length > 1) {
        e.preventDefault()
      }
    },
  },
}
</script>

<style lang="scss">
.list-table {
  display: grid;
  grid-template-columns: 0.15fr 0.7fr 0.6fr 1fr 1fr 0.35fr 0.3fr;
  border-bottom: 1px solid #e5eaee;
}

.gray-bg {
  display: flex;
  background: #f5f6fa;
  border-radius: 6px;
  height: max-content;
  width: fit-content;
  cursor: pointer;
}

.overflow-ellipsis {
  max-height: 35px;
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
}

.collapse {
  min-height: 100px;
  height: max-content;
}

.focus-change {
  height: 150px;
  overflow-y: scroll;

  &:focus-visible {
    outline: none;
    background: #f5f6fa;
    border-radius: 5px;
    padding: 10px;
  }
}

.over-flow {
  max-height: 80vh;
  overflow-y: scroll;
}
</style>
