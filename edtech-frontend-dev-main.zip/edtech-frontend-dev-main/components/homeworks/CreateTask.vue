<template>
  <aside class="main-component">
    <div v-if="!loading" class="d-flex flex-column max-height">
      <div class="title-component">
        {{ createMode ? 'Создание задания' : 'Домашнее задание' }}
      </div>
      <div class="d-flex flex-column justify-space-between max-height">
        <div class="task-form d-flex flex-column mt-4">
          <drop-down-element
            v-if="createMode"
            type="subjects"
            :options="subjectList"
            :default="subjectDefault"
            :error="subjectValidation"
            class="main-component-text"
            @input="writeSubjectHw"
          ></drop-down-element>
          <div
            v-if="!subjectValidation"
            class="mt-2 text-center main-component-text-little red-color"
          >
            Выберите предмет
          </div>
          <drop-down-element
            v-if="createMode"
            type="grades"
            :options="gradeList"
            :default="gradeDefault"
            :error="gradeValidation"
            class="main-component-text mt-4"
            @input="writeGradeHw"
          ></drop-down-element>
          <div
            v-if="!gradeValidation"
            class="mt-2 text-center main-component-text-little red-color"
          >
            Выберите класс
          </div>
          <drop-down-element
            v-if="createMode && typeof gradeHw !== 'string'"
            type="grades"
            :options="gradeGroupList"
            :default="gradeGroupDefault"
            class="main-component-text mt-4"
            @input="writeGradeGroupHw"
          ></drop-down-element>
          <drop-down-element
            v-if="createMode && $auth.user.role === 'admin'"
            type="teacher"
            :options="teacherProfiles"
            :default="teacherDefault"
            :error="teacherValidation"
            class="main-component-text mt-4"
            @input="writeTeacherHw"
          ></drop-down-element>
          <div
            v-if="!teacherValidation"
            class="mt-2 text-center main-component-text-little red-color"
          >
            Выберите преподователя
          </div>
          <div v-else-if="!createMode || patchMode" id="viewMode">
            <div class="blueBorder blueColor py-3 main-component-text pl-5">
              {{ selectedHomework.subject }}
            </div>
            <div
              class="blueBorder blueColor py-3 main-component-text pl-5 mt-4"
            >
              {{ selectedHomework.grade }}
            </div>
            <div
              v-if="selectedHomework.gradeGroup"
              class="blueBorder blueColor py-3 main-component-text pl-5 mt-4"
            >
              {{ selectedHomework.gradeGroup }}
            </div>
          </div>
          <v-menu
            ref="menu"
            v-model="menu"
            :close-on-content-click="false"
            transition="scale-transition"
            offset-y
            min-width="auto"
            :disabled="readonly"
          >
            <template #activator="{ on, attrs }">
              <div
                class="d-flex blueBorder d-flex align-center my-4 py-3 px-4 justify-space-between"
                v-bind="attrs"
                v-on="on"
              >
                <div class="main-component-text blueColor">
                  {{ formattedDate }}
                </div>
                <img src="@/assets/images/Calendar.svg" />
              </div>
            </template>
            <v-date-picker
              v-model="deadlineDate"
              no-title
              scrollable
              locale="ru-RU"
              first-day-of-week="1"
              :readonly="readonly"
            >
            </v-date-picker>
          </v-menu>
          <div class="subtitle-text mt-4">Описание</div>
          <textarea
            v-model="description"
            :readonly="readonly"
            class="txt-area mt-2 mb-4 main-component-text"
          />
          <div class="subtitle-text">Прикладываемые материалы</div>
          <input
            id="attachedFiles"
            ref="attachedFiles"
            type="file"
            name="attachedFiles"
            class="mt-2 invisible"
            multiple
            @change="addFile"
          />
          <div
            v-if="attachedFiles.length > 0 || selectedHomework"
            class="d-flex mt-2 flex-column"
          >
            <div
              class="grayBorder borderRadius pa-2 main-component-text grayColor pa-3 available d-flex flex-column"
            >
              <div v-if="selectedHomework">
                <div v-if="typeof selectedHomework.attachedFiles !== 'object'">
                  <div
                    v-for="(
                      attachedFile, index
                    ) in selectedHomework.attachedFiles"
                    :key="index"
                  >
                    <a
                      :href="attachedFile.file"
                      target="_blank"
                      class="text-break grayColor my-3 d-block"
                      >{{ attachedFile.name }}</a
                    >
                  </div>
                </div>

                <div v-else class="main-component-text">
                  Нет приложенных файлов
                </div>
              </div>
              <div
                v-for="(file, index) in attachedFiles"
                :key="index"
                class="my-2 d-flex align-center"
              >
                <div class="file-name">{{ file.name }}</div>
                <div class="del" @click="deleteFile(index)">
                  <img src="@/assets/images/deleteDD.svg" />
                </div>
              </div>
            </div>
            <div
              v-if="!fileValidation"
              class="mt-2 text-center main-component-text-little red-color"
            >
              Длина названия файла более 64 символов
            </div>
          </div>
          <label
            v-if="!readonly"
            for="attachedFiles"
            class="buttonBlueBorder blueColor main-component-text noActiveBlueBtn mt-2 mb-5"
            >Добавить файлы</label
          >
        </div>
        <div class="d-flex flex-column">
          <div class="d-flex flex-column">
            <button
              v-if="createMode"
              id="createBtn"
              class="buttonBlueBorder main-component-text"
              @click="
                changeHwState('not_issued')
                homeworkValidation()
                saveFiles()
              "
            >
              Сохранить
            </button>
            <button
              v-if="!readonly"
              id="postBtn"
              class="buttonBlueBorder main-component-text"
              :class="!readonly ? 'my-4' : ''"
              @click="
                changeHwState('issued')
                homeworkValidation()
                saveFiles()
              "
            >
              Опубликовать
            </button>
            <button
              v-if="
                readonly &&
                ($auth.user.role === 'teacher' ||
                  $auth.user.role === 'admin') &&
                !isFinished
              "
              class="buttonBlueBorder main-component-text"
              @click="changeHwState('finished'), finishHW()"
            >
              В архив
            </button>
          </div>
          <button
            class="buttonBlueBorder main-component-text mt-4 blueColor"
            @click="closeHW()"
          >
            Назад
          </button>
        </div>
      </div>
    </div>
    <v-skeleton-loader
      v-else
      class="main-component"
      type="article"
    ></v-skeleton-loader>
  </aside>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import {
  useHomeworkStore,
  useSubjectStore,
  useGradeStore,
  useAdminStore,
} from '~/store'
import DropDownElement from '~/components/main/DropDownElement'
import { Subject } from '~/models/subject.model'
import { TeacherProfileList } from '~/models/schedule.model'

export default {
  name: 'CreateTask',
  components: {
    DropDownElement,
  },
  props: {
    selectedHomework: {
      type: Object,
      required: false,
      default: () => {},
    },
    createMode: {
      type: Boolean,
    },
    patchMode: {
      type: Boolean,
    },
    tabValue: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      hwState: 'issued',
      subjectHw: '',
      gradeHw: '',
      gradeGroupHw: '',
      teacherHw: '',
      subjectDefault: 'Выберите предмет',
      gradeGroupDefault: 'Выберите группу',
      gradeDefault: 'Выберите класс',
      teacherDefault: 'Выберите преподавателя',
      selectedGroup: '',
      menu: false,
      attachedFiles: [],
      readonly: true,
      isFinished: false,
      deadlineDate: '',
      description: '',
      validationState: true,
      subjectValidation: true,
      gradeValidation: true,
      teacherValidation: true,
      fileValidation: true,
    }
  },
  computed: {
    ...mapState(useHomeworkStore, ['filesUuid']),
    ...mapState(useHomeworkStore, {
      files: (store) => store.filesID,
      loading: (store) => store.loading,
    }),
    ...mapState(useAdminStore, {
      teacherProfiles: (store) =>
        TeacherProfileList.serializeList(store.teacherProfiles),
    }),

    ...mapState(useSubjectStore, {
      subjectList: (store) => Subject.serializeList(store.subjects),
    }),
    ...mapState(useGradeStore, {
      gradeList: (store) => store.gradeList,
      gradeGroupList: (store) => store.gradeGroupList,
    }),
    groupNameList() {
      const groupNameList = []
      this.groupList.forEach((item) => {
        groupNameList.push(item.name)
      })
      return groupNameList
    },
    formattedDate() {
      const options = {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }
      return new Date(Date.parse(this.deadlineDate)).toLocaleDateString(
        'ru-RU',
        options
      )
    },
  },

  watch: {
    gradeHw(grade) {
      this.loadGradeGroupList(grade.uuid)
    },
  },

  async mounted() {
    if (this.$route.params.id) {
      await this.setSelectedHomework(this.$route.params.id)
    }
    await this.prepareDate()
    await this.prepareDescription()
    this.setReadonly()
    this.setHWmode()
    if (this.$auth.user.role === 'admin') {
      this.loadTeacherProfile()
    }
  },

  methods: {
    prepareDate() {
      if (this.selectedHomework) {
        this.deadlineDate = this.selectedHomework.deadline
      } else {
        this.deadlineDate = new Date(
          Date.now() - new Date().getTimezoneOffset() * 60000
        )
          .toISOString()
          .substr(0, 10)
      }
    },
    prepareDescription() {
      if (this.selectedHomework) {
        this.description = this.selectedHomework.description
      } else {
        this.description = ''
      }
    },
    changeHwState(state) {
      this.hwState = state
    },
    writeSubjectHw(selected) {
      this.subjectHw = selected
    },
    writeGradeHw(selected) {
      this.gradeHw = selected
    },
    writeGradeGroupHw(selected) {
      this.gradeGroupHw = selected
    },
    writeTeacherHw(selected) {
      this.teacherHw = selected
    },
    ...mapActions(useHomeworkStore, [
      'editSelectedHomework',
      'createHomework',
      'uploadFiles',
      'setCreateMode',
      'setHomework',
      'editHomework',
      'setPatchMode',
      'setCreateMode',
      'setSelectedHomework',
    ]),
    ...mapActions(useHomeworkStore, ['saveFile']),
    getOption(value) {
      this.selectedGroup = value
    },
    ...mapActions(useAdminStore, ['loadTeacherProfile']),
    ...mapActions(useGradeStore, ['loadGradeGroupList']),

    addFile(e) {
      const droppedFiles = e.target.files
      if (!droppedFiles) return
      ;[...droppedFiles].forEach((file) => {
        this.attachedFiles.push(file)
      })
    },

    deleteFile(fileKey) {
      this.attachedFiles.splice(fileKey, 1)
    },

    attachFiles() {
      const emptyFiles = []
      this.attachedFiles.forEach((file) => {
        const emptyFile = {
          file_name: file.name,
          file,
        }
        if (emptyFile.file instanceof File) {
          emptyFiles.push(emptyFile)
        }
      })
      if (emptyFiles !== this.filesUuid) {
        this.saveFile(emptyFiles)
      }
    },

    finishHW() {
      if (this.selectedHomework) {
        const postDataAttached = {
          state: this.hwState,
        }
        this.editHomework(postDataAttached, this.$route.params.id)
      }
    },

    saveFiles() {
      if (this.validationState) {
        if (this.selectedHomework) {
          if (this.attachedFiles.length) {
            const postDataAttached = {
              description: this.description,
              attached_files: this.attachedFiles,
              deadline: this.deadlineDate,
              state: this.hwState,
            }
            this.editHomework(postDataAttached, this.$route.params.id)
            this.setHomework(this.tabValue)
          } else {
            const postDataWithOutFiles = {
              description: this.description,
              deadline: this.deadlineDate,
              state: this.hwState,
            }
            this.editHomework(postDataWithOutFiles, this.$route.params.id)
            this.setHomework(this.tabValue)
          }
        } else if (this.teacherHw.uuid) {
          if (typeof this.gradeGroupHw === 'string') {
            const postDataAdmin = {
              teacher_profile: this.teacherHw.uuid,
              subject: this.subjectHw.uuid,
              grade: this.gradeHw.uuid,
              description: this.description,
              attached_files: this.attachedFiles,
              deadline: this.deadlineDate,
              assignment_type: 'homework',
              state: this.hwState,
            }
            this.createHomework(postDataAdmin)
          } else {
            const postDataAdmin = {
              teacher_profile: this.teacherHw.uuid,
              subject: this.subjectHw.uuid,
              grade: this.gradeHw.uuid,
              grade_group: this.gradeGroupHw.uuid,
              description: this.description,
              attached_files: this.attachedFiles,
              deadline: this.deadlineDate,
              assignment_type: 'homework',
              state: this.hwState,
            }
            this.createHomework(postDataAdmin)
          }

          this.setCreateMode(false)
          this.setHomework(this.tabValue)
        } else {
          if (typeof this.gradeGroupHw === 'string') {
            const postData = {
              subject: this.subjectHw.uuid,
              grade: this.gradeHw.uuid,
              description: this.description,
              attached_files: this.attachedFiles,
              deadline: this.deadlineDate,
              assignment_type: 'homework',
              state: this.hwState,
            }
            this.createHomework(postData)
          } else {
            const postData = {
              subject: this.subjectHw.uuid,
              grade_group: this.gradeGroupHw.uuid,
              grade: this.gradeHw.uuid,
              description: this.description,
              attached_files: this.attachedFiles,
              deadline: this.deadlineDate,
              assignment_type: 'homework',
              state: this.hwState,
            }
            this.createHomework(postData)
          }

          this.setCreateMode(false)
          this.setHomework(this.tabValue)
        }
      }
    },

    homeworkValidation() {
      this.subjectValidation = true
      this.gradeValidation = true
      this.validationState = true
      this.teacherValidation = true
      this.fileValidation = true

      this.attachedFiles.forEach((attachedFile) => {
        if (attachedFile.name.length > 64) {
          this.fileValidation = false
          this.validationState = false
        }
      })

      if (this.$auth.user.role === 'admin') {
        if (
          this.subjectHw === this.subjectDefault ||
          this.gradeHw === this.gradeDefault ||
          this.teacherHw === this.teacherDefault
        ) {
          this.validationState = false
        }
        if (this.subjectHw === this.subjectDefault) {
          this.subjectValidation = false
        }
        if (this.gradeHw === this.gradeDefault) {
          this.gradeValidation = false
        }
        if (this.teacherHw === this.teacherDefault) {
          this.teacherValidation = false
        }
      } else {
        if (
          this.subjectHw === this.subjectDefault ||
          this.gradeHw === this.gradeDefault
        ) {
          this.validationState = false
        }
        if (this.subjectHw === this.subjectDefault) {
          this.subjectValidation = false
        }
        if (this.gradeHw === this.gradeDefault) {
          this.gradeValidation = false
        }
      }
    },

    setReadonly() {
      if (
        this.$auth.user.role === 'teacher' ||
        this.$auth.user.role === 'admin'
      ) {
        if (this.selectedHomework !== undefined) {
          if (
            this.selectedHomework.state === 'finished' ||
            this.selectedHomework.state === 'issued'
          ) {
            this.readonly = true
          } else {
            this.readonly = false
          }
        } else {
          this.readonly = false
        }
      } else {
        this.readonly = true
      }
    },

    setHWmode() {
      if (
        this.$auth.user.role === 'teacher' ||
        this.$auth.user.role === 'admin'
      ) {
        if (this.selectedHomework) {
          if (this.selectedHomework.state === 'finished') {
            this.isFinished = true
          }
        }
      }
    },
    closeHW() {
      if (this.createMode) {
        this.setCreateMode(false)
      } else {
        this.$router.push('/teacher/Homework')
        this.setPatchMode(false)
      }
    },
  },
}
</script>

<style lang="scss">
.max-height {
  height: 100%;
}

.txt-input {
  width: 100%;
  height: 42px;
  background: #f1f2f3;
  border-radius: 10px;
  padding: 12px 20px;

  &:active,
  &:focus-visible {
    outline: none;
  }
}

.txt-area {
  width: 323px;
  resize: none;
  border: 1px solid #e5e5e5;
  border-radius: 10px;
  height: 100px;
  padding: 10px;

  &:active,
  &:focus-visible {
    outline: none;
  }
}

.invisible {
  width: 0.1px;
  height: 0.1px;
  opacity: 0;
  overflow: hidden;
  position: absolute;
  z-index: -1;
}

.file-name {
  width: 95%;
  word-break: break-all;
}

.del {
  width: 5%;
  cursor: pointer;
}

.red-color {
  color: #ff2e2e;
}
</style>
