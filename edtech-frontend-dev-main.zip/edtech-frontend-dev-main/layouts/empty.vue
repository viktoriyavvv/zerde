<template>
  <v-app>
    <v-main>
      <div class="content">
        <div class="content__logo">
          <img src="~/assets/images/logo/logo-image.svg" alt="" />
          <img src="~/assets/images/logo/logo-text.svg" alt="" />
        </div>
        <div class="content__text">Система управления обучением</div>
        <div class="content__background"></div>
      </div>
      <v-container class="fill-height blue-back">
        <Nuxt />
      </v-container>
    </v-main>
  </v-app>
</template>

<script>
export default {
  name: 'EmptyLayout',
}
</script>

<style lang="scss">
.v-main__wrap {
  display: flex;
  .content {
    padding: 183px 0 0 0;
    margin: 0 auto;
    flex: 0 0 36.6%;
    position: relative;
    overflow: hidden;
    background: #003a70;
    border-radius: 0;
    &__logo {
      :not(:last-child) {
        margin-bottom: 10px;
      }
      img {
        display: block;
        margin: 0 auto;
      }
    }
    &__logo {
      margin: 0 0 30px 0;
    }
    &__text {
      font-family: 'Montserrat';
      font-weight: 600;
      font-size: 24px;
      text-align: center;
      color: #f5f6fa;
    }
    &__background {
      position: absolute;
      width: 100%;
      height: 40%;
      bottom: 0;
      background-image: url('~assets/images/Vector.png');
    }
  }
}

.blue-back {
  background-color: #f5f6fa;
}
</style>
