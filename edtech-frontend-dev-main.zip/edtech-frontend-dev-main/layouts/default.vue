<template>
  <v-app dark>
    <v-navigation-drawer fixed app class="navbar">
      <v-container class="d-flex mt-2 justify-center">
        <nuxt-link to="/">
          <img style="max-height: 120px" src="~/assets/images/zaman-logo.png" />
        </nuxt-link>
      </v-container>
      <v-container>
        <hr />
      </v-container>
      <v-list>
        <span v-for="(item, i) in items" :key="i">
          <v-list-item v-if="checkRole(item)" :to="item.to" router>
            <v-list-item-action>
              <icon-list :name="item.icon"></icon-list>
            </v-list-item-action>
            <v-list-item-content>
              <v-list-item-title v-text="item.title" />
            </v-list-item-content>
          </v-list-item>
        </span>
      </v-list>
      <v-container class="navbar__actions">
        <v-btn rounded outlined large icon @click="logout">
          <img src="~/assets/images/logout.svg" alt="Logout | Выйти" />
        </v-btn>
      </v-container>
    </v-navigation-drawer>
    <v-main class="main-content">
      <v-container fluid>
        <Nuxt />
      </v-container>
    </v-main>
  </v-app>
</template>

<script>
import { mapActions } from 'pinia'
import { useUserStore } from '~/store'
import iconList from '~/components/main/IconList.vue'
export default {
  name: 'DefaultLayout',
  components: {
    iconList,
  },
  data() {
    return {
      items: [
        {
          icon: 'home',
          title: 'Главная',
          to: '/',
          role: ['student'],
        },
        {
          icon: 'schedule',
          title: 'Расписание',
          to: '/ScheduleMain',
        },
        {
          icon: 'homework',
          title: 'Домашние задания',
          to: '/teacher/Homework',
          role: ['teacher', 'class-teacher', 'admin'],
        },
        {
          icon: 'journal',
          title: 'Журналы',
          to: '/teacher/MyJournals',
          role: ['teacher', 'class-teacher', 'admin'],
        },
        {
          icon: 'homework',
          title: 'Домашние задания',
          to: '/student/HomeworkMain',
          role: ['student'],
        },
        {
          icon: 'marks',
          title: 'Оценки',
          to: '/student/MarksMain',
          role: 'student',
        },
        {
          icon: 'grades',
          title: 'Классы',
          to: '/teacher/MyStudents',
          role: ['class-teacher', 'admin'],
        },
        // {
        //   icon: 'notification',
        //   title: 'Уведомления',
        //   to: '',
        //   role: ['teacher', 'student', 'class-teacher'],
        // },
        // {
        //   icon: 'files',
        //   title: 'Материалы',
        //   to: '/student/subjFiles',
        //   role: ['student', 'teacher', 'class-teacher'],
        // },
        //         {
        //   icon: 'news',
        //   title: 'Новости',
        //   to: '',
        //   role: ['student'],
        // },
        {
          icon: 'report',
          title: 'Отчеты',
          to: '/teacher/ReportsMain',
          role: ['teacher', 'class-teacher', 'admin'],
        },
        {
          icon: 'ktp',
          title: 'КТП',
          to: '/teacher/calendarThematicPlan',
          role: ['teacher', 'class-teacher', 'admin'],
        },
      ],
    }
  },
  methods: {
    ...mapActions(useUserStore, ['logout']),
    checkRole(route) {
      const user = this.$auth.user
      // eslint-disable-next-line no-prototype-builtins
      if (!route.hasOwnProperty('role')) return true
      if (user.role === 'admin' && !route.role.includes('student')) return true
      if (typeof route.role === 'string') {
        return route.role === user.role
      } else if (Array.isArray(route.role)) {
        return route.role.includes(user.role)
      } else {
        // TODO: add vue-sentry
        throw new TypeError(
          `\`role\` property should only be of type \`string\` or \`Array<string>\`. role: ${
            route.role
          }: <${typeof route.role}>`
        )
      }
    },
  },
}
</script>

<style lang="scss">
* {
  font-family: Montserrat, sans-serif;
  color: #313131;
}

p {
  margin: 0 !important;
}

h1 {
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 20px;
}

.block__title {
  .name {
    font-size: 18px;
    font-weight: 600;
    padding-left: 25px;
  }
  hr {
    background-color: #313131;
    margin: 20px 0;
  }
}

.v-application {
  position: relative;

  .navbar {
    .v-list-item--active {
      background-color: #003a70;
      border-right: 10px solid #ffc72c;
      .v-list-item__title {
        color: #fff;
      }
      .v-list-item__action {
        color: #fff;
      }
      .v-icon svg path {
        fill: #fff;
      }
    }
    &__actions {
      position: fixed;
      bottom: 0;
      background-color: #fff;
    }
  }
}

.main-content {
  background-color: #f5f6fa;
  overflow: hidden;
}
</style>
