<template>
  <div class="grid-wrapper">
    <ScheduleDefault class="schedule"></ScheduleDefault>
    <StudentProfile
      :profile-data-ready="profileDataReady"
      class="profile"
    ></StudentProfile>
    <AcademicPerformance class="score"></AcademicPerformance>
    <AttendanceCard class="attendance"></AttendanceCard>
    <NotificationsCard class="news"></NotificationsCard>
    <HomeworkCard class="homework"></HomeworkCard>
  </div>
</template>

<script>
import { mapActions } from 'pinia'
import { useProfileStore } from '~/store'
import ScheduleDefault from '~/components/schedules/ScheduleDefault'
import AttendanceCard from '~/components/main/AttendanceCard'
import NotificationsCard from '~/components/main/NotificationsCard'
import HomeworkCard from '~/components/main/HomeworkCard'
import StudentProfile from '~/components/main/StudentProfile'
import AcademicPerformance from '~/components/main/AcademicPerformance'

export default {
  name: 'IndexPage',
  components: {
    ScheduleDefault,
    AttendanceCard,
    NotificationsCard,
    HomeworkCard,
    StudentProfile,
    AcademicPerformance,
  },
  middleware: ['authMainPage'],
  data() {
    return {
      profileDataReady: false,
    }
  },
  mounted() {
    this.prepareProfileData()
  },
  methods: {
    ...mapActions(useProfileStore, ['loadProfile']),
    async prepareProfileData() {
      await this.loadProfile()
      this.profileDataReady = true
    },
  },
}
</script>

<style lang="scss">
@import '/assets/main.scss';

.grid-wrapper {
  display: grid;
  grid-template-columns: 1fr 0.7fr 0.5fr;
  gap: 20px;
  grid-template-areas:
    'schedule schedule profile'
    'score attendance news'
    'homework homework news';
}

.schedule {
  grid-area: schedule;
}

.attendance {
  grid-area: attendance;
}

.news {
  grid-area: news;
}
.grid-wrapper {
  .profile {
    grid-area: profile;
  }
}

.score {
  grid-area: score;
}

.homework {
  grid-area: homework;
}
</style>
