<template>
  <div class="my-class">
    <h1>Мой класс</h1>
    <div class="my-class__main table-main pagesGrid">
      <div class="my-class__list list">
        <v-tabs v-model="tab">
          <v-tab>Ученики</v-tab>
          <v-tab>Учителя</v-tab>
        </v-tabs>
        <v-divider></v-divider>
        <v-tabs-items v-model="tab">
          <v-tab-item>
            <DefaultList
              :loading="loading"
              :list="grade.studentProfiles"
              :headers="headersStudents"
              class="container"
              type="students-class"
            />
          </v-tab-item>
          <v-tab-item>
            <DefaultList
              :loading="loading"
              :list="grade.teacherProfiles"
              :headers="headersTeachers"
              class="container"
              type="teachers"
            />
          </v-tab-item>
        </v-tabs-items>
      </div>
      <div class="main-component-text">
        <StudentProfileSidebar />
        <TeacherProfileSidebar
          :profile="grade.classTeacherProfile"
          :teacher-user="grade.classTeacherProfile.userAccount"
        />
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapActions } from 'pinia'
import StudentProfileSidebar from '../../components/profiles/StudentProfile.vue'
import TeacherProfileSidebar from '../../components/profiles/TeacherProfile.vue'
import { StudentProfile } from '~/models/profile.model'
import { Grade } from '~/models/grade.model'
import { useProfileStore, useGradeStore } from '~/store'
import DefaultList from '~/components/main/DefaultList.vue'

export default {
  name: 'MyClass',
  components: {
    StudentProfileSidebar,
    TeacherProfileSidebar,
    DefaultList,
  },
  data: () => ({
    headersStudents: ['№', 'ФИО', 'Дата рождения', 'Номер телефона'],
    headersTeachers: ['№', 'ФИО', 'Предмет'],
    isLoading: false,
    tab: null,
  }),
  computed: {
    ...mapState(useProfileStore, {
      profile: (store) => StudentProfile.serialize(store.profile),
      profilePic: (store) => store.profilePic,
    }),
    ...mapState(useGradeStore, {
      grade: (store) => Grade.serialize(store.grade),
      loading: (store) => store.loading,
    }),
  },
  mounted() {
    this.loadGrade(this.profile.grade.uuid)
  },
  methods: {
    ...mapActions(useGradeStore, ['loadGrade']),
  },
}
</script>

<style lang="scss">
.table {
  width: 70%;
  border-radius: 8px;
  background-color: #fff;
  padding: 20px 25px;
  margin-right: 2%;
  box-shadow: 0px 4px 25px 0px #0000000a;
  &__type {
    margin-bottom: 15px;
    button {
      text-decoration: none;
      color: #8b8b8b;
      transition: 0.5s;
      margin-right: 20px;
      margin-bottom: 20px;
    }
    hr {
      background-color: #313131;
    }
  }
  .picked {
    text-decoration: underline;
    color: #003a70;
    transition: 0.5s;
  }
  .list {
    p {
      font-size: 14px;
    }
    &__titles {
      font-weight: 600;
      display: flex;
      border-bottom: #e5eaee 1px solid;
      padding: 0 0 15px 25px;
    }
    &__content {
      display: flex;
      border-bottom: #e5eaee 1px solid;
      padding: 15px 0 15px 25px;
    }
    .num {
      width: 10%;
    }
    .name {
      width: 40%;
    }
    .date {
      width: 15%;
    }
    .phone {
      width: 35%;
    }
  }
}

.data {
  width: 28%;
  &__profile {
    padding: 20px 25px;
    border-radius: 8px;
    background-color: #fff;
    margin-bottom: 20px;
    &_button {
      font-weight: 500;
      border-radius: 10px;
      border: #003a70 1px solid;
      color: #003a70;
      height: 42px;
      width: 100%;
    }

    &_name {
      display: flex;
      align-items: center;
      font-size: 16px;
      font-weight: 600;
      margin-bottom: 10px;
      img {
        margin-right: 20px;
        width: 64px;
        height: 64px;
        border-radius: 99px;
      }
    }
    &_more {
      margin-bottom: 15px;
      p {
        border-bottom: #e5eaee 1px solid;
        padding-bottom: 8px;
        margin-bottom: 8px !important;
      }
    }
  }
}
</style>
