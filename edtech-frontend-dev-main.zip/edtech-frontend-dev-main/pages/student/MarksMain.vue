<template>
  <div class="marks">
    <h1>Оценки</h1>
    <div class="marks table-main pagesGrid">
      <div class="marks__list list">
        <div>
          <div>
            <v-tabs v-model="tab">
              <v-tab
                @click="
                  loadDefaultMarks()
                  setMarksState('quarter')
                "
                >По четвертям</v-tab
              >
              <v-tab @click="setMarksState('subjects')">По предметам</v-tab>
              <v-tab
                @click="
                  prepareYearMarks()
                  setMarksState('year')
                "
                >Итоговые</v-tab
              >
            </v-tabs>
          </div>
          <v-divider></v-divider>
        </div>
        <v-tabs-items v-model="tab">
          <v-tab-item>
            <MarksTerm class="marks__table" />
            <client-only class="d-none">
              <vue-html2pdf
                ref="html2PdfMarkTerm"
                class="d-none"
                :show-layout="false"
                :float-layout="true"
                :enable-download="true"
                :paginate-elements-by-height="1400"
                :filename="pdfName"
                :pdf-quality="2"
                :manual-pagination="false"
                pdf-format="a4"
                pdf-orientation="landscape"
                pdf-content-width="100%"
              >
                <section slot="pdf-content">
                  <MarksTerm />
                </section>
              </vue-html2pdf>
            </client-only>
          </v-tab-item>
          <v-tab-item>
            <MarksSubject class="marks__table" />
            <client-only class="d-none">
              <vue-html2pdf
                ref="html2PdfMarkSubject"
                class="d-none"
                :show-layout="false"
                :float-layout="true"
                :enable-download="true"
                :paginate-elements-by-height="1400"
                :filename="pdfName"
                :pdf-quality="2"
                :manual-pagination="false"
                pdf-format="a4"
                pdf-orientation="landscape"
                pdf-content-width="100%"
              >
                <section slot="pdf-content">
                  <MarksSubject />
                </section> </vue-html2pdf></client-only
          ></v-tab-item>
          <v-tab-item>
            <MarksYear class="marks__table" />
            <client-only class="d-none">
              <vue-html2pdf
                ref="html2PdfMarkYear"
                class="d-none"
                :show-layout="false"
                :float-layout="false"
                :enable-download="true"
                :paginate-elements-by-height="1400"
                :filename="pdfName"
                :pdf-quality="2"
                :manual-pagination="false"
                pdf-format="a4"
                pdf-orientation="landscape"
                pdf-content-width="100%"
              >
                <section slot="pdf-content">
                  <MarksYear />
                </section> </vue-html2pdf></client-only
          ></v-tab-item>
        </v-tabs-items>
      </div>
      <MarksActions
        :tab-mode="tabValue"
        :quarter-list="termList"
        :subjects="subjectList"
        @downloadPdf="generateReport"
        @loadQuarterMarks="loadQuarterMarksWithId"
        @filterList="filterList"
      ></MarksActions>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'pinia'
import {
  useTermStore,
  useMarksStore,
  useAttendanceStore,
  useSubjectStore,
  useUserStore,
} from '~/store'
import { Term } from '~/models/term.model'
import { Subject } from '~/models/subject.model'
import { User } from '~/models/user.model'
import MarksTerm from '~/components/marks/MarksTerm'
import MarksSubject from '~/components/marks/MarksSubject'
import MarksYear from '~/components/marks/MarksYear'
import MarksActions from '~/components/marks/MarksActions'
export default {
  name: 'MarksPage',
  components: {
    MarksActions,
    MarksTerm,
    MarksSubject,
    MarksYear,
  },

  data() {
    return {
      tab: null,
      tabValue: 'quarter',
      subjectFilterValue: '',
      quarterFilterValue: '',
    }
  },
  computed: {
    ...mapState(useTermStore, {
      termList: (store) => Term.serializeList(store.terms),
      currentTerm: (store) => Term.serialize(store.currentTerm),
    }),
    ...mapState(useSubjectStore, {
      subjectList: (store) => Subject.serializeList(store.subjects),
    }),
    ...mapState(useUserStore, {
      userData: (store) => User.serialize(store.user),
    }),
    ...mapState(useMarksStore, {
      isLoading: (store) => store.loading,
    }),
    pdfName() {
      return this.userData.fullName + ' PDF'
    },
  },
  mounted() {
    this.loadDefaultMarks()
    this.setSubjects()
  },
  methods: {
    reciveMode(value) {
      this.mode = value
    },
    ...mapActions(useTermStore, ['loadTerms']),
    ...mapActions(useAttendanceStore, ['setAttendanceYear']),
    ...mapActions(useMarksStore, [
      'loadQuarterMarks',
      'loadYearMarks',
      'loadSubjectMarks',
    ]),
    ...mapActions(useSubjectStore, ['setSubjects']),
    async loadDefaultMarks() {
      await this.loadTerms()
      this.loadQuarterMarks(this.currentTerm.uuid)
    },
    async prepareYearMarks() {
      await this.setAttendanceYear()
      await this.loadYearMarks()
    },
    setMarksState(tabTxt) {
      this.tabValue = tabTxt
    },
    loadQuarterMarksWithId(quarterId) {
      this.loadQuarterMarks(quarterId)
    },
    async filterList(subject, quarter) {
      this.subjectFilterValue = subject
      this.quarterFilterValue = quarter
      await this.loadSubjectMarks(subject, quarter)
    },
    generateReport() {
      if (this.tabValue === 'quarter') {
        this.$refs.html2PdfMarkTerm.generatePdf()
      } else if (this.tabValue === 'subjects') {
        this.$refs.html2PdfMarkSubject.generatePdf()
      } else if (this.tabValue === 'year') {
        this.$refs.html2PdfMarkYear.generatePdf()
      }
    },
    async prepareSubjectMarks() {
      await this.loadSubjectMarks(
        this.subjectList[0].uuid,
        this.currentTerm.uuid
      )
    },
  },
}
</script>
