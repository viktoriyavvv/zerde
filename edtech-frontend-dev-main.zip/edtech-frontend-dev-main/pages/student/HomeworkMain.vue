<template>
  <div class="student-homework">
    <h1>Домашние задания</h1>
    <div class="student-homework__main table-main pagesGrid">
      <div class="student-homework__list list">
        <div>
          <div class="student-homework__class-info">
            <v-tabs v-model="tab">
              <v-tab
                @click="
                  setHomeworkState('')
                  clickActionFiltered()
                  closeHwDetails()
                  resetPage()
                "
                >Все</v-tab
              >
              <v-tab
                @click="
                  setHomeworkState('done')
                  clickActionFiltered()
                  closeHwDetails()
                  resetPage()
                "
                >Выполнены</v-tab
              >
              <v-tab
                @click="
                  setHomeworkState('not_done')
                  clickActionFiltered()
                  closeHwDetails()
                  resetPage()
                "
                >Не выполнены</v-tab
              >
            </v-tabs>
          </div>
          <v-divider></v-divider>
        </div>
        <div class="pagination-content">
          <v-tabs-items v-model="tab" class="pagination-content__content">
            <v-tab-item>
              <DefaultList
                :list="homeworkList"
                :headers="headers"
                :loading="isLoading"
                class="container"
                type="homework"
                @selectHW="getHomeworkId"
            /></v-tab-item>
            <v-tab-item>
              <DefaultList
                :list="homeworkList"
                :headers="headers"
                :loading="isLoading"
                class="container"
                type="homework"
                @selectHW="getHomeworkId"
            /></v-tab-item>
            <v-tab-item>
              <DefaultList
                :list="homeworkList"
                :headers="headers"
                :loading="isLoading"
                class="container"
                type="homework"
                @selectHW="getHomeworkId"
            /></v-tab-item>
          </v-tabs-items>
          <v-pagination
            v-model="page"
            :length="homeworksPages"
            :total-visible="7"
            color="#003a70"
            class="pagination-content__pagination main-component-text-little"
            @input="
              loadHomeworkPaginated()
              closeHwDetails()
            "
          ></v-pagination>
        </div>
      </div>
      <TaskFilter
        v-if="!mode && !loadingDetails"
        :subjects="subjectList"
        @filterListStudent="filterListStudent"
      />
      <HomeworkRealization
        v-else-if="mode && !loadingDetails"
        :details="homeworkDetails"
      />
      <div v-else class="main-component">
        <v-skeleton-loader type="article"></v-skeleton-loader>
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState, mapStores } from 'pinia'
import { useHomeworkStore, useSubjectStore } from '~/store'
import {
  HomeworkStudent /*  StudentAnswer */,
  HomeworkDetails,
} from '~/models/homework.model'
import { Subject } from '~/models/subject.model'
import TaskFilter from '~/components/tasks/TaskFilter.vue'
import HomeworkRealization from '~/components/tasks/HomeworkRealization'
import DefaultList from '~/components/main/DefaultList.vue'

export default {
  name: 'HomeWork',
  components: { TaskFilter, DefaultList, HomeworkRealization },
  middleware: ['authStudent'],
  data: () => ({
    page: 1,
    tab: null,
    tabValue: '',
    subjectFilterValue: '',
    resetValue: true,
    headers: ['Предмет', 'Задание', 'Срок выполнения', 'Статус', 'Оценка'],
  }),
  computed: {
    ...mapStores(useHomeworkStore),
    ...mapStores(useSubjectStore),
    ...mapState(useHomeworkStore, {
      homeworkList: (store) => HomeworkStudent.serializeList(store.homeworks),
      mode: (store) => store.mode,
      selectedHomeworkUuid: (store) => store.selectedHomeworkUuid,
      homeworkDetails: (store) =>
        HomeworkDetails.serialize(store.selectedHomework),
      isLoading: (store) => store.loading,
      loadingDetails: (store) => store.loadingDetails,
      homeworksPages: (store) => {
        const count = Math.ceil(store.homeworksCount)
        if (count < 1) {
          return 1
        } else return count
      },
    }),
    ...mapState(useSubjectStore, {
      subjectList: (store) => Subject.serializeList(store.subjects),
    }),
  },
  mounted() {
    this.setHomework(this.tabValue, 0)
    this.setSubjects()
  },
  methods: {
    resetPage() {
      this.page = 1
    },
    loadHomeworkPaginated() {
      if (this.resetValue) {
        this.setHomework(this.tabValue, this.page - 1)
      } else {
        this.setFilteredHomeworkStudent(
          this.tabValue,
          this.subjectFilterValue,
          this.dateFilterValue,
          this.page - 1
        )
      }
    },
    ...mapActions(useHomeworkStore, [
      'setHomework',
      'setFilteredHomeworkStudent',
      'setSelectedHomeworkUuid',
      'setHomeworkDetails',
      'setMode',
      'closeHwDetails',
    ]),
    ...mapActions(useSubjectStore, ['setSubjects']),
    filterListStudent(subject, date, reset) {
      this.resetValue = reset
      this.subjectFilterValue = subject
      this.dateFilterValue = date
      this.resetPage()
      if (!reset) {
        this.setFilteredHomeworkStudent(
          this.tabValue,
          subject,
          date,
          this.page - 1
        )
      } else {
        this.setHomework(this.tabValue)
      }
    },
    setHomeworkState(tabTxt) {
      this.tabValue = tabTxt
    },
    clickActionFiltered() {
      if (this.resetValue) {
        this.setHomework(this.tabValue)
      } else {
        this.setFilteredHomeworkStudent(
          this.tabValue,
          this.subjectFilterValue,
          this.dateFilterValue,
          this.page - 1
        )
      }
    },
    getHomeworkId(id) {
      this.setSelectedHomeworkUuid(id)
      this.setHomeworkDetails()
    },
  },
}
</script>
