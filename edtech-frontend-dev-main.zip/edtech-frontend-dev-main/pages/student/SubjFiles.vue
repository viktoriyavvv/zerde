<template>
  <div class="files">
    <h1>Материалы</h1>
    <div class="d-flex">
      <div class="files__main">
        <div class="block__title">
          <div class="options">
            <div>
              <button
                :class="{ chosen: whichHome === 'all' }"
                @click="whichHome = 'all'"
              >
                Все файлы
              </button>
              <button
                :class="{ chosen: whichHome === 'mine' }"
                @click="$router.push(`/folderFiles`)"
              >
                Мои файлы
              </button>
              <button
                :class="{ chosen: whichHome === 'elected' }"
                @click="whichHome = 'elected'"
              >
                Избранные файлы
              </button>
            </div>
          </div>
          <hr />
        </div>
        <TableFile :files="files" />
        <!-- <PlateFile /> -->
      </div>
      <div class="files__action">
        <!-- <ActionFile /> -->
      </div>
    </div>
  </div>
</template>

<script>
// import ActionFile from '~/components/files/actionFile.vue'
// import PlateFile from '~/components/files/PlateFile.vue'
import TableFile from '~/components/files/TableFile.vue'
export default {
  name: 'SubjFiles',
  components: { TableFile },
  data: () => ({
    whichHome: 'all',
    files: [
      {
        name: 'Русский язык',
        amount: '7 files',
      },
      {
        name: 'Русский язык',
        amount: '7 files',
      },
      {
        name: 'Русский язык',
        amount: '7 files',
      },
      {
        name: 'Русский язык',
        amount: '7 files',
      },
      {
        name: 'Русский язык',
        amount: '7 files',
      },
      {
        name: 'Русский язык',
        amount: '7 files',
      },
    ],
  }),
}
</script>

<style lang="scss">
.files {
  &__main {
    width: 70%;
    margin-right: 20px;
    padding: 25px;
    background-color: #fff;
    border-radius: 10px;
  }
  &__action {
    width: 27%;
  }
  .block__title {
    .options {
      button {
        font-weight: 500;
        color: #8b8b8b;
        margin-right: 15px;
        transition: 0.3s;
      }
      .chosen {
        text-decoration: underline;
        color: #003a70;
        transition: 0.3s;
      }
    }
  }
}
</style>
