<template>
  <div class="files">
    <h1>Материалы</h1>
    <div class="d-flex">
      <div class="files__main">
        <div class="block__title">
          <div class="options">
            <div>
              <button
                :class="{ chosen: whichHome === 'all' }"
                @click="$router.push(`/subjFiles`)"
              >
                Все файлы
              </button>
              <button
                :class="{ chosen: whichHome === 'mine' }"
                @click="whichHome = 'mine'"
              >
                Мои файлы
              </button>
              <button
                :class="{ chosen: whichHome === 'elected' }"
                @click="whichHome = 'elected'"
              >
                Избранные файлы
              </button>
            </div>
          </div>
          <hr />
        </div>
        <div class="table">
          <div class="grid">
            <div v-for="(file, index) in files" :key="index">
              <button
                :class="{ active: file.filled }"
                class="star"
                @click="file.filled = !file.filled"
              >
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle cx="12" cy="12" r="11.5" stroke="#FFC72C" />
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M12 6C10.6426 6 10.5142 8.36435 9.70608 9.19972C8.89792 10.0351 6.38547 9.07995 6.03639 10.5627C5.68805 12.0462 7.94824 12.5495 8.22691 13.8223C8.50705 15.095 7.12615 16.8833 8.30611 17.7732C9.48607 18.6624 10.7562 16.6498 12 16.6498C13.2438 16.6498 14.5139 18.6624 15.6939 17.7732C16.8738 16.8833 15.4937 15.095 15.7731 13.8223C16.0525 12.5495 18.3119 12.0462 17.9636 10.5627C17.6153 9.07995 15.1021 10.0351 14.2946 9.19972C13.4865 8.36435 13.3574 6 12 6Z"
                    stroke="#FFC72C"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    fill="currentColor"
                  />
                </svg>
              </button>
              <a :href="file.link" download=""
                ><img :src="file.img" alt=""
              /></a>
              <p>{{ file.name }}</p>
              <span>{{ file.date }}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="files__action">
        <!-- <ActionFile /> -->
      </div>
    </div>
  </div>
</template>

<script>
// var extension = fileName.substring(fileName.lastIndexOf('.')+1);
export default {
  name: 'SubjFiles',
  data: () => ({
    whichHome: 'mine',
    files: [
      {
        img: require('~/assets/images/pdf.svg'),
        name: 'Avionica Tech Req..',
        date: '2 days ago',
        filled: false,
      },
      {
        img: require('~/assets/images/doc.svg'),
        link: '~/assets/doc.docx',
        name: 'Avionica Tech Req..',
        date: '2 days ago',
        filled: false,
      },
      {
        img: require('~/assets/images/pdf.svg'),
        name: 'Avionica Tech Req..',
        date: '2 days ago',
        filled: false,
      },
    ],
  }),
}
</script>

<style lang="scss">
.files {
  &__main {
    width: 70%;
    margin-right: 20px;
    padding: 25px;
    background-color: #fff;
    border-radius: 10px;
  }
  &__action {
    width: 27%;
  }
  .block__title {
    .options {
      button {
        font-weight: 500;
        color: #8b8b8b;
        margin-right: 15px;
        transition: 0.3s;
      }
      .chosen {
        text-decoration: underline;
        color: #003a70;
        transition: 0.3s;
      }
    }
  }
}

.grid {
  display: grid;
  grid-template-columns: auto auto auto auto auto;
  column-gap: 46px;
  text-align: center;
  padding-top: 40px;
  div {
    position: relative;
  }
  .star {
    position: absolute;
    right: 0;
    top: -15%;
    color: #fff;
    transition: 0.3s;
  }
  .active {
    color: #ffc72c;
    transition: 0.3s;
  }
}
</style>
