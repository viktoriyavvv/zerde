<template>
  <div>
    <h1>Расписание</h1>
    <div class="pagesGrid">
      <schedule-table
        :data-range="range"
        :selected-option="uuid"
        @tableToPage="receiveState"
      />
      <schedule-actions
        :state="state"
        @actionToTable="receiveDates"
        @getSelected="receiveSelected"
      />
    </div>
  </div>
</template>

<script>
import scheduleTable from '~/components/schedules/ScheduleTable'
import scheduleActions from '~/components/schedules/ScheduleActions'

export default {
  name: 'ScheduleMain',
  components: {
    scheduleActions,
    scheduleTable,
  },

  data() {
    return {
      scheduleTheme: '',
      state: ' ',
      range: [],
      uuid: '',
    }
  },

  methods: {
    receiveState(value) {
      this.state = value
    },
    receiveDates(value) {
      this.range = value
    },
    receiveSelected(value) {
      this.uuid = value
    },
  },
}
</script>
