<template>
  <v-container>
    <section class="login">
      <h1 class="heading login__heading">Авторизация</h1>
      <form @submit.prevent="login">
        <div>
          <v-text-field
            id="email"
            v-model="auth.email"
            placeholder="Введите email"
            label="Логин"
            solo
            type="email"
            :rules="[rules.required, rules.email]"
          >
            <template #prepend-inner>
              <svg
                style="margin: 15px"
                class="icon"
                width="16"
                height="22"
                viewBox="0 0 16 22"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M7.84455 20.6618C4.15273 20.6618 1 20.0873 1 17.7865C1 15.4858 4.13273 13.3618 7.84455 13.3618C11.5364 13.3618 14.6891 15.4652 14.6891 17.766C14.6891 20.0658 11.5564 20.6618 7.84455 20.6618Z"
                  stroke="#112950"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M7.83725 10.1735C10.26 10.1735 12.2236 8.2099 12.2236 5.78718C12.2236 3.36445 10.26 1.3999 7.83725 1.3999C5.41452 1.3999 3.44998 3.36445 3.44998 5.78718C3.4418 8.20172 5.3918 10.1654 7.80634 10.1735C7.81725 10.1735 7.82725 10.1735 7.83725 10.1735Z"
                  stroke="#112950"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </template>
          </v-text-field>
        </div>
        <div>
          <v-text-field
            id="password"
            v-model="auth.password"
            :rules="[rules.required]"
            placeholder="Введите пароль"
            required
            type="password"
            solo
            label="Пароль"
          >
            <template #prepend-inner>
              <svg
                style="margin: 15px"
                class="icon"
                width="18"
                height="21"
                viewBox="0 0 18 21"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M13.4709 7.40335V5.25435C13.4399 2.73535 11.3719 0.719353 8.85385 0.750353C6.38685 0.781353 4.39185 2.76735 4.34985 5.23435V7.40335"
                  stroke="#112950"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
                <path
                  d="M8.91016 12.1562V14.3772"
                  stroke="#112950"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
                <path
                  fill-rule="evenodd"
                  clip-rule="evenodd"
                  d="M8.91024 6.82422C3.16524 6.82422 1.25024 8.39222 1.25024 13.0952C1.25024 17.7992 3.16524 19.3672 8.91024 19.3672C14.6552 19.3672 16.5712 17.7992 16.5712 13.0952C16.5712 8.39222 14.6552 6.82422 8.91024 6.82422Z"
                  stroke="#112950"
                  stroke-width="1.5"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                />
              </svg>
            </template>
          </v-text-field>
        </div>
        <div class="submit">
          <button
            class="button submit__button"
            :disabled="isLogginIn"
            type="submit"
          >
            Войти
          </button>
        </div>
      </form>
      <div v-if="errors.length > 0" class="errors">
        <ul class="errors__list">
          <li v-for="(error, index) in errors" :key="index">
            <p class="errors__list-item">{{ getErrorMsg(error) }}</p>
          </li>
        </ul>
      </div>
      <div class="login__info">
        <!-- <div class="info__block">
          <nuxt-link class="link forgot" to="/auth/forgot">
            Забыли пароль?
          </nuxt-link>
        </div> -->
        <!-- <div class="info__block">
          <p class="text">
            Нажимая войти, Вы подтверджаете, что ознакомились и согласны с
            правилами и условиями
            <a class="link" href="#">Пользовательского соглашения</a> и
            <a class="link" href="#">Политикой обработки данных.</a>
          </p>
        </div> -->
      </div>
    </section>
  </v-container>
</template>

<script>
import { mapStores } from 'pinia'
import { useUserStore, useProfileStore } from '~/store'

const errorNames = {
  'Incorrect email or password.': 'Введен неверный логин или пароль',
  'Enter a valid email address.': 'Введите корректный электронный адрес.',
}

export default {
  name: 'LoginPage',
  layout: 'empty',
  auth: false,
  data() {
    return {
      auth: {
        email: '',
        password: '',
      },
      errors: [],
      isLogginIn: false,
      rules: {
        required: (value) => !!value || 'Обязательное поле.',
        email: (value) => {
          const pattern =
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
          return pattern.test(value) || 'Некорректный e-mail.'
        },
      },
    }
  },

  computed: {
    ...mapStores(useUserStore, useProfileStore),
  },
  methods: {
    async login() {
      this.errors = []
      try {
        this.$nuxt.$loading.start()
        this.isLogginIn = true
        const res = await this.$auth.loginWith('local', {
          data: { ...this.auth },
        })
        if (res.status === 200) {
          const user = await this.$axios.get('/accounts/me/')

          this.$auth.strategy.token.set(res.data.access)
          this.userStore.setUser(user.data)
          this.$auth.setUser(user.data)

          if (user.role === 'student') {
            const profile = await this.$axios.get('/accounts/me/student/')
            this.profileStore.setProfile(profile.data)
          }
          this.$router.push('/')
        }
      } catch (error) {
        const errorData = error.response.data
        const errors = []
        Object.entries(errorData).forEach(([key]) => {
          errorData[key].forEach((msg) => errors.push(msg))
        })
        this.errors = errors
      } finally {
        this.isLogginIn = false
        this.$nuxt.$loading.finish()
      }
    },
    getErrorMsg(e) {
      return errorNames[e] ? errorNames[e] : 'Что-то пошло не так'
    },
  },
}
</script>

<style lang="scss" scoped>
.container {
  max-width: 440px;
  align-items: center;
  justify-content: center;
  .login {
    &__heading {
      color: #181c32;
      font-family: 'Montserrat';
      font-weight: 600;
      font-size: 30px;
      text-align: center;
    }
    .submit {
      &__button {
        font-weight: 600;
        font-size: 15px;
        background: #003a70;
        border-radius: 6px;
        color: #fff;
        width: 100%;
        height: 48px;
        &:disabled {
          cursor: not-allowed;
        }
      }
    }

    &__info {
      .link {
        color: #003a70;
        text-decoration: none;
      }
      .forgot {
        display: flex;
        justify-content: center;
        text-align: center;
        font-size: 14px;
        font-style: normal;

        font-weight: 600;

        margin: 20px 0;
      }
      .text {
        font-weight: 400;
        font-size: 12px;
        color: #8b8b8b;
      }
    }
  }
}

.errors {
  margin: 10px 0;
  padding: 10px;
  background-color: #fecaca;
  border-radius: 6px;
  font-weight: 600;
  border: 1px solid #f87171;
  &__list {
    &-item {
      color: #dc2626;
    }
  }
}
</style>
