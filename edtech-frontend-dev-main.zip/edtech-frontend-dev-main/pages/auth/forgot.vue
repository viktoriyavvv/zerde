<template>
  <div>Forgot password</div>
</template>

<script>
export default {
  auth: false,
  name: 'ForgotPassword',
  layout: 'empty',
}
</script>
