<template>
  <div class="reports-page">
    <h1>Отчеты</h1>
    <div class="reports-page__main pagesGrid main-component-text">
      <div class="reports-page__main-content">
        <div class="reports-page__stats-wrap">
          <div class="reports-page__stats">
            <div>
              <div class="reports-page__sub-title">Движение учеников</div>
            </div>
            <StatChart :data="chartData1" :options="options" />
          </div>
          <div class="reports-page__stats">
            <div class="reports-page__sub-title">Посещаемость</div>
            <StatChart :data="chartData2" :options="options" />
          </div>
        </div>
        <div class="reports-page__activity">
          <div class="reports-page__sub-title">Общая активность на портале</div>
        </div>
      </div>
      <ReportsNav />
    </div>
  </div>
</template>

<script>
import { mapActions } from 'pinia'
import ReportsNav from '~/components/tasks/ReportsNav.vue'
import { useGradeStore } from '~/store'
import StatChart from '~/components/charts/StatChart.vue'

export default {
  name: 'ReportsMain',
  components: {
    ReportsNav,
    StatChart,
  },
  data() {
    return {
      headers: ['№ п/п', 'Дата', 'Тема урока', 'Домашнее задание', 'Файлы'],
      chartData1: {
        labels: [
          'January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
        ],
        datasets: [
          {
            label: 'Прибывшие',
            data: [65, 59, 80, 81, 56, 55, 40],
            fill: true,
            borderColor: '#d7f9ef',
            backgroundColor: '#d7f9ef',
            pointRadius: 2,
          },
          {
            label: 'Выбывшие',
            data: [12, 11, 90, 21, 33, 90, 58],
            fill: true,
            borderColor: '#F7CED1',
            tension: 0.1,
            backgroundColor: '#F7CED1',
            pointRadius: 2,
          },
        ],
      },
      chartData2: {
        labels: [
          'January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
        ],
        datasets: [
          {
            label: 'Прибывшие',
            data: [65, 59, 80, 81, 56, 55, 40],
            fill: true,
            borderColor: '#d7f9ef',
            tension: 0.1,
            backgroundColor: '#d7f9ef',
            pointRadius: 0,
          },
          {
            label: 'Выбывшие',
            data: [12, 11, 90, 21, 33, 90, 58],
            fill: true,
            borderColor: '#F7CED1',
            tension: 0.1,
            backgroundColor: '#F7CED1',
            pointRadius: 0,
          },
        ],
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        legend: {
          display: true,
          position: 'bottom',
          labels: {
            fontColor: '#000080',
          },
        },
        scales: {
          yAxes: [
            {
              ticks: {
                beginAtZero: true,
              },
            },
          ],
        },
      },
    }
  },
  mounted() {
    this.loadGradeList()
  },
  methods: {
    ...mapActions(useGradeStore, ['loadGradeList']),
  },
}
</script>
