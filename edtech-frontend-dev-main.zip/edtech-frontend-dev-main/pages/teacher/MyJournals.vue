<template>
  <div>
    <h1 class="journals__title mb-5 ml-10">Журнал</h1>
    <div class="d-flex justify-space-between">
      <div style="margin-right: 20px; width: 100%">
        <div>
          <div v-if="term === ''">
            <JournalTableEmpty />
          </div>
          <div
            v-if="
              toShowSumMarks === true &&
              showFinals === false &&
              term.uuid !== 'total'
            "
          >
            <JournalTableOnlySor
              :grade-journal="gradeJournal"
              :subject-journal="subjectJournal"
              :quarter-journal="quarterJournal"
              :term="term"
            />
          </div>
          <div
            v-if="
              toShowSumMarks === false &&
              showFinals === false &&
              term.uuid !== 'total' &&
              term !== ''
            "
          >
            <JournalsTable
              :grade-journal="gradeJournal"
              :subject-journal="subjectJournal"
              :quarter-journal="quarterJournal"
              :term="term"
            />
          </div>
          <div
            v-if="
              showFinals === true &&
              halfYearSwitcher === false &&
              halfYearSwitcherSideBar === false &&
              term.uuid === 'total'
            "
          >
            <JournalTableOnlyTerms
              :grade-name="gradeName"
              :grade-finals="gradeFinals"
              :subject-finals="subjectFinals"
              @getSwitchState="getSwitchState"
            />
          </div>
          <div
            v-if="
              showFinals === true &&
              halfYearSwitcherSideBar === true &&
              term.uuid === 'total'
            "
          >
            <JournalTableOnlyHalfYear
              :grade-name="gradeName"
              :grade-finals="gradeFinals"
              :subject-finals="subjectFinals"
              :quarter-journal="quarterJournal"
              @getSwitchState="getSwitchState"
            />
          </div>
        </div>
      </div>

      <div>
        <JournalSideBar
          :term="term.name"
          @showSumMarks="showSumMarks"
          @getFinals="getFinals"
          @getTermName="getTermName"
          @getGradeName="getGradeName"
          @getJournalData="getJournalData"
          @getSwitchStateFromSideBar="getSwitchStateFromSideBar"
        ></JournalSideBar>
      </div>
    </div>
  </div>
</template>

<script>
import JournalsTable from '@/components/journals/JournalsTable'
import JournalSideBar from '@/components/journals/JournalSideBar'
import JournalTableOnlySor from '@/components/journals/JournalTableOnlySor'
import JournalTableOnlyTerms from '@/components/journals/JournalTableOnlyTerms'
import JournalTableOnlyHalfYear from '@/components/journals/JournalTableOnlyHalfYear'
import JournalTableEmpty from '@/components/journals/JournalTableEmpty'

export default {
  name: 'MyJournals',
  components: {
    JournalTableEmpty,
    JournalTableOnlyHalfYear,
    JournalTableOnlyTerms,
    JournalTableOnlySor,
    JournalSideBar,
    JournalsTable,
  },
  data() {
    return {
      toShowSumMarks: false,
      showFinals: false,
      halfYearSwitcher: false,
      halfYearSwitcherSideBar: false,
      term: '',
      gradeName: '',
      gradeFinals: '',
      subjectFinals: '',
      gradeJournal: '',
      subjectJournal: '',
      quarterJournal: '',
    }
  },
  head() {
    return {
      title: 'Журналы',
    }
  },
  methods: {
    showSumMarks(isHideClicked) {
      this.toShowSumMarks = isHideClicked
    },
    getSwitchState(switcherState) {
      this.halfYearSwitcher = switcherState
      this.halfYearSwitcherSideBar = switcherState
    },
    getSwitchStateFromSideBar(switcherState) {
      this.halfYearSwitcherSideBar = switcherState
      this.halfYearSwitcher = switcherState
    },
    getFinals(finalsValue, finalsData) {
      this.gradeFinals = finalsData.grade
      this.subjectFinals = finalsData.subjects
      this.showFinals = finalsValue
    },
    getTermName(termData) {
      this.term = termData
      if (this.term.uuid === 'total') {
        this.showFinals = true
      } else this.showFinals = false
    },
    getGradeName(gradeName) {
      this.gradeName = gradeName
    },
    getJournalData(journalData) {
      this.gradeJournal = journalData.grade
      this.subjectJournal = journalData.subjects
      this.quarterJournal = journalData.quarter
    },
  },
}
</script>
