<template>
  <div class="my-students">
    <h1>Мои ученики</h1>
    <div class="my-students__main table-main pagesGrid">
      <div class="my-students__list list">
        <div>
          <div class="my-students__class-info">
            <span v-if="gradeName === ''">Класс: {{ defaultGrade.name }}</span>
            <span v-else>Класс: {{ gradeName }}</span>
            <span v-if="classTeacher === ''"
              >Классный руководитель: {{ defaultClassTeacherName }}
            </span>
            <span v-else>Классный руководитель: {{ classTeacher }} </span>
          </div>
          <v-divider></v-divider>
        </div>
        <div class="pagination-content">
          <div class="pagination-content__content">
            <DefaultList
              :list="studentList"
              :headers="headers"
              :loading="loading"
              :page="page"
              type="students"
              class="container"
              @showProfile="showProfile"
            />
          </div>
          <v-pagination
            v-model="page"
            :length="classPages"
            :total-visible="7"
            color="#003a70"
            class="pagination-content__pagination main-component-text-little"
            @input="loadStudentsPaginated()"
          ></v-pagination>
        </div>
      </div>
      <StudentFilter
        v-if="!reveal"
        :grades="gradeList"
        @filterList="filterList"
      />
      <StudentItem
        v-else
        :profile="studentList[profileIndex]"
        :reveal="reveal"
        @closeProfile="closeProfile"
      >
      </StudentItem>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'pinia'
import StudentItem from '../../components/profiles/StudentItem.vue'
import { StudentProfile } from '~/models/profile.model'
import { useClassTeacherStore } from '~/store'
import { ClassTeacherGrade } from '~/models/grade.model'
import DefaultList from '~/components/main/DefaultList.vue'
import StudentFilter from '~/components/tasks/StudentFilter.vue'

export default {
  name: 'MyStudents',
  components: { DefaultList, StudentFilter, StudentItem },
  middleware: ['authClassTeacher'],
  data() {
    return {
      headers: [
        '№ п/п',
        'Фамилия Имя Отчество',
        'Номер телефона',
        'Электронная почта',
        'Адрес проживания',
      ],
      profileIndex: null,
      list: [],
      reveal: false,
      gradeName: '',
      isLoading: false,
      classTeacher: '',
      page: 1,
      grade: {},
    }
  },
  computed: {
    ...mapState(useClassTeacherStore, {
      gradeList: (store) => ClassTeacherGrade.serializeList(store.gradeList),
      studentList: (store) => StudentProfile.serializeList(store.studentList),
      defaultGrade: (store) => store.defaultGrade,
      defaultClassTeacherName: (store) => store.defaultClassTeacherName,
      classPages: (store) => {
        const count = Math.ceil(store.studentCount)
        if (count < 1) {
          return 1
        } else return count
      },
      loading: (store) => store.loading,
    }),
  },
  async mounted() {
    await this.setGradeList()
    this.grade = this.defaultGrade
  },
  methods: {
    ...mapActions(useClassTeacherStore, ['setGradeList', 'setStudentList']),
    showProfile(studentIndex) {
      this.profileIndex = studentIndex
      this.reveal = true
    },
    closeProfile() {
      this.reveal = false
    },
    filterList(grade) {
      this.setStudentList(grade.uuid, this.page - 1)
      this.grade = grade
      this.gradeName = grade.name
      this.classTeacher = grade.classTeacherProfile.userAccount.fullName
    },
    setLoading(isLoading) {
      if (isLoading) {
        this.isLoading = true
      } else {
        this.isLoading = false
      }
    },
    resetPage() {
      this.page = 1
    },
    loadStudentsPaginated() {
      this.setStudentList(this.grade.uuid, this.page - 1)
    },
  },
}
</script>
