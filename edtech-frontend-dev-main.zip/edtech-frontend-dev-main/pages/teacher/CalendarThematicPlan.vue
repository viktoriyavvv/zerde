<template>
  <div class="ktp">
    <h1>Календарно-тематический план</h1>
    <div class="ktp__main pagesGrid">
      <DefaultList
        :list="testData"
        :headers="headers"
        :loading="isLoading"
        type="ktp"
        class="container"
      />
      <KtpFilter />
    </div>
  </div>
</template>

<script>
import { mapActions } from 'pinia'
import DefaultList from '~/components/main/DefaultList.vue'
import KtpFilter from '~/components/tasks/KtpFilter.vue'
import { useGradeStore } from '~/store'

export default {
  name: 'CalendarThematicPlan',
  components: {
    DefaultList,
    KtpFilter,
  },
  data() {
    return {
      headers: ['№ п/п', 'Дата', 'Тема урока', 'Домашнее задание', 'Файлы'],
      testData: [
        {
          date: '10.02.2021',
          theme: 'ФСУ (сумма кубов)',
          homework: 'Сборник задач: стр. 17 (№ 2, 4, 9)',
          files: [],
        },
      ],
      isLoading: false,
    }
  },
  beforeMount() {
    this.loadGradeList()
  },
  methods: {
    ...mapActions(useGradeStore, ['loadGradeList']),
  },
}
</script>

<style lang="scss">
.ktp {
  height: 100%;

  &__main {
    min-height: 90vh;
  }
}
</style>
