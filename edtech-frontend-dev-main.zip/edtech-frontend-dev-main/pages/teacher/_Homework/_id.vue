<template>
  <div class="teacher-homework">
    <h1>
      <span class="teacher-homework__title">Домашние задания</span>
      <img src="~/assets/images/stroke.png" alt="" />
      {{ selectedHomework.subject }} -
      {{ selectedHomework.gradeGroup }}
    </h1>
    <div class="pagesGrid">
      <div class="main-component">
        <HomeworkListCheck></HomeworkListCheck>
      </div>
      <CreateTask
        :selected-homework="selectedHomework"
        :group-list="grade"
      ></CreateTask>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import HomeworkListCheck from '~/components/homeworks/HomeworkListCheck.vue'
import CreateTask from '~/components/homeworks/CreateTask.vue'
import { useHomeworkStore } from '~/store'
import { SelectedHomeworkTeacher } from '~/models/homework.model'
import { StudentGrade } from '~/models/grade.model'

export default {
  name: 'HomeworkDetailed',
  components: {
    HomeworkListCheck,
    CreateTask,
  },
  computed: {
    ...mapState(useHomeworkStore, {
      selectedHomework: (store) =>
        SelectedHomeworkTeacher.serialize(store.selectedHomework),
      grade: (store) => StudentGrade.serializeList(store.grade),
      loading: (store) => store.loading,
    }),
  },
  async mounted() {
    await this.setGrade()
  },
  methods: {
    ...mapActions(useHomeworkStore, ['setGrade']),
  },
}
</script>

<style lang="scss">
.teacher-homework {
  &__title {
    color: #8b8b8b;
  }
}
</style>
