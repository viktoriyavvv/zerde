<template>
  <div class="teacher-homework">
    <h1>Домашние задания</h1>
    <div
      class="teacher-homework__main table-main pagesGrid main-component-text"
    >
      <div class="teacher-homework__list list">
        <div>
          <div class="teacher-homework__class-info">
            <v-tabs v-model="tab">
              <v-tab
                @click="
                  setHomeworkState('issued')
                  clickActionFiltered()
                  resetPage()
                "
                >Выданные
              </v-tab>
              <v-tab
                v-if="$nuxt.$auth.user.role !== 'class-teacher'"
                @click="
                  setHomeworkState('not_issued')
                  clickActionFiltered()
                  resetPage()
                "
                >Не выданные
              </v-tab>
              <v-tab
                v-if="$nuxt.$auth.user.role !== 'class-teacher'"
                @click="
                  setHomeworkState('finished')
                  clickActionFiltered()
                  resetPage()
                "
                >Архив
              </v-tab>
            </v-tabs>
          </div>
          <v-divider></v-divider>
        </div>
        <div class="pagination-content">
          <v-tabs-items v-model="tab" class="pagination-content__content">
            <v-tab-item>
              <DefaultList
                :list="homeworkList"
                :headers="headers"
                :loading="loading"
                :page="page"
                class="container"
                type="homework-teacher"
                @selectItem="selectItem"
              />
            </v-tab-item>
            <v-tab-item>
              <DefaultList
                :list="homeworkList"
                :headers="headers"
                :loading="loading"
                :page="page"
                class="container"
                type="homework-teacher"
                @selectItem="selectItem"
              />
            </v-tab-item>
            <v-tab-item>
              <DefaultList
                :list="homeworkList"
                :headers="headers"
                :loading="loading"
                :page="page"
                class="container"
                type="homework-teacher"
                @selectItem="selectItem"
              />
            </v-tab-item>
          </v-tabs-items>
          <v-pagination
            v-model="page"
            :length="homeworksPages"
            :total-visible="7"
            color="#003a70"
            class="pagination-content__pagination"
            @input="loadHomeworkPaginated(), setCreateMode(false)"
          ></v-pagination>
        </div>
      </div>
      <TaskFilter
        v-if="!create && !patch"
        :subjects="subjectList"
        :grades="gradeList"
        @filterListTeacher="filterListTeacher"
        @setMode="changeMode"
      />
      <CreateTask
        v-else-if="create && !patch"
        :create-mode="create"
        :patch-mode="patch"
        :tab-value="tabValue"
      />
      <CreateTask
        v-else-if="!create && patch"
        :create-mode="create"
        :patch-mode="patch"
        :tab-value="tabValue"
        :selected-homework="selectedHomework2"
      />
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'pinia'
import { useHomeworkStore, useSubjectStore, useGradeStore } from '~/store'
import { HomeworkTeacher } from '~/models/homework.model'
import { Subject } from '~/models/subject.model'
import TaskFilter from '~/components/tasks/TaskFilter.vue'
import DefaultList from '~/components/main/DefaultList.vue'
import CreateTask from '~/components/homeworks/CreateTask'

export default {
  name: 'HomeworkTeacher',
  components: { CreateTask, TaskFilter, DefaultList },
  middleware: ['authTeacher'],
  data: () => ({
    tab: null,
    tabValue: 'issued',
    subjectFilterValue: '',
    gradeFilterValue: '',
    resetValue: true,
    headers: [
      '№',
      'Предмет',
      'Класс',
      'Группа',
      'Описание',
      'Срок выполнения',
      'Статистика',
    ],
    taskGrade: '',
    taskSubject: '',
    page: 1,
  }),
  computed: {
    ...mapState(useHomeworkStore, {
      homeworkList: (store) => HomeworkTeacher.serializeList(store.homeworks),
      selectedHomeworkUuid: (store) => store.selectedHomeworkUuid,
      selectedHomework2: (store) => store.getSelectedHomework,
      create: (store) => store.createMode,
      patch: (store) => store.patchMode,
      loading: (store) => store.loading,
      homeworksPages: (store) => {
        const count = Math.ceil(store.homeworksCount)
        if (count < 1) {
          return 1
        } else return count
      },
    }),
    ...mapState(useSubjectStore, {
      subjectList: (store) => Subject.serializeList(store.subjects),
    }),
    ...mapState(useGradeStore, {
      gradeList: (store) => store.gradeList,
      gradeGroupList: (store) => store.gradeGroupList,
    }),
  },
  mounted() {
    this.setHomework(this.tabValue, 0)
    this.setSubjects()
    this.loadGradeList()
    this.loadGradeGroupList()
  },
  methods: {
    ...mapActions(useHomeworkStore, [
      'setHomework',
      'setFilteredHomeworkTeacher',
      'setSelectedHomework',
      'setCreateMode',
      'setPatchMode',
    ]),
    ...mapActions(useSubjectStore, ['setSubjects']),
    ...mapActions(useGradeStore, ['loadGradeList', 'loadGradeGroupList']),
    async selectItem(homeworkUuid) {
      await this.setSelectedHomework()
      if (this.tabValue === 'not_issued') {
        this.setPatchMode(true)
      }
    },
    filterListTeacher(subject, grade, reset) {
      this.resetValue = reset
      this.subjectFilterValue = subject
      this.gradeFilterValue = grade
      this.resetPage()
      if (!reset) {
        this.setFilteredHomeworkTeacher(
          this.tabValue,
          subject,
          grade,
          this.page - 1
        )
      } else {
        this.setHomework(this.tabValue)
      }
    },
    setHomeworkState(tabTxt) {
      this.tabValue = tabTxt
    },
    clickActionFiltered() {
      if (this.resetValue) {
        this.setHomework(this.tabValue)
      } else {
        this.setFilteredHomeworkTeacher(
          this.tabValue,
          this.subjectFilterValue,
          this.gradeFilterValue,
          this.page - 1
        )
      }
    },
    changeMode(value) {
      this.setCreateMode(value)
    },
    resetPage() {
      this.page = 1
    },
    loadHomeworkPaginated() {
      if (this.resetValue) {
        this.setHomework(this.tabValue, this.page - 1)
      } else {
        this.setFilteredHomeworkTeacher(
          this.tabValue,
          this.subjectFilterValue,
          this.gradeFilterValue,
          this.page - 1
        )
      }
    },
  },
}
</script>
