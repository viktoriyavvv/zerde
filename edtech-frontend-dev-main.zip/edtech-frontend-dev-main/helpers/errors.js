export const errorNames = {
  'Incorrect email or password.':
    'Неправильный адрес электронной почты или пароль.',
  'Enter a valid email address.': 'Введите корректный электронный адрес.',
  'Incorrect password.': 'Неверный пароль',
  'The password is too similar to the email address.':
    'Пароль слишком похож на адрес электронной почты.',
  'The password is too similar to the first name.':
    'Пароль слишком похож на имя.',
  'Ensure this field has no more than 128 characters.':
    'Пожалуйста, используйте не более 128 символов.',
}
