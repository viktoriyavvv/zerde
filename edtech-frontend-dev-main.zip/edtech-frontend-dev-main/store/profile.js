import { defineStore } from 'pinia'

export const useProfileStore = defineStore({
  id: 'profile',
  state: () => {
    return {
      profile: {},
      profilePic: '',
      loading: true,
    }
  },
  getters: {
    getProfile: (state) => state.profile,
  },

  actions: {
    setProfile(profile) {
      this.$patch({
        profile: {
          ...profile,
        },
      })
    },
    async loadProfile() {
      await this.$nuxt.$axios
        .get('/accounts/me/student/')
        .then((response) => {
          this.setProfile(response.data)
          this.loadProfilePic(response.data.image)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },
    async loadProfilePic(url) {
      await this.$nuxt.$axios
        .get(url, { responseType: 'blob' })
        .then((response) => {
          this.$patch({
            profilePic: URL.createObjectURL(response.data),
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
  },
})
