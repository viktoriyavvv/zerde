import { defineStore } from 'pinia'

export const useAssignmentStore = defineStore({
  id: 'assignment',
  state: () => {
    return {
      assignments: [],
      loading: true,
    }
  },
  actions: {
    setAssignment(assignments) {
      this.$patch({
        assignments: [...assignments],
      })
    },
    async loadAssignment() {
      this.$patch({
        loading: true,
      })
      const res = await this.$nuxt.$axios
        .get(`/mark/assignment-marks/${this.$nuxt.$auth.user.role}/`)
        .then((response) => {
          this.setAssignment(response.data.results)
        })
        .catch(function (error) {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })

      return res
    },
  },
})
