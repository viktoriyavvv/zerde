import { defineStore } from 'pinia'

export const useAdminStore = defineStore({
  id: 'admin',
  state: () => {
    return {
      teacherProfiles: [],
    }
  },
  actions: {
    async loadTeacherProfile() {
      await this.$nuxt.$axios
        .get('/accounts/teacher-profiles/admin/')
        .then((response) => {
          this.$patch({
            teacherProfiles: [...response.data.results],
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
  },
})
