import { defineStore } from 'pinia'
import { SelectedHomeworkTeacher } from '~/models/homework.model'

export const useHomeworkStore = defineStore({
  id: 'homework',
  state: () => ({
    selectedHomeworkUuid: '',
    selectedHomework: [],
    homeworks: [],
    grade: [],
    filesUuid: [],
    mode: false,
    filesID: [],
    successReply: false,
    studentReply: [],
    studentReplies: [],
    createMode: false,
    patchMode: false,
    loading: true,
    loadingDetails: false,
    homeworksCount: 0,
    toLongName: false,
  }),

  getters: {
    getHomeworks: (state) => state.homeworks,
    getSelectedHomeworkUuid: (state) => state.selectedHomeworkUuid,
    getSelectedHomework: (state) => {
      return SelectedHomeworkTeacher.serialize(state.selectedHomework)
    },
    getGrade: (state) => state.grade,
  },

  actions: {
    setMode() {
      this.$patch({
        mode: !this.mode,
        successReply: false,
      })
    },
    setCreateMode(mode) {
      this.$patch({
        createMode: mode,
      })
    },
    setPatchMode(mode) {
      this.$patch({
        patchMode: mode,
      })
    },

    /**
     * @param {Array} homeworks
     */
    async setHomework(homeworkState, offset) {
      this.$patch({
        loading: true,
      })
      await this.$nuxt.$axios
        .get(
          `homework/assignments/${
            this.$nuxt.$auth.user.role
          }/?state=${homeworkState}&limit=20&offset=${offset * 20}`
        )
        .then((response) => {
          this.$patch({
            homeworks: [...response.data.results],
            homeworksCount: response.data.count / 20,
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },

    async setFilteredHomeworkTeacher(
      homeworkState,
      homeworkSubject,
      homeworkGrade,
      offset
    ) {
      this.$patch({
        homeworks: [],
        loading: true,
      })
      let params = new URLSearchParams([])
      if (!homeworkGrade.uuid && homeworkSubject.uuid) {
        params = new URLSearchParams([
          ['state', homeworkState],
          ['subject', homeworkSubject.uuid],
          ['limit', 20],
          ['offset', offset * 20],
        ])
      } else if (homeworkGrade.uuid && !homeworkSubject.uuid) {
        params = new URLSearchParams([
          ['state', homeworkState],
          ['grade', homeworkGrade.uuid],
          ['limit', 20],
          ['offset', offset * 20],
        ])
      } else {
        params = new URLSearchParams([
          ['state', homeworkState],
          ['subject', homeworkSubject.uuid],
          ['grade', homeworkGrade.uuid],
          ['limit', 20],
          ['offset', offset * 20],
        ])
      }
      await this.$nuxt.$axios
        .get(`homework/assignments/${this.$nuxt.$auth.user.role}/`, { params })
        .then((response) => {
          this.$patch({
            homeworks: [...response.data.results],
            homeworksCount: response.data.count / 20,
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },

    async setFilteredHomeworkStudent(
      homeworkState,
      homeworkSubject,
      homeworkDate,
      offset
    ) {
      this.$patch({
        homeworks: [],
        loading: true,
      })
      let params = new URLSearchParams([])
      if (homeworkDate.length === 0 && homeworkSubject.uuid) {
        params = new URLSearchParams([
          ['state', homeworkState],
          ['subject', homeworkSubject.uuid],
          ['limit', 20],
          ['offset', offset * 20],
        ])
      } else if (homeworkDate.length === 2 && !homeworkSubject.uuid) {
        params = new URLSearchParams([
          ['state', homeworkState],
          ['deadline_before', homeworkDate[1]],
          ['deadline_after', homeworkDate[0]],
          ['limit', 20],
          ['offset', offset * 20],
        ])
      } else {
        params = new URLSearchParams([
          ['state', homeworkState],
          ['subject', homeworkSubject.uuid],
          ['deadline_before', homeworkDate[1]],
          ['deadline_after', homeworkDate[0]],
          ['limit', 20],
          ['offset', offset * 20],
        ])
      }
      await this.$nuxt.$axios
        .get(`homework/assignments/student/`, { params })
        .then((response) => {
          this.$patch({
            homeworks: [...response.data.results],
            homeworksCount: response.data.count / 20,
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },

    async setSelectedHomework(hwId) {
      this.$patch({
        loading: true,
      })
      this.$patch({
        selectedHomework: [],
      })
      await this.$nuxt.$axios
        .get(`homework/assignments/${hwId}/${this.$nuxt.$auth.user.role}/`)
        .then((response) => {
          this.$patch({
            selectedHomework: response.data,
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },

    async editHomeworkMark(commentTxt, mark, uuid) {
      const postData = {
        comment: commentTxt,
        mark_value: mark,
      }
      try {
        await this.$nuxt.$axios.patch(
          `/mark/assignment-marks/${uuid}/teacher-or-admin/`,
          JSON.stringify(postData),
          {
            headers: {
              Accept: 'application/json',
              'Content-Type': 'application/json',
            },
          }
        )
      } catch (error) {
        alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
      }
    },
    async rateHomework(student, comments, mark, homework) {
      const postData = {
        comment: comments,
        mark_value: mark,
        max_mark_value: 10,
        student_profile: student,
        assignment: homework,
      }
      try {
        await this.$nuxt.$axios.post(
          `/mark/assignment-marks/teacher-or-admin/`,
          JSON.stringify(postData),
          {
            headers: {
              Accept: 'application/json',
              'Content-Type': 'application/json',
            },
          }
        )
      } catch (error) {
        alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
      }
    },

    setSelectedHomeworkUuid(selectedHomeworkIndex) {
      this.$patch({
        selectedHomeworkUuid: selectedHomeworkIndex,
      })
    },

    async setHomeworkDetails() {
      this.$patch({
        loadingDetails: true,
        selectedHomework: {},
        mode: false,
      })
      await this.$nuxt.$axios
        .get(
          `homework/assignments/${this.selectedHomeworkUuid}/${this.$nuxt.$auth.user.role}/`
        )
        .then((response) => {
          this.$patch({
            selectedHomework: response.data,
          })
          if (response.data.student_assignment_replies) {
            this.$patch({
              studentReply: response.data.student_assignment_replies,
            })
          }
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loadingDetails: false,
            mode: true,
          })
        })
    },

    async replyStudent(hw) {
      for (const file of hw.attached_files) {
        await this.uploadFiles(file)
      }
      this.$patch({
        successReply: false,
      })
      const studentReply = {
        attached_files: this.filesID,
        assignment: hw.assignment,
        comment: hw.comment,
      }
      const reply = JSON.stringify(studentReply)
      await this.$nuxt.$axios
        .post(
          `/homework/assignments/student_replies/${this.$nuxt.$auth.user.role}/`,
          reply,
          {
            headers: {
              'Content-Type': 'application/json',
            },
          }
        )
        .then(() => {
          this.$patch({
            successReply: true,
          })
        })
        .catch((error) =>
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        )
    },

    async uploadFiles(file) {
      const attachData = new FormData()
      attachData.append('file_name', file.name)
      attachData.append('file', file)
      await this.$nuxt.$axios
        .post(`/homework/assignments/attached_files/`, attachData, {
          headers: {
            'Content-Type': 'application/json',
          },
        })
        .then((response) => {
          this.filesID.push(response.data.uuid)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },

    async createHomework(task) {
      this.$patch({
        filesID: [],
      })
      let hw = {}
      for (const file of task.attached_files) {
        await this.uploadFiles(file)
      }
      if (task.teacher_profile) {
        hw = {
          teacher_profile: task.teacher_profile,
          subject: task.subject,
          grade: task.grade,
          grade_group: task.grade_group,
          description: task.description,
          attached_files: this.filesID,
          deadline: task.deadline,
          assignment_type: 'homework',
          state: task.state,
        }
      } else {
        hw = {
          subject: task.subject,
          grade: task.grade,
          grade_group: task.grade_group,
          description: task.description,
          attached_files: this.filesID,
          deadline: task.deadline,
          assignment_type: 'homework',
          state: task.state,
        }
      }
      const hwTask = JSON.stringify(hw)
      await this.$nuxt.$axios
        .post(`/homework/assignments/${this.$nuxt.$auth.user.role}/`, hwTask, {
          headers: {
            'Content-Type': 'application/json',
          },
        })
        .then((response) => {
          this.$patch({
            successReply: true,
          })
        })
        .catch((error) => {
          this.$patch({
            filesID: [],
          })
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },

    async editHomework(editedHomework, homeworkId) {
      let hw = {}
      if (editedHomework.attached_files) {
        for (const file of editedHomework.attached_files) {
          await this.uploadFiles(file)
        }
        hw = {
          description: editedHomework.description,
          attached_files: this.filesID,
          deadline: editedHomework.deadlineDate,
          state: editedHomework.state,
        }
      } else {
        hw = editedHomework
      }
      const editedHW = JSON.stringify(hw)
      await this.$nuxt.$axios
        .patch(
          `/homework/assignments/${homeworkId}/${this.$nuxt.$auth.user.role}/`,
          editedHW,
          {
            headers: {
              'Content-Type': 'application/json',
            },
          }
        )
        .then((response) => {
          this.$patch({
            filesID: [],
          })
        })
        .catch((error) => {
          this.$patch({
            filesID: [],
          })
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
      this.$nuxt.redirect(302, `/teacher/Homework`)
    },

    async setGrade() {
      await this.$nuxt.$axios
        .get(`school/grades/${this.$nuxt.$auth.user.role}/`)
        .then((response) => {
          this.$patch({
            grade: [...response.data.results],
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },

    closeHwDetails() {
      this.$patch({
        mode: false,
      })
    },
  },
})
