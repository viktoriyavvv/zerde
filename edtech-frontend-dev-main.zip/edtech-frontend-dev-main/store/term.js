import { defineStore } from 'pinia'

export const useTermStore = defineStore({
  id: 'terms',
  state: () => {
    return {
      terms: [],
      currentTerm: '',
    }
  },
  getters: {
    getTerms: (state) => state.terms,
    getDefaultTermId: (state) => state.defaultTermId,
  },
  actions: {
    setTerms(terms) {
      const today = new Date()
      let dd = today.getDate()
      let mm = today.getMonth() + 1
      const yyyy = today.getFullYear()
      if (dd < 10) {
        dd = '0' + dd
      }
      if (mm < 10) {
        mm = '0' + mm
      }
      const currentDate = yyyy + '-' + mm + '-' + dd
      const currentTermValue = terms.find(
        (e) => e.start_date < currentDate && e.end_date > currentDate
      )
      if (currentTermValue === undefined) {
        this.$patch({
          terms: [...terms],
          currentTerm: terms[0],
        })
      } else {
        this.$patch({
          terms: [...terms],
          currentTerm: currentTermValue,
        })
      }
    },
    async loadTerms() {
      await this.$nuxt.$axios
        .get(`/schedule/quarters/`)
        .then((response) => {
          this.setTerms(response.data.results)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
  },
})
