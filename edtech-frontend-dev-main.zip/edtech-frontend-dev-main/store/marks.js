import { defineStore } from 'pinia'

export const useMarksStore = defineStore({
  id: 'marks',
  state: () => {
    return {
      quarterMarks: [],
      yearMarks: [],
      subjectMarks: [],
      subjectMarksOnly: [],
      subjectMarksOnlyAttendance: [],
      errorStatus: false,
      currentQuarter: '',
      loading: true,
      messageStatus: true,
    }
  },
  actions: {
    /**
     * @param {Array} marks
     */

    async loadQuarterMarks(quarterId) {
      this.$patch({
        loading: true,
        currentQuarter: quarterId,
        quarterMarks: [],
        yearMarks: [],
        subjectMarks: [],
        subjectMarksOnly: [],
        subjectMarksOnlyAttendance: [],
      })
      await this.$nuxt.$axios
        .get(`mark/student-mark-books/quarters/${quarterId}/`)
        .then((response) => {
          this.$patch({
            quarterMarks: [...response.data.results],
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },

    async loadYearMarks() {
      this.$patch({
        loading: true,
        quarterMarks: [],
        yearMarks: [],
        subjectMarks: [],
        subjectMarksOnly: [],
        subjectMarksOnlyAttendance: [],
      })
      await this.$nuxt.$axios
        .get(`mark/student-mark-books/school-years/`)
        .then((response) =>
          this.$patch({
            yearMarks: [...response.data.results],
          })
        )
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },

    async loadSubjectMarks(subject, quarter) {
      this.$patch({
        loading: true,
        quarterMarks: [],
        yearMarks: [],
        subjectMarks: [],
        subjectMarksOnly: [],
        subjectMarksOnlyAttendance: [],
      })
      await this.$nuxt.$axios
        .get(`mark/student-mark-books/quarters/${quarter}/subjects/${subject}/`)
        .then((response) => {
          if (response.data.student_marks.length !== 0) {
            this.$patch({
              subjectMarksOnlyAttendance: response.data.attendances,
              subjectMarksOnly: response.data.student_marks,
              subjectMarks: response.data,
              errorStatus: false,
              messageStatus: false,
            })
          } else {
            this.$patch({
              errorStatus: true,
            })
          }
        })
        .catch((error) => {
          this.$patch({
            errorStatus: true,
          })
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },
  },
})
