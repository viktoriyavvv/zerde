import { defineStore } from 'pinia'

export const useScheduleStore = defineStore({
  id: 'schedule',
  state: () => {
    return {
      schedule: [],
      scheduleBy: [],
      scheduleDay: [],
      loading: false,
    }
  },
  getters: {
    getSchedule: (state) => state.schedule,
  },
  actions: {
    setSchedule(schedule) {
      this.$patch({
        schedule: [...schedule],
      })
    },

    setScheduleBy(schedule) {
      this.$patch({
        scheduleBy: [...schedule],
      })
    },

    setScheduleDay(schedule) {
      this.$patch({
        scheduleDay: [...schedule],
      })
    },

    async loadSchedule() {
      this.$patch({
        loading: true,
      })
      const curr = new Date()
      const firstday = curr.getDate() - curr.getDay() + 1
      const formattedLastDay = new Date(curr.setDate(firstday))
        .toISOString()
        .substring(0, 10)
      const lastday = new Date(curr.setDate(firstday + 6))
        .toISOString()
        .substring(0, 10)
      await this.$nuxt.$axios
        .get(`/schedule/scheduled-subjects/${this.$nuxt.$auth.user.role}/`, {
          params: {
            date_after: formattedLastDay,
            date_before: lastday,
            limit: 6,
          },
        })
        .then((response) => {
          this.setSchedule(response.data.results)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },

    async loadScheduleByDates(dates, byParam, activeSchedule) {
      this.$patch({
        loading: true,
      })
      if (dates.length === 2) {
        if (byParam === '' || byParam === undefined) {
          await this.$nuxt.$axios
            .get(
              `/schedule/scheduled-subjects/${this.$nuxt.$auth.user.role}/`,
              {
                params: {
                  date_after: dates[0],
                  date_before: dates[1],
                  limit: 6,
                },
              }
            )
            .then((response) => {
              if (
                this.$nuxt.$auth.user.role === 'student' ||
                this.$nuxt.$auth.user.role === 'teacher'
              ) {
                this.setSchedule(response.data.results)
              } else {
                this.setScheduleBy(response.data.results)
              }
            })
            .catch((error) => {
              alert(
                'Произошла ошибка, пожалуйста, перезагрузите страницу.',
                error
              )
            })
            .then(() => {
              this.$patch({
                loading: false,
              })
            })
        } else {
          let params = {}
          if (activeSchedule === 'grade') {
            params = {
              date_after: dates[0],
              date_before: dates[1],
              limit: 6,
              grade: byParam,
            }
          } else if (activeSchedule === 'classroom') {
            params = {
              date_after: dates[0],
              date_before: dates[1],
              limit: 6,
              classroom: byParam,
            }
          } else if (activeSchedule === 'teacher') {
            params = {
              date_after: dates[0],
              date_before: dates[1],
              limit: 6,
              teacher_profile: byParam,
            }
          }
          await this.$nuxt.$axios
            .get(
              `/schedule/scheduled-subjects/${this.$nuxt.$auth.user.role}/`,
              { params }
            )
            .then((response) => {
              this.setScheduleBy(response.data.results)
            })
            .catch((error) => {
              alert(
                'Произошла ошибка, пожалуйста, перезагрузите страницу.',
                error
              )
            })
            .then(() => {
              this.$patch({
                loading: false,
              })
            })
        }
      }
    },

    async loadScheduleByClassroom(roomNumber, dateRange) {
      this.$patch({
        loading: true,
      })
      if (dateRange === undefined) {
        const curr = new Date()
        const firstday = curr.getDate() - curr.getDay() + 1
        const formattedLastDay = new Date(curr.setDate(firstday))
          .toISOString()
          .substring(0, 10)
        const lastday = new Date(curr.setDate(firstday + 6))
          .toISOString()
          .substring(0, 10)
        await this.$nuxt.$axios
          .get(`/schedule/scheduled-subjects/${this.$nuxt.$auth.user.role}/`, {
            params: {
              date_after: formattedLastDay,
              date_before: lastday,
              classroom: roomNumber,
            },
          })
          .then((response) => {
            this.setScheduleBy(response.data.results)
          })
          .catch((error) => {
            alert(
              'Произошла ошибка, пожалуйста, перезагрузите страницу.',
              error
            )
          })
          .then(() => {
            this.$patch({
              loading: false,
            })
          })
      } else {
        await this.$nuxt.$axios
          .get(`/schedule/scheduled-subjects/${this.$nuxt.$auth.user.role}/`, {
            params: {
              date_after: dateRange[0],
              date_before: dateRange[1],
              classroom: roomNumber,
            },
          })
          .then((response) => {
            this.setScheduleBy(response.data.results)
          })
          .catch((error) => {
            alert(
              'Произошла ошибка, пожалуйста, перезагрузите страницу.',
              error
            )
          })
          .then(() => {
            this.$patch({
              loading: false,
            })
          })
      }
    },

    async loadScheduleByGrade(gradeSel, dates) {
      this.$patch({
        loading: true,
      })
      const curr = new Date()
      const firstday = curr.getDate() - curr.getDay() + 1
      const formattedLastDay = new Date(curr.setDate(firstday))
        .toISOString()
        .substring(0, 10)
      const lastday = new Date(curr.setDate(firstday + 6))
        .toISOString()
        .substring(0, 10)
      if (dates === undefined) {
        await this.$nuxt.$axios
          .get(`/schedule/scheduled-subjects/${this.$nuxt.$auth.user.role}/`, {
            params: {
              date_after: formattedLastDay,
              date_before: lastday,
              grade: gradeSel,
              limit: 6,
            },
          })
          .then((response) => {
            this.setScheduleBy(response.data.results)
          })
          .catch((error) => {
            alert(
              'Произошла ошибка, пожалуйста, перезагрузите страницу.',
              error
            )
          })
          .then(() => {
            this.$patch({
              loading: false,
            })
          })
      } else {
        await this.$nuxt.$axios
          .get(`/schedule/scheduled-subjects/${this.$nuxt.$auth.user.role}/`, {
            params: {
              date_after: dates[0],
              date_before: dates[1],
              grade: gradeSel,
              limit: 6,
            },
          })
          .then((response) => {
            this.setScheduleBy(response.data.results)
          })
          .catch((error) => {
            alert(
              'Произошла ошибка, пожалуйста, перезагрузите страницу.',
              error
            )
          })
          .then(() => {
            this.$patch({
              loading: false,
            })
          })
      }
    },

    async loadScheduleByTeacher(uuid, dateRange) {
      if (dateRange === undefined) {
        const curr = new Date()
        const firstday = curr.getDate() - curr.getDay() + 1
        const formattedLastDay = new Date(curr.setDate(firstday))
          .toISOString()
          .substring(0, 10)
        const lastday = new Date(curr.setDate(firstday + 6))
          .toISOString()
          .substring(0, 10)
        await this.$nuxt.$axios
          .get(`/schedule/scheduled-subjects/${this.$nuxt.$auth.user.role}/`, {
            params: {
              date_after: formattedLastDay,
              date_before: lastday,
              teacher_profile: uuid,
            },
          })
          .then((response) => {
            this.setScheduleBy(response.data.results)
          })
          .catch((error) => {
            alert(
              'Произошла ошибка, пожалуйста, перезагрузите страницу.',
              error
            )
          })
          .then(() => {
            this.$patch({
              loading: false,
            })
          })
      } else {
        await this.$nuxt.$axios
          .get(`/schedule/scheduled-subjects/${this.$nuxt.$auth.user.role}/`, {
            params: {
              date_after: dateRange[0],
              date_before: dateRange[1],
              teacher_profile: uuid,
            },
          })
          .then((response) => {
            this.setScheduleBy(response.data.results)
          })
          .catch((error) => {
            alert(
              'Произошла ошибка, пожалуйста, перезагрузите страницу.',
              error
            )
          })
          .then(() => {
            this.$patch({
              loading: false,
            })
          })
      }
    },

    async loadScheduleByDate(day) {
      await this.$nuxt.$axios
        .get(`/schedule/scheduled-subjects/${this.$nuxt.$auth.user.role}/`, {
          params: {
            date: day,
          },
        })

        .then((response) => {
          this.setScheduleDay(response.data.results)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },
  },
})

export const useBellrangSchedule = defineStore({
  id: 'bellrang',
  state: () => {
    return {
      bellrang: [],
    }
  },
  getters: {
    getBellrang: (state) => state.bellrang,
  },

  actions: {
    setBellrang(bellrang) {
      this.$patch({
        bellrang: [...bellrang],
      })
    },
    async loadBellrang() {
      await this.$nuxt.$axios
        .get(`/schedule/schedule-times/`)
        .then((response) => {
          this.setBellrang(response.data.results)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
  },
})

export const useClassTeacherGradesStore = defineStore({
  id: 'gradeGroup',
  state: () => {
    return {
      gradeList: [],
      gradeNameList: [],
    }
  },

  actions: {
    setGrade(grades) {
      this.$patch({
        gradeList: [...grades],
      })
    },
    async loadGrade() {
      await this.$nuxt.$axios
        .get(`/school/grades/${this.$nuxt.$auth.user.role}/`)
        .then((response) => {
          this.setGrade(response.data.results)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
  },
})

export const useClassroomStore = defineStore({
  id: 'classroom',
  state: () => {
    return {
      classroomList: [],
    }
  },
  actions: {
    setClassroom(rooms) {
      this.$patch({
        classroomList: [...rooms],
      })
    },

    async loadClassroom() {
      await this.$nuxt.$axios
        .get('/school/classrooms/')
        .then((response) => {
          this.setClassroom(response.data.results)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
  },
})

export const useTeacherListStore = defineStore({
  id: 'teachers',
  state: () => {
    return {
      teacherList: [],
    }
  },
  actions: {
    setTeachers(teachers) {
      this.$patch({
        teacherList: [...teachers],
      })
    },

    async loadTeachers() {
      await this.$nuxt.$axios
        .get('/accounts/teacher-profiles/admin/')
        .then((response) => {
          this.setTeachers(response.data.results)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
  },
})
