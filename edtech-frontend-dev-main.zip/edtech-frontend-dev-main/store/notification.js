import { defineStore } from 'pinia'

export const useNotificationStore = defineStore({
  id: 'notifications',
  state: () => {
    return {
      notifications: [],
    }
  },
  actions: {
    setNotifications(notifications) {
      this.$patch({
        notifications: [...notifications],
      })
    },
    async loadNotifications() {
      await this.$nuxt.$axios
        .get('/school/notifications/')
        .then((response) => {
          this.setNotifications(response.data.results)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
  },
})
