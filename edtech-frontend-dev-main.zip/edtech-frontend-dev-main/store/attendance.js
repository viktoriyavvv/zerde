import { defineStore } from 'pinia'

export const useAttendanceStore = defineStore({
  id: 'attendance',
  state: () => {
    return {
      attendanceQuarters: [],
      attendanceYear: [],
      attendance: [],
      loading: true,
    }
  },
  actions: {
    /**
     * @param {Array} attendance
     */
    async setAttendanceYear() {
      await this.$nuxt.$axios
        .get(`schedule/school-years/attendance/student/`)
        .then((response) => {
          this.$patch({
            attendanceQuarters: [...response.data.quarters],
            attendanceYear: response.data.school_year_attendance,
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },

    setAttendance(attendances) {
      this.$patch({
        attendance: attendances,
      })
    },

    async loadAttendance() {
      this.$patch({
        loading: true,
      })
      await this.$nuxt.$axios
        .get(`/mark/attendances/${this.$nuxt.$auth.user.role}/`)
        .then((response) => {
          this.setAttendance(response.data)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },
  },
})
