import { defineStore } from 'pinia'

export const useClassTeacherStore = defineStore({
  id: 'classTeacher',
  state: () => ({
    studentList: [],
    gradeList: [],
    defaultGradeId: '',
    defaultGrade: '',
    defaultClassTeacherName: '',
    loading: true,
    studentCount: 0,
  }),

  getters: {
    getStudentList: (state) => state.studentList,
    getGradeList: (state) => state.gradeList,
  },

  actions: {
    async setGradeList() {
      this.gradeList = []
      await this.$nuxt.$axios
        .get(`school/grades/${this.$nuxt.$auth.user.role}/`)
        .then((response) => {
          this.$patch({
            gradeList: [...response.data.results],
            defaultGradeId: response.data.results[0].uuid,
            defaultGrade: response.data.results[0],
            defaultClassTeacherName:
              response.data.results[0].class_teacher_profile.user_account
                .last_name +
              ' ' +
              response.data.results[0].class_teacher_profile.user_account
                .first_name,
          })
          this.setStudentList(this.defaultGradeId)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
    async setStudentList(gradeId, offset) {
      this.$patch({
        loading: true,
        studentList: [],
      })
      const params = new URLSearchParams([
        ['grade', gradeId],
        ['offset', offset * 20],
        ['limit', 20],
      ])
      await this.$nuxt.$axios
        .get(`accounts/student-profiles/${this.$nuxt.$auth.user.role}/`, {
          params,
        })
        .then((response) => {
          this.$patch({
            studentList: [...response.data.results],
            studentCount: response.data.count / 20,
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },
  },
})
