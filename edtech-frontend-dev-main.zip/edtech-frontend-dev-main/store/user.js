import { defineStore } from 'pinia'
import { useProfileStore } from './profile'

export const useUserStore = defineStore({
  id: 'user',
  state: () => {
    return {
      user: null,
    }
  },

  getters: {
    getUser: (state) => state.user,
    loggedIn: (state) => state.user !== null,
  },

  actions: {
    /**
     * @param {object} user
     */
    setUser(userData) {
      this.$patch({
        user: {
          ...userData,
        },
      })
    },
    clearUser() {
      this.$patch({
        user: {},
      })
    },
    async logout() {
      await this.$nuxt.$auth.logout()
      this.$reset()
      useProfileStore().$reset()
      this.$nuxt.redirect('/auth/login/')
    },
  },
})
