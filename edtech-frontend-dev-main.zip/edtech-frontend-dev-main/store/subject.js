import { defineStore } from 'pinia'

export const useSubjectStore = defineStore({
  id: 'subject',
  state: () => ({
    subjects: [],
  }),

  getters: {
    getSubjects: (state) => state.subjects,
  },

  actions: {
    /**
     * @param {Array} subjects
     */
    async setSubjects() {
      await this.$nuxt.$axios
        .get(`/school/subjects/${this.$nuxt.$auth.user.role}/`)
        .then((response) => {
          this.$patch({
            subjects: [...response.data.results],
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
  },
})
