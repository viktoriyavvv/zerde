import { defineStore } from 'pinia'
import { SchoolYear } from '@/models/journalYear.model'
import { Journal } from '@/models/journal.model'

export const useJournalStore = defineStore({
  id: 'journal',
  state: () => {
    return {
      grades: [],
      subjects: [],
      quarters: [],
      markType: [],
      journal: {
        uuid: null,
        student_mark_books: [],
      },
      by_term: false,
      schoolYear: {
        uuid: null,
        student_mark_books: [],
      },
    }
  },
  getters: {
    schoolYearGetter(state) {
      return SchoolYear.serialize(state.schoolYear)
    },
    journalGetter(state) {
      return Journal.serialize(state.journal)
    },
  },
  actions: {
    changeByTerm(val) {
      this.$patch({
        by_term: val,
      })
    },
    async loadJournal(grades, subjects, quarters) {
      const res = await this.$nuxt.$axios.get(
        `/mark/grade_books/grades/${grades}/subjects/${subjects}/quarters/${quarters}/`
      )

      this.setJournal(res.data)
      this.$patch({
        by_term: res.data.by_term,
      })
    },
    setJournal(filteredJournal) {
      this.$patch({
        journal: { ...filteredJournal },
      })
    },
    async getQuarters() {
      const res = await this.$nuxt.$axios.get('/schedule/quarters/')
      this.setQuarters(res.data.results)
    },
    setQuarters(quarters) {
      this.$patch({
        quarters: [...quarters],
      })
    },
    async getSubjects() {
      const res = await this.$nuxt.$axios.get('/school/subjects/teacher/')
      this.setSubjects(res.data.results)
    },
    setSubjects(subjects) {
      this.$patch({
        subjects: [...subjects],
      })
    },
    async getSubjectsClassTeacher() {
      const res = await this.$nuxt.$axios.get('/school/subjects/class-teacher/')
      this.setSubjectsClassTeacher(res.data.results)
    },
    setSubjectsClassTeacher(subjects) {
      this.$patch({
        subjects: [...subjects],
      })
    },
    async getGrades() {
      const res = await this.$nuxt.$axios.get('/school/grades/teacher/')
      this.setGrades(res.data.results)
    },
    setGrades(grades) {
      this.$patch({
        grades: [...grades],
      })
    },
    async getGradesClassTeacher() {
      const res = await this.$nuxt.$axios.get('/school/grades/class-teacher/')
      this.setGradesClassTeacher(res.data.results)
    },
    setGradesClassTeacher(grades) {
      this.$patch({
        grades: [...grades],
      })
    },
    async getSchoolYear(gradeUuid, subjectUuid) {
      this.$patch({
        schoolYear: {},
      })
      const res = await this.$nuxt.$axios.get(
        `/mark/grade_books/grades/${gradeUuid}/subjects/${subjectUuid}/school-year/`
      )
      this.$patch({
        schoolYear: { ...res.data },
        by_term: res.data.by_term,
      })
    },
    setSchoolYear(schoolYear) {
      this.$patch({
        schoolYear: { ...schoolYear },
      })
    },
    async createQuarterMark(studentMarkBook, markValue, quarter) {
      let data = {}
      data = {
        student_mark_book: studentMarkBook,
        mark_value: markValue,
        quarter,
      }
      await this.$nuxt.$axios.post(
        '/mark/student-quarter-marks/teacher-or-admin/',
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async deleteQuarterMark(uuid) {
      await this.$nuxt.$axios.delete(
        `/mark/student-quarter-marks/${uuid}/delete/teacher-or-admin/`
      )
    },
    async patchQuarterMark(markValue, uuid) {
      let data = {}
      data = {
        uuid,
        mark_value: markValue,
      }
      await this.$nuxt.$axios.patch(
        `/mark/student-quarter-marks/${uuid}/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async createYearMark(studentMarkBook, markValue) {
      let data = {}
      data = {
        student_mark_book: studentMarkBook,
        mark_value: markValue,
      }
      await this.$nuxt.$axios.post(
        '/mark/student-school-year-marks/teacher-or-admin/',
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async deleteYearMark(uuid) {
      await this.$nuxt.$axios.$delete(
        `/mark/student-school-year-marks/${uuid}/delete/teacher-or-admin/`
      )
    },
    async patchYearMark(markValue, uuid) {
      const data = {
        mark_value: markValue,
        uuid,
      }

      await this.$nuxt.$axios.patch(
        `/mark/student-school-year-marks/${uuid}/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async createExamMarks(maxScoreValue, gradeBook) {
      const data = {
        max_score_value: maxScoreValue,
        grade_book: gradeBook,
      }
      await this.$nuxt.$axios.post(
        '/mark/exam-marks/teacher-or-admin/',
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async patchExamMarks(maxScoreValue, uuid) {
      const data = {
        max_score_value: maxScoreValue,
        uuid,
      }

      await this.$nuxt.$axios.patch(
        `/mark/exam-marks/${uuid}/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async deleteExamMarks(uuid) {
      await this.$nuxt.$axios.delete(
        `/mark/exam-marks/${uuid}/delete/teacher-or-admin/`
      )
    },
    async createStudentExamMarkScore(
      examMark,
      studentMarkBook,
      markValue,
      scoreValue,
      comment
    ) {
      const data = {
        exam_mark: examMark,
        student_mark_book: studentMarkBook,
        mark_value: markValue,
        score_value: scoreValue,
        comment,
      }
      await this.$nuxt.$axios.post(
        '/mark/student-exam-marks/teacher-or-admin/',
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async patchStudentExamMarkScore(scoreValue, markValue, comment, uuid) {
      const data = {
        score_value: scoreValue,
        mark_value: markValue,
        comment,
        uuid,
      }

      await this.$nuxt.$axios.patch(
        `/mark/student-exam-marks/${uuid}/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async deleteStudentExamMark(uuid) {
      await this.$nuxt.$axios.delete(
        `/mark/student-exam-marks/${uuid}/delete/teacher-or-admin/`
      )
    },
    async createFinalMarks(studentMarkBook, markValue) {
      const data = {
        student_mark_book: studentMarkBook,
        mark_value: markValue,
      }
      await this.$nuxt.$axios.post(
        '/mark/student-final-marks/teacher-or-admin/',
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async patchFinalMarks(markValue, uuid) {
      const data = {
        mark_value: markValue,
        uuid,
      }
      await this.$nuxt.$axios.patch(
        `/mark/student-final-marks/${uuid}/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async deleteFinalMarks(uuid) {
      await this.$nuxt.$axios.$delete(
        `/mark/student-final-marks/${uuid}/delete/teacher-or-admin/`
      )
    },
    async createStudentMark(studentMarkBook, markValue, comment, mark) {
      const data = {
        student_mark_book: studentMarkBook,
        mark_value: markValue,
        comment,
        mark,
      }

      await this.$nuxt.$axios.post(
        '/mark/student-marks/teacher-or-admin/',
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async deleteStudentMark(uuid) {
      await this.$nuxt.$axios.$delete(
        `/mark/student-marks/${uuid}/delete/teacher-or-admin/`
      )
    },
    async patchStudentMark(uuid, markValue, comment) {
      const data = {
        uuid,
        mark_value: markValue,
        comment,
      }

      await this.$nuxt.$axios.patch(
        `/mark/student-marks/${uuid}/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async patchMarkGradeBooks(uuid, byTerm) {
      const data = {
        uuid,
        by_term: byTerm,
      }
      const res = await this.$nuxt.$axios.patch(
        `/mark/grade_books/${uuid}/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
      this.$patch({
        by_term: res.data.by_term,
      })
    },
    async createQuizMarks(gradeBook, quizMarkType, quarter, maxMarkValue) {
      const data = {
        grade_book: gradeBook,
        quiz_mark_type: quizMarkType,
        quarter,
        max_mark_value: maxMarkValue,
      }
      await this.$nuxt.$axios.post(
        `/mark/quiz-marks/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async patchQuizMarks(maxMarkValue, uuid) {
      const data = {
        max_mark_value: maxMarkValue,
        uuid,
      }
      await this.$nuxt.$axios.patch(
        `/mark/quiz-marks/${uuid}/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async deleteQuizMarks(uuid) {
      await this.$nuxt.$axios.$delete(
        `/mark/quiz-marks/${uuid}/delete/teacher-or-admin/`
      )
    },
    async createStudentQuizMarks(
      studentMarkBook,
      markValue,
      quizMark,
      comment
    ) {
      const data = {
        student_mark_book: studentMarkBook,
        mark_value: markValue,
        quiz_mark: quizMark,
        comment,
      }
      await this.$nuxt.$axios.post(
        `/mark/student-quiz-marks/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async patchStudentQuizMarks(markValue, comment, uuid) {
      const data = {
        mark_value: markValue,
        comment,
        uuid,
      }
      await this.$nuxt.$axios.patch(
        `/mark/student-quiz-marks/${uuid}/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async deleteStudentQuizMarks(uuid) {
      await this.$nuxt.$axios.$delete(
        `/mark/student-quiz-marks/${uuid}/delete/teacher-or-admin/`
      )
    },
    async getMarkType() {
      const res = await this.$nuxt.$axios.get(
        '/mark/mark-types/teacher-or-admin/'
      )
      this.setMarkType(res.data.results)
    },
    setMarkType(markType) {
      this.$patch({
        markType: [...markType],
      })
    },
    async patchMarkType(markType, uuid) {
      const data = {
        mark_type: markType,
        uuid,
      }
      await this.$nuxt.$axios.patch(
        `/mark/marks/${uuid}/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async createMarkAttendanceTeacherAdmin(
      scheduledSubject,
      studentMarkBook,
      comment,
      state
    ) {
      const data = {
        scheduled_subject: scheduledSubject,
        student_mark_book: studentMarkBook,
        comment,
        state,
      }
      await this.$nuxt.$axios.post(
        '/mark/attendances/teacher-or-admin/',
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async patchMarkAttendanceTeacherAdmin(comment, state, uuid) {
      const data = {
        comment,
        state,
        uuid,
      }
      await this.$nuxt.$axios.patch(
        `/mark/attendances/${uuid}/teacher-or-admin/`,
        JSON.stringify(data, null, ' '),
        {
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
        }
      )
    },
    async deleteMarkAttendanceTeacherAdmin(uuid) {
      await this.$nuxt.$axios.$delete(
        `/mark/attendances/${uuid}/delete/teacher-or-admin/`
      )
    },
  },
})
