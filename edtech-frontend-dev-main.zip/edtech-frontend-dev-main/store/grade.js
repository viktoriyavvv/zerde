import { defineStore } from 'pinia'

export const useGradeStore = defineStore({
  id: 'grade',
  state: () => {
    return {
      grade: [],
      gradeList: [],
      gradeGroupList: [],
      loading: true,
      classTeacherPic: '',
    }
  },
  getters: {
    getGrade: (state) => state.grade,
  },
  actions: {
    setGrade(grade) {
      this.$patch({
        grade: {
          ...grade,
        },
      })
    },
    setGradeList(grades) {
      this.$patch({
        gradeList: [...grades],
      })
    },
    async loadGrade(uuid) {
      this.$patch({
        loading: true,
      })
      await this.$nuxt.$axios
        .get(`/school/grades/${uuid}/`)
        .then((response) => {
          this.setGrade(response.data)
          this.loadClassTeacherPic(response.data.class_teacher_profile.image)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },

    async loadGradeList() {
      this.$patch({
        loading: true,
      })
      await this.$nuxt.$axios
        .get(`/school/grades/${this.$nuxt.$auth.user.role}/`)
        .then((response) => {
          this.setGradeList(response.data.results)
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },
    async loadClassTeacherPic(url) {
      await this.$nuxt.$axios
        .get(url, { responseType: 'blob' })
        .then((response) => {
          this.$patch({
            classTeacherPic: URL.createObjectURL(response.data),
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
    },
    async loadGradeGroupList(uuid) {
      this.$patch({
        loading: true,
      })
      await this.$nuxt.$axios
        .get(`/school/grade-groups/${this.$nuxt.$auth.user.role}/`, {
          params: { grade: uuid },
        })
        .then((response) => {
          this.$patch({
            gradeGroupList: response.data.results,
          })
        })
        .catch((error) => {
          alert('Произошла ошибка, пожалуйста, перезагрузите страницу.', error)
        })
        .then(() => {
          this.$patch({
            loading: false,
          })
        })
    },
  },
})
