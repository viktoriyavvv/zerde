import test from 'ava'
import { createLocalVue, mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import { PiniaVuePlugin } from 'pinia'
import { spy } from 'sinon'
import StudentProfile from '~/components/profiles/StudentProfile'
import StudentItem from '~/components/profiles/StudentItem'

const localVue = createLocalVue()
localVue.use(PiniaVuePlugin)

test('student profile render without pic', (t) => {
  const wrapper = mount(StudentProfile, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        profile: {
          profile: {
            user_account: {
              email: 'string',
              first_name: 'string',
              last_name: 'string',
            },
            grade: {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              name: 'string',
            },
            address: {
              city: 'string',
              street: 'string',
              apartment: 'string',
              floor: 0,
              entrance: 'string',
            },
            phone: 'string',
            date_of_birth: '2022-06-30',
            parent_name: 'string',
            parent_phone: 'string',
          },
        },
      },
    }),
  })
  if (
    wrapper.find('#profile').exists() &&
    wrapper.find('#avatarPlaceholder').exists()
  ) {
    t.pass()
  }
})

test('student profile render with pic', (t) => {
  const wrapper = mount(StudentProfile, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        profile: {
          profile: {
            user_account: {
              email: 'string',
              first_name: 'string',
              last_name: 'string',
            },
            grade: {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              name: 'string',
            },
            address: {
              city: 'string',
              street: 'string',
              apartment: 'string',
              floor: 0,
              entrance: 'string',
            },
            phone: 'string',
            date_of_birth: '2022-06-30',
            parent_name: 'string',
            parent_phone: 'string',
            image: 'string',
          },
        },
      },
    }),
  })
  if (wrapper.find('#profile').exists() && wrapper.find('#avatar').exists()) {
    t.pass()
  }
})

test('student item render', (t) => {
  const wrapper = mount(StudentItem, {
    propsData: {
      profile: {
        userAccount: {
          firstName: 'string',
          lastName: 'string',
          email: 'string',
          role: 'string',
          fullName: 'string',
        },
        grade: 'string',
        address: 'string',
        phone: 'string',
        dateOfBirth: '2022-06-30',
        image: 'string',
      },
      reveal: true,
    },
  })

  if (wrapper.find('.profile__body').exists()) {
    t.pass()
  }
})
