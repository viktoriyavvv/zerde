import test from 'ava'
import { mount, createLocalVue } from '@vue/test-utils'
import VueRouter from 'vue-router'
import DefaultList from '@/components/main/DefaultList.vue'

const localVue = createLocalVue()
localVue.use(VueRouter)
const router = new VueRouter()

const factory = ({ propsData } = {}, computed = {}) => {
  return mount(DefaultList, {
    propsData: {
      ...propsData,
    },
    computed: {
      ...computed,
    },
  })
}

const factoryWrapperList = ({ propsData } = {}, computed = {}) => {
  return mount(DefaultList, {
    propsData: {
      ...propsData,
    },
    computed: {
      displayList() {
        return true
      },
      displayMessage() {
        return false
      },
      displayLoading() {
        return false
      },
      ...computed,
    },
  })
}

test('DefaultList.vue renders', (t) => {
  const wrapper = factory()
  t.true(wrapper.exists())
})

test('DefaultList.vue renders table headers', (t) => {
  const headersList = [
    'Предмет',
    'Задание',
    'Срок выполнения',
    'Статус',
    'Оценка',
  ]
  const wrapper = factory({ propsData: { headers: headersList } })
  t.truthy(wrapper.findAll('th').length)
  t.is(wrapper.findAll('th').length, headersList.length)
})

test('DefaultList.vue renders loader', (t) => {
  const wrapper = factory({
    computed: {
      displayLoading() {
        return true
      },
    },
  })
  t.truthy(wrapper.findAll('.loader').length)
})

test('DefaultList.vue renders error message', (t) => {
  const wrapper = factory({
    computed: {
      displayMessage() {
        return true
      },
    },
  })
  t.truthy(wrapper.find('.message__text'))
})

test('DefaultList.vue renders table with hw from list for student and has only one table body', (t) => {
  const hwList = [
    {
      uuid: '136cdfe3-b5a4-4f42-ba65-c81b3c577791',
      deadline: '09 июн. 2022 г.',
      state: 'not_done',
      subject: {
        uuid: '1864071e-23b7-4f47-ad0b-5c2b4f3814ed',
        name: 'Математика',
      },
      teacherName: {
        email: '',
        firstName: 'Анна',
        lastName: 'Болейн',
        fullName: 'Болейн Анна',
        role: '',
      },
      mark: [
        {
          uuid: '8f04df76-d780-41d8-b564-2f8b3f77e014',
          markValue: 5,
          maxMarkValue: 10,
          markPercentValue: 50,
          comment: '',
          date: '',
        },
      ],
      homeworkType: '',
    },
    {
      uuid: '668d777a-77bf-4220-b101-00a494990e86',
      deadline: '09 июл. 2022 г.',
      state: 'done',
      subject: {
        uuid: '1864071e-23b7-4f47-ad0b-5c2b4f3814ed',
        name: 'Математика',
      },
      teacherName: {
        email: '',
        firstName: 'Анна',
        lastName: 'Болейн',
        fullName: 'Болейн Анна',
        role: '',
      },
      mark: [
        {
          uuid: 'bed31484-ece3-4033-80a1-b8359e7277d8',
          markValue: 5,
          maxMarkValue: 10,
          markPercentValue: 50,
          comment: '',
          date: '',
        },
      ],
      homeworkType: '',
    },
  ]
  const headersList = [
    'Предмет',
    'Задание',
    'Срок выполнения',
    'Статус',
    'Оценка',
  ]
  const typeString = 'homework'
  const wrapper = factoryWrapperList({
    propsData: {
      list: hwList,
      type: typeString,
      headers: headersList,
    },
  })
  t.truthy(wrapper.find('.student-homework'))
  t.is(wrapper.findAll('.list-body').length, 1)
  t.is(wrapper.findAll('.student-homework__row').length, hwList.length)
})

test('DefaultList.vue renders table with hw from list for teacher and has only one table body', (t) => {
  const hwList = [
    {
      uuid: '136cdfe3-b5a4-4f42-ba65-c81b3c577791',
      deadline: '09 июн. 2022 г.',
      subject: 'Математика',
      state: 'issued',
      gradeGroup: '11b/A',
      description: 'tetete',
      repliedStudents: 0,
      totalStudents: 1,
      studentStats: 0,
    },
    {
      uuid: '668d777a-77bf-4220-b101-00a494990e86',
      deadline: '09 июл. 2022 г.',
      subject: 'Математика',
      state: 'issued',
      gradeGroup: '11b/A',
      description: 'Test hw assignment',
      repliedStudents: 1,
      totalStudents: 1,
      studentStats: 100,
    },
  ]
  const headersList = [
    '№',
    'Предмет',
    'Класс',
    'Группа',
    'Описание',
    'Срок выполнения',
    'Статистика',
  ]
  const typeString = 'homework-teacher'
  const wrapper = factoryWrapperList({
    propsData: {
      list: hwList,
      type: typeString,
      headers: headersList,
    },
  })
  t.truthy(wrapper.find('.teacher-homework'))
  t.is(wrapper.findAll('.list-body').length, 1)
  t.is(wrapper.findAll('.teacher-homework__row').length, hwList.length)
})

test('DefaultList.vue renders table with students from list for class-teacher and has only one table body', (t) => {
  const headersList = [
    '№ п/п',
    'Фамилия Имя Отчество',
    'Номер телефона',
    'Электронная почта',
    'Адрес проживания',
  ]
  const students = [
    {
      userAccount: {
        email: 'student1@mail.com',
        firstName: 'Арман',
        lastName: 'Баженов',
        fullName: 'Баженов Арман',
        role: '',
      },
      grade: { uuid: 'bce3882d-c495-4d06-ac40-d5272d99f27f', name: '11b' },
      address: {
        city: 'Алматы',
        street: 'Жарокова',
        apartment: '366',
        floor: '',
        fullAddress: 'Алматы, Жарокова 366',
      },
      phone: '87081234567',
      dateOfBirth: '2003-01-01',
      image: '',
    },
  ]
  const typeString = 'students'
  const wrapper = factoryWrapperList({
    propsData: {
      list: students,
      type: typeString,
      headers: headersList,
    },
  })
  t.truthy(wrapper.find('.student-list'))
  t.is(wrapper.findAll('.list-body').length, 1)
  t.is(wrapper.findAll('.student-list__row').length, students.length)
})

test('DefaultList.vue renders table with students from list for student and has only one table body', (t) => {
  const headersList = ['№', 'ФИО', 'Дата рождения', 'Номер телефона']
  const students = [
    {
      userAccount: {
        email: 'student1@mail.com',
        firstName: 'Арман',
        lastName: 'Баженов',
        fullName: 'Баженов Арман',
        role: '',
      },
      grade: {},
      address: {},
      phone: '87081234567',
      dateOfBirth: '2003-01-01',
      image: '',
    },
    {
      userAccount: {
        email: 'student1@mail.com',
        firstName: 'Арман',
        lastName: 'Баженов',
        fullName: 'Баженов Арман',
        role: '',
      },
      grade: {},
      address: {},
      phone: '87081234567',
      dateOfBirth: '2003-01-01',
      image: '',
    },
    {
      userAccount: {
        email: 'student1@mail.com',
        firstName: 'Арман',
        lastName: 'Баженов',
        fullName: 'Баженов Арман',
        role: '',
      },
      grade: {},
      address: {},
      phone: '87081234567',
      dateOfBirth: '2003-01-01',
      image: '',
    },
    {
      userAccount: {
        email: 'student1@mail.com',
        firstName: 'Арман',
        lastName: 'Баженов',
        fullName: 'Баженов Арман',
        role: '',
      },
      grade: {},
      address: {},
      phone: '87081234567',
      dateOfBirth: '2003-01-01',
      image: '',
    },
  ]
  const typeString = 'students-class'
  const wrapper = factoryWrapperList({
    propsData: {
      list: students,
      type: typeString,
      headers: headersList,
    },
  })
  t.truthy(wrapper.find('.student-list'))
  t.is(wrapper.findAll('.list-body').length, 1)
  t.is(wrapper.findAll('.student-list__row').length, students.length)
  t.is(wrapper.findAll('td').length, 4 * students.length)
})

test('DefaultList.vue renders table with teachers from list for student and has only one table body', (t) => {
  const headersList = ['№', 'ФИО', 'Предмет']
  const teachers = [
    {
      userAccount: {
        email: 'teacher1@mail.com',
        firstName: 'Анна',
        lastName: 'Болейн',
        fullName: 'Болейн Анна',
        role: '',
      },
      subjects: [
        { uuid: '1864071e-23b7-4f47-ad0b-5c2b4f3814ed', name: 'Математика' },
        { uuid: '1d03adcb-7b42-4834-90d2-ae194f13a28f', name: 'Химия' },
        { uuid: '27bf4665-9836-46ab-b434-481854dee2c3', name: 'Физика' },
      ],
    },
  ]
  const typeString = 'teachers'
  const wrapper = factoryWrapperList({
    propsData: {
      list: teachers,
      type: typeString,
      headers: headersList,
    },
  })
  t.truthy(wrapper.find('.teacher-list'))
  t.is(wrapper.findAll('.list-body').length, 1)
  t.is(wrapper.findAll('.teacher-list__row').length, teachers.length)
})

test('DefaultList.vue emits an event with hw id when clicked', (t) => {
  const hwList = [
    {
      uuid: '136cdfe3-b5a4-4f42-ba65-c81b3c577791',
      deadline: '09 июн. 2022 г.',
      state: 'not_done',
      subject: {
        uuid: '1864071e-23b7-4f47-ad0b-5c2b4f3814ed',
        name: 'Математика',
      },
      teacherName: {
        email: '',
        firstName: 'Анна',
        lastName: 'Болейн',
        fullName: 'Болейн Анна',
        role: '',
      },
      mark: [
        {
          uuid: '8f04df76-d780-41d8-b564-2f8b3f77e014',
          markValue: 5,
          maxMarkValue: 10,
          markPercentValue: 50,
          comment: '',
          date: '',
        },
      ],
      homeworkType: '',
    },
  ]
  const headersList = [
    'Предмет',
    'Задание',
    'Срок выполнения',
    'Статус',
    'Оценка',
  ]
  const typeString = 'homework'
  const wrapper = factoryWrapperList({
    propsData: {
      list: hwList,
      type: typeString,
      headers: headersList,
    },
  })
  wrapper.find('.student-homework__row').trigger('click')
  t.truthy(wrapper.emitted().selectHW)
})

test('DefaultList.vue redirects to page with hw id when teacher clicks on specific hw on the list', (t) => {
  const hwList = [
    {
      uuid: '136cdfe3-b5a4-4f42-ba65-c81b3c577791',
      deadline: '09 июн. 2022 г.',
      subject: 'Математика',
      state: 'issued',
      gradeGroup: '11b/A',
      description: 'tetete',
      repliedStudents: 0,
      totalStudents: 1,
      studentStats: 0,
    },
  ]
  const headersList = [
    '№',
    'Предмет',
    'Класс',
    'Группа',
    'Описание',
    'Срок выполнения',
    'Статистика',
  ]
  const typeString = 'homework-teacher'
  const wrapper = mount(DefaultList, {
    localVue,
    router,
    propsData: {
      list: hwList,
      type: typeString,
      headers: headersList,
    },
    computed: {
      displayList() {
        return true
      },
      displayMessage() {
        return false
      },
      displayLoading() {
        return false
      },
    },
  })
  wrapper.find('.teacher-homework__row').trigger('click')
  const idPath = wrapper.vm.$route.path.split('/').pop()
  t.is(idPath, hwList[0].uuid)
})

test('DefaultList.vue emits an event with profile index when clicked by class teacher', (t) => {
  const headersList = [
    '№ п/п',
    'Фамилия Имя Отчество',
    'Номер телефона',
    'Электронная почта',
    'Адрес проживания',
  ]
  const students = [
    {
      userAccount: {
        email: 'student1@mail.com',
        firstName: 'Арман',
        lastName: 'Баженов',
        fullName: 'Баженов Арман',
        role: '',
      },
      grade: { uuid: 'bce3882d-c495-4d06-ac40-d5272d99f27f', name: '11b' },
      address: {
        city: 'Алматы',
        street: 'Жарокова',
        apartment: '366',
        floor: '',
        fullAddress: 'Алматы, Жарокова 366',
      },
      phone: '87081234567',
      dateOfBirth: '2003-01-01',
      image: '',
    },
  ]
  const typeString = 'students'
  const wrapper = factoryWrapperList({
    propsData: {
      list: students,
      type: typeString,
      headers: headersList,
    },
  })
  wrapper.find('.student-list__row').trigger('click')
  t.truthy(wrapper.emitted().showProfile)
})
