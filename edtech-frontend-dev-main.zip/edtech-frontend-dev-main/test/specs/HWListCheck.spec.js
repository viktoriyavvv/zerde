import test from 'ava'
import { createLocalVue, mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import { PiniaVuePlugin } from 'pinia'
import { spy } from 'sinon'
import HomeworkListCheck from '~/components/homeworks/HomeworkListCheck'

const localVue = createLocalVue()
localVue.use(PiniaVuePlugin)

test('list loading skeleton', (t) => {
  const wrapper = mount(HomeworkListCheck, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: true,
        },
      },
    }),
  })

  if (wrapper.find('.v-skeleton-loader').exists()) {
    t.pass()
  }
})

test('list shows student replies', (t) => {
  const wrapper = mount(HomeworkListCheck, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
          selectedHomework: [
            {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              deadline: '2022-06-29T06:16:53.673Z',
              subject: 'string',
              grade: 'string',
              grade_group: 'string',
              description: 'string',
              attached_files: [
                {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  file_name: 'string',
                  file: 'string',
                  description: 'string',
                },
              ],
              student_profiles: {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                user_account: {
                  first_name: 'string',
                  last_name: 'string',
                },
                mark: 'string',
                student_assignment_replies: [
                  {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    attached_files: [
                      {
                        uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                        file_name: 'string',
                        file: 'string',
                        description: 'string',
                      },
                    ],
                    comment: 'string',
                  },
                ],
              },
              state: 'issued',
            },
          ],
        },
      },
    }),
  })

  if (
    wrapper.find('#replies').exists() &&
    t.is(wrapper.findAll('.list-table').length, 1)
  ) {
    t.pass()
  }
})

test('list shows student replies readonly', (t) => {
  const wrapper = mount(HomeworkListCheck, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
          selectedHomework: [
            {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              deadline: '2022-06-29T06:16:53.673Z',
              subject: 'string',
              grade: 'string',
              grade_group: 'string',
              description: 'string',
              attached_files: [
                {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  file_name: 'string',
                  file: 'string',
                  description: 'string',
                },
              ],
              student_profiles: {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                user_account: {
                  first_name: 'string',
                  last_name: 'string',
                },
                mark: 'string',
                student_assignment_replies: [
                  {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    attached_files: [
                      {
                        uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                        file_name: 'string',
                        file: 'string',
                        description: 'string',
                      },
                    ],
                    comment: 'string',
                  },
                ],
              },
              state: 'issued',
            },
          ],
        },
      },
    }),
    computed: {
      readonly() {
        return true
      },
    },
  })

  if (t.is(wrapper.find('#postMark').exists(), false)) {
    t.pass()
  }
})
