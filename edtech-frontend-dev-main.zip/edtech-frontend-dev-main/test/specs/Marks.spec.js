import test from 'ava'
import { spy } from 'sinon'
import { mount, createLocalVue } from '@vue/test-utils'
import { PiniaVuePlugin } from 'pinia'
import { createTestingPinia } from '@pinia/testing'
import MarksYear from '~/components/marks/MarksYear.vue'
import MarksTerm from '~/components/marks/MarksTerm'
import MarksSubject from '~/components/marks/MarksSubject'
import MarksActions from '~/components/marks/MarksActions'

const localVue = createLocalVue()
localVue.use(PiniaVuePlugin)

// MarksYear tests
test('MarksYear.vue renders', (t) => {
  const wrapper = mount(MarksYear, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
  })
  t.true(wrapper.exists())
  t.true(wrapper.find('.yearMarks').exists())
})

test('MarksYear.vue displays loader when request is in process', (t) => {
  const wrapper = mount(MarksYear, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        marks: {
          yearMarks: [],
          loading: true,
        },
      },
    }),
  })
  t.true(wrapper.find('.v-skeleton-loader').exists())
})

test('MarksYear.vue displays a table with marks from store', (t) => {
  const wrapper = mount(MarksYear, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        terms: {
          terms: [
            {
              uuid: '75d634e9-8313-44fe-a16f-309553f64a46',
              name: 'I четверть',
              start_date: '2021-09-01',
              end_date: '2021-10-31',
            },
            {
              uuid: 'c13ae747-a2ca-41ce-8f10-8181a599d821',
              name: 'II четверть',
              start_date: '2021-11-08',
              end_date: '2021-12-29',
            },
            {
              uuid: '63cef3c7-02f7-4de6-bb66-45d62a3798ad',
              name: 'III четверть',
              start_date: '2022-01-10',
              end_date: '2022-03-18',
            },
            {
              uuid: '2309ca9d-d76f-49bf-a964-c4f3580f7894',
              name: 'IV четверть',
              start_date: '2022-03-31',
              end_date: '2022-08-31',
            },
          ],
        },
        marks: {
          yearMarks: [
            {
              uuid: '41518472-b75d-41f3-bcc7-e2bbef1a0d40',
              subject: {
                uuid: '1864071e-23b7-4f47-ad0b-5c2b4f3814ed',
                name: 'Математика',
              },
              quarter_marks: [],
              school_year_mark: null,
              student_exam_mark: null,
              final_mark_student: null,
            },
            {
              uuid: '4514d652-b8e9-4a9e-9f76-8f4234c74d18',
              subject: {
                uuid: '1d03adcb-7b42-4834-90d2-ae194f13a28f',
                name: 'Химия',
              },
              quarter_marks: [
                {
                  uuid: '5f2b95a8-89ff-4314-a4ea-c337fd27b809',
                  quarter: {
                    uuid: '2309ca9d-d76f-49bf-a964-c4f3580f7894',
                    name: 'IV четверть',
                    is_term_quarter: false,
                  },
                  mark_value: 5,
                  max_mark_value: 5,
                },
              ],
              school_year_mark: null,
              student_exam_mark: null,
              final_mark_student: null,
            },
            {
              uuid: '2973c774-077c-4402-9687-02ec59f73152',
              subject: {
                uuid: '27bf4665-9836-46ab-b434-481854dee2c3',
                name: 'Физика',
              },
              quarter_marks: [
                {
                  uuid: 'a0c27927-db02-4fe1-9551-f3f959992574',
                  quarter: {
                    uuid: '63cef3c7-02f7-4de6-bb66-45d62a3798ad',
                    name: 'III четверть',
                    is_term_quarter: false,
                  },
                  mark_value: 4,
                  max_mark_value: 5,
                },
              ],
              school_year_mark: null,
              student_exam_mark: null,
              final_mark_student: null,
            },
          ],
          loading: false,
        },
        attendance: {
          attendanceYear: {
            absence_day_count: 2,
            all_absences_count: 2,
            attended_with_delay_count: 0,
            absences_with_reason_count: 2,
          },
          attendanceQuarters: [
            {
              uuid: '75d634e9-8313-44fe-a16f-309553f64a46',
              quarter_absence_day_count: 0,
              quarter_all_absences_count: 0,
              quarter_attended_with_delay_count: 0,
              quarter_absences_with_reason_count: 0,
            },
            {
              uuid: 'c13ae747-a2ca-41ce-8f10-8181a599d821',
              quarter_absence_day_count: 0,
              quarter_all_absences_count: 0,
              quarter_attended_with_delay_count: 0,
              quarter_absences_with_reason_count: 0,
            },
            {
              uuid: '63cef3c7-02f7-4de6-bb66-45d62a3798ad',
              quarter_absence_day_count: 1,
              quarter_all_absences_count: 1,
              quarter_attended_with_delay_count: 0,
              quarter_absences_with_reason_count: 1,
            },
            {
              uuid: '2309ca9d-d76f-49bf-a964-c4f3580f7894',
              quarter_absence_day_count: 1,
              quarter_all_absences_count: 1,
              quarter_attended_with_delay_count: 0,
              quarter_absences_with_reason_count: 1,
            },
          ],
        },
      },
    }),
  })
  t.true(wrapper.find('.yearMarks__table').exists())
})

test('MarksYear.vue correctly returns a number of blank cells', (t) => {
  const wrapper = mount(MarksYear, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        terms: {
          terms: [
            {
              uuid: '75d634e9-8313-44fe-a16f-309553f64a46',
              name: 'I четверть',
              start_date: '2021-09-01',
              end_date: '2021-10-31',
            },
          ],
        },
        marks: {
          yearMarks: [
            {
              uuid: '41518472-b75d-41f3-bcc7-e2bbef1a0d40',
              subject: {
                uuid: '1864071e-23b7-4f47-ad0b-5c2b4f3814ed',
                name: 'Математика',
              },
              quarter_marks: [],
              school_year_mark: null,
              student_exam_mark: null,
              final_mark_student: null,
            },
          ],
          loading: false,
        },
        attendance: {
          attendanceYear: {
            absence_day_count: 2,
            all_absences_count: 2,
            attended_with_delay_count: 0,
            absences_with_reason_count: 2,
          },
          attendanceQuarters: [
            {
              uuid: '75d634e9-8313-44fe-a16f-309553f64a46',
              quarter_absence_day_count: 0,
              quarter_all_absences_count: 0,
              quarter_attended_with_delay_count: 0,
              quarter_absences_with_reason_count: 0,
            },
          ],
        },
      },
    }),
  })
  t.true(wrapper.find('.yearMarks__cell_placeholder').exists())
  // t.is(wrapper.vm.blankCells, 3)
})

// MarksTerm tests
test('MarksTerm.vue renders', (t) => {
  const wrapper = mount(MarksTerm, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
  })
  t.true(wrapper.exists())
  t.true(wrapper.find('.termMarks').exists())
})

test('MarksTerm.vue displays a loder when request is in process', (t) => {
  const wrapper = mount(MarksTerm, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        marks: {
          quarterMarks: [],
          loading: true,
        },
      },
    }),
  })
  t.true(wrapper.find('.v-skeleton-loader').exists())
})

test('MarksTerm.vue displays a table with marks from store', (t) => {
  const wrapper = mount(MarksTerm, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        marks: {
          quarterMarks: [
            {
              uuid: '41518472-b75d-41f3-bcc7-e2bbef1a0d40',
              subject: {
                uuid: '1864071e-23b7-4f47-ad0b-5c2b4f3814ed',
                name: 'Математика',
              },
              student_marks: [
                {
                  uuid: 'c9466ca5-0e74-45cc-96fa-e5259e9658c3',
                  mark_value: 5,
                  mark: {
                    uuid: 'e4d10d22-bdb8-498c-bba3-90f1af05880a',
                    mark_type: {
                      uuid: '3e809239-1c18-4494-93ba-375704e60080',
                      title: 'Формативное оценивание',
                      short_title: 'ФО',
                      max_mark_value: 10,
                    },
                    date: '2022-06-09',
                  },
                  comment: 'asd',
                },
              ],
              quiz_mark_students: [],
              quarter_mark: null,
              marks_and_quiz_marks_percentage: 12.5,
              examine_marks_percentage: 0,
              all_marks_percentage: 12.5,
              all_absences_count: 1,
              attended_with_delay_count: 0,
              absences_with_reason_count: 1,
            },
            {
              uuid: '2973c774-077c-4402-9687-02ec59f73152',
              subject: {
                uuid: '27bf4665-9836-46ab-b434-481854dee2c3',
                name: 'Физика',
              },
              student_marks: [],
              quiz_mark_students: [],
              quarter_mark: null,
              marks_and_quiz_marks_percentage: 0,
              examine_marks_percentage: 0,
              all_marks_percentage: 0,
              all_absences_count: 0,
              attended_with_delay_count: 0,
              absences_with_reason_count: 0,
            },
            {
              uuid: '4514d652-b8e9-4a9e-9f76-8f4234c74d18',
              subject: {
                uuid: '1d03adcb-7b42-4834-90d2-ae194f13a28f',
                name: 'Химия',
              },
              student_marks: [],
              quiz_mark_students: [],
              quarter_mark: {
                uuid: '5f2b95a8-89ff-4314-a4ea-c337fd27b809',
                mark_value: 5,
                max_mark_value: 5,
              },
              marks_and_quiz_marks_percentage: 0,
              examine_marks_percentage: 0,
              all_marks_percentage: 0,
              all_absences_count: 1,
              attended_with_delay_count: 0,
              absences_with_reason_count: 1,
            },
          ],
          loading: false,
        },
      },
    }),
  })
  t.true(wrapper.find('.termMarks__table').exists())
})

// MarksSubject tests
test('MarksSubject.vue renders', (t) => {
  const wrapper = mount(MarksSubject, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
  })
  t.true(wrapper.exists())
})

test('MarksSubject.vue displays loader when request is in process', (t) => {
  const wrapper = mount(MarksSubject, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        marks: {
          errorStatus: false,
          loading: true,
        },
      },
    }),
  })
  t.true(wrapper.find('.v-skeleton-loader').exists())
})

test('MarksSubject.vue displays an info message to choose subject and quarter', (t) => {
  const wrapper = mount(MarksSubject, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        marks: {
          loading: false,
          messageStatus: true,
        },
      },
    }),
  })
  t.true(wrapper.find('.infoMessage').exists())
  t.is(
    wrapper.find('.infoMessage').text(),
    'Выберите предмет и четверть для отображения оценок'
  )
})

test('MarksSubject.vue displays an error message when no results found', (t) => {
  const wrapper = mount(MarksSubject, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        marks: {
          loading: false,
          errorStatus: true,
        },
      },
    }),
  })
  t.true(wrapper.find('.errorMessage').exists())
  t.is(
    wrapper.find('.errorMessage').text(),
    'Результаты, соответствующие параметрам вашего запроса, не найдены'
  )
})

test('MarksSubject.vue displays a table with marks from store', (t) => {
  const wrapper = mount(MarksSubject, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        marks: {
          loading: false,
          errorStatus: false,
          messageStatus: false,
          subjectMarks: {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            student_marks: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                mark_value: 0,
                mark: {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  mark_type: {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    title: 'string',
                    short_title: 'string',
                    max_mark_value: 0,
                  },
                  date: '2022-06-23',
                },
                comment: 'string',
              },
            ],
            attendances: [
              {
                comment: 'string',
                state: 'attended_with_delay',
                date: '2022-06-23',
              },
            ],
          },
        },
      },
    }),
  })
  t.true(wrapper.find('.subjectMarks__table').exists())
})

// MarksActions.vue tests
test('MarksActions.vue renders', (t) => {
  const wrapper = mount(MarksActions, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
  })
  t.true(wrapper.exists())
})

test('MarksActions.vue renders with actions for quarter marks', (t) => {
  const wrapper = mount(MarksActions, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
    propsData: {
      tabMode: 'quarter',
    },
  })
  t.true(wrapper.find('.quarterMarksActions').exists())
})

test('MarksActions.vue renders with actions for subject marks', (t) => {
  const wrapper = mount(MarksActions, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
    propsData: {
      tabMode: 'subjects',
    },
  })
  t.true(wrapper.find('.subjectMarksActions').exists())
})

test('MarksActions.vue renders with actions for year marks', (t) => {
  const wrapper = mount(MarksActions, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
    propsData: {
      tabMode: 'year',
    },
  })
  t.true(wrapper.find('.yearMarksActions').exists())
})

test('MarksActions.vue emits an event on click on print button', (t) => {
  const wrapper = mount(MarksActions, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
    propsData: {
      tabMode: 'year',
    },
  })
  const printPdfButton = wrapper.find('.printPdfButton')
  t.true(printPdfButton.exists())
  printPdfButton.trigger('click')
  wrapper.vm.$nextTick()
  t.truthy(wrapper.emitted().downloadPdf)
})

test('MarksActions.vue emits an event on click on filter quarter mark button', (t) => {
  const wrapper = mount(MarksActions, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
    propsData: {
      tabMode: 'quarter',
      quarterList: [
        {
          uuid: '75d634e9-8313-44fe-a16f-309553f64a46',
          name: 'I четверть',
          start_date: '2021-09-01',
          end_date: '2021-10-31',
        },
      ],
    },
  })
  const chooseQuarterButton = wrapper.find('.quarterMarkFilter')
  t.true(chooseQuarterButton.exists())
  chooseQuarterButton.trigger('click')
  wrapper.vm.$nextTick()
  t.truthy(wrapper.emitted().loadQuarterMarks)
})

test.only('MarksActions.vue emits an event on click on filter marks button', (t) => {
  const wrapper = mount(MarksActions, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
    propsData: {
      tabMode: 'subjects',
    },
    computed: {
      quarterCheck() {
        return true
      },
      subjectCheck() {
        return true
      },
    },
  })
  const filterMarksButton = wrapper.find('.sidebar__button')
  t.true(filterMarksButton.exists())
  filterMarksButton.trigger('click')
  wrapper.vm.$nextTick()
  t.truthy(wrapper.emitted().filterList)
})
