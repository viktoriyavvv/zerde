import test from 'ava'
import { createLocalVue, shallowMount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import { PiniaVuePlugin } from 'pinia'
import { spy } from 'sinon'
import ScheduleTable from '~/components/schedules/ScheduleTable'
import { useScheduleStore } from '~/store'

const localVue = createLocalVue()
localVue.use(PiniaVuePlugin)

const authMockStudent = {
  loggedIn: true,
  user: {
    email: 'password0000@example.com',
    first_name: 'Travis',
    last_name: 'Anderson',
    role: 'student',
  },
}

const authMockTeacher = {
  loggedIn: true,
  user: {
    email: 'password0000@example.com',
    first_name: 'Travis',
    last_name: 'Anderson',
    role: 'teacher',
  },
}

const authMockAdmin = {
  loggedIn: true,
  user: {
    email: 'password0000@example.com',
    first_name: 'Travis',
    last_name: 'Anderson',
    role: 'admin',
  },
}

const authMockClassTeacher = {
  loggedIn: true,
  user: {
    email: 'password0000@example.com',
    first_name: 'Travis',
    last_name: 'Anderson',
    role: 'class-teacher',
  },
}

/* test('schedule loading student', async (t) => {
  const wrapper = shallowMount(ScheduleTable, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        schedule: {
          schedule: [
            {
              date: '2022-06-23',
              scheduled_subjects: [
                {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  subject: {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    name: 'string',
                  },
                  classroom: {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    number: 0,
                  },
                  teacher_name: {
                    first_name: 'string',
                    last_name: 'string',
                  },
                  schedule_time: {
                    start_time: 'string',
                    end_time: 'string',
                  },
                },
              ],
            },
          ],
          loading: false,
        },
      },
    }),
    mocks: {
      $vuetify: { breakpoint: {} },
      $auth: authMockStudent,
    },
  })
  await wrapper.vm.$nextTick()
  if (wrapper.find('#scheduleWrapper').exists()) {
    t.pass()
  }
}) */

test('schedule tabs student', async (t) => {
  const wrapper = shallowMount(ScheduleTable, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        schedule: {
          schedule: [],
        },
      },
    }),
    mocks: {
      $auth: authMockStudent,
    },
  })

  await wrapper.vm.$nextTick()
  const tabsLength = wrapper.findAllComponents('v-tab-stub').length
  if (
    t.is(tabsLength, 2) &&
    t.is(wrapper.find('#scheduleTab').text(), 'Расписание') &&
    t.is(wrapper.find('#bellrangTab').text(), 'Звонки')
  ) {
    t.pass()
  }
})

test('schedule bell rang loading', async (t) => {
  const wrapper = shallowMount(ScheduleTable, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        schedule: {
          schedule: [],
        },
        bellrang: {
          bellrang: [
            {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              start_time: 'string',
              end_time: 'string',
              break_time: '00:05:00',
            },
          ],
        },
      },
    }),
    mocks: {
      $auth: authMockTeacher,
    },
  })

  await wrapper.vm.$nextTick()
  wrapper.vm.setActiveSchedule('bellRang')
  await wrapper.vm.$nextTick()
  if (wrapper.find('#bellrang').exists()) {
    t.pass()
  }
})

test('schedule warn if schedules array empty', async (t) => {
  const wrapper = shallowMount(ScheduleTable, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        schedule: {
          schedule: [],
        },
      },
    }),
    mocks: {
      $auth: authMockStudent,
    },
  })
  await wrapper.vm.$nextTick()
  if (wrapper.find('#warn').exists()) {
    t.pass()
  }
})

test('schedule tabs admin', async (t) => {
  const wrapper = shallowMount(ScheduleTable, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        schedule: {
          schedule: [],
        },
      },
    }),
    mocks: {
      $auth: authMockAdmin,
    },
  })

  await wrapper.vm.$nextTick()
  const tabsLength = wrapper.findAllComponents('v-tab-stub').length
  if (
    t.is(tabsLength, 4) &&
    t.is(wrapper.find('#gradesTab').text(), 'Классы') &&
    t.is(wrapper.find('#bellrangTab').text(), 'Звонки') &&
    t.is(wrapper.find('#roomTab').text(), 'Кабинеты') &&
    t.is(wrapper.find('#teacherTab').text(), 'Учителя')
  ) {
    t.pass()
  }
})

test('schedule tabs classteacher', async (t) => {
  const wrapper = shallowMount(ScheduleTable, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        schedule: {
          schedule: [],
        },
      },
    }),
    mocks: {
      $auth: authMockClassTeacher,
    },
  })

  await wrapper.vm.$nextTick()
  const tabsLength = wrapper.findAllComponents('v-tab-stub').length
  if (
    t.is(tabsLength, 2) &&
    t.is(wrapper.find('#gradesTab').text(), 'Классы') &&
    t.is(wrapper.find('#bellrangTab').text(), 'Звонки')
  ) {
    t.pass()
  }
})

test('schedule loading admin right activeSchedule', (t) => {
  const wrapper = shallowMount(ScheduleTable, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
    mocks: {
      $auth: authMockAdmin,
    },
  })

  const store = useScheduleStore()
  ScheduleTable.computed.scheduleExten.call(store.scheduleBy)
  if (t.is(wrapper.vm.$data.activeSchedule, 'grade')) {
    t.pass()
  }
})
