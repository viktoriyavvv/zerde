import test from 'ava'
import { mount } from '@vue/test-utils'
import TaskFilter from '~/components/tasks/TaskFilter.vue'

const authMockStudent = {
  loggedIn: true,
  user: {
    email: 'password0000@example.com',
    first_name: 'Travis',
    last_name: 'Anderson',
    role: 'student',
  },
}

const authMockTeacher = {
  loggedIn: true,
  user: {
    email: 'password0000@example.com',
    first_name: 'Travis',
    last_name: 'Anderson',
    role: 'teacher',
  },
}

test('TaskFilter.vue renders', (t) => {
  const wrapper = mount(TaskFilter, {
    mocks: {
      $auth: authMockStudent,
    },
  })
  t.true(wrapper.exists())
})

test('TaskFilter.vue renders only one dropdown for student user', (t) => {
  const wrapper = mount(TaskFilter, {
    mocks: {
      $auth: authMockStudent,
    },
  })
  t.true(wrapper.find('.sidebar__dropdown').exists())
  t.is(wrapper.findAll('.sidebar__dropdown').length, 1)
})

test('TaskFilter.vue renders two dropdowns for non-student user', (t) => {
  const wrapper = mount(TaskFilter, {
    mocks: {
      $auth: authMockTeacher,
    },
  })
  t.true(wrapper.find('.sidebar__dropdown').exists())
  t.is(wrapper.findAll('.sidebar__dropdown').length, 2)
})

test('TaskFilter.vue buttonDisabled computed property is false when there is no options', (t) => {
  const wrapper = mount(TaskFilter, {
    data() {
      return {
        filterDate: [],
      }
    },
    mocks: {
      $auth: authMockTeacher,
    },
    computed: {
      gradeCheck() {
        return false
      },
      subjectCheck() {
        return false
      },
    },
  })

  t.true(wrapper.vm.buttonDisabled)
})

test('TaskFilter.vue buttonDisabled computed property is true when there is at least one option', (t) => {
  const wrapper = mount(TaskFilter, {
    data() {
      return {
        filterDate: [],
      }
    },
    mocks: {
      $auth: authMockTeacher,
    },
    computed: {
      gradeCheck() {
        return true
      },
      subjectCheck() {
        return false
      },
    },
  })

  t.false(wrapper.vm.buttonDisabled)
})

test('TaskFilter.vue renders a button to apply the filters and it is disabled when there is no parameters', (t) => {
  const wrapper = mount(TaskFilter, {
    mocks: {
      $auth: authMockStudent,
    },
    computed: {
      buttonDisabled() {
        return true
      },
    },
  })
  t.true(wrapper.find('.sidebar__button').exists())
  t.true(wrapper.find('.sidebar__button_disabled').exists())
})

test('TaskFilter.vue renders a button to apply the filters and it is active when there are parameters, and action is emitted on click by student', (t) => {
  const wrapper = mount(TaskFilter, {
    mocks: {
      $auth: authMockStudent,
    },
    computed: {
      buttonDisabled() {
        return false
      },
    },
  })
  const filterButton = wrapper.find('.sidebar__button')
  t.true(filterButton.exists())
  t.false(wrapper.find('.sidebar__button_disabled').exists())
  filterButton.trigger('click')
  wrapper.vm.$nextTick()
  t.truthy(wrapper.emitted().filterListStudent)
})

test('TaskFilter.vue renders a button to apply the filters and it is active when there are parameters, and action is emitted on click by teacher', (t) => {
  const wrapper = mount(TaskFilter, {
    mocks: {
      $auth: authMockTeacher,
    },
    computed: {
      buttonDisabled() {
        return false
      },
    },
  })
  const filterButton = wrapper.find('.sidebar__button')
  t.true(filterButton.exists())
  t.false(wrapper.find('.sidebar__button_disabled').exists())
  filterButton.trigger('click')
  wrapper.vm.$nextTick()
  t.truthy(wrapper.emitted().filterListTeacher)
})

test('TaskFilter.vue does not render a button to create homework for student user', (t) => {
  const wrapper = mount(TaskFilter, {
    mocks: {
      $auth: authMockStudent,
    },
  })
  t.false(wrapper.find('.sidebar__createHw').exists())
})

test('TaskFilter.vue renders a button to create homework for teacher user and action is emitted on click', (t) => {
  const wrapper = mount(TaskFilter, {
    mocks: {
      $auth: authMockTeacher,
    },
  })
  const createButton = wrapper.find('.sidebar__createHw')
  t.true(createButton.exists())
  createButton.trigger('click')
  wrapper.vm.$nextTick()
  t.truthy(wrapper.emitted().setMode)
})

test('TaskFilter.vue renders a button to reset filtered list and action is emitted on click', (t) => {
  const wrapper = mount(TaskFilter, {
    data() {
      return {
        subjectDefault: 'Выбрать предмет',
        gradeDefault: 'Выбрать класс',
        selectedSubject: 'Maths',
        selectedGrade: '11A',
        reset: false,
      }
    },
    mocks: {
      $auth: authMockTeacher,
    },
  })
  const resetButton = wrapper.find('.sidebar__reset')
  t.true(resetButton.exists())
  resetButton.trigger('click')
  wrapper.vm.$nextTick()
  t.is(wrapper.vm.selectedSubject, wrapper.vm.subjectDefault)
  t.is(wrapper.vm.selectedGrade, wrapper.vm.gradeDefault)
  t.is(wrapper.vm.reset, true)
  t.truthy(wrapper.emitted().filterListTeacher)
})
