import test from 'ava'
import { createLocalVue, mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import { PiniaVuePlugin } from 'pinia'
import { spy } from 'sinon'
import ScheduleLessonCard from '~/components/schedules/ScheduleLessonCard'
import ScheduleDefault from '@/components/schedules/ScheduleDefault.vue'
import DropDownElement from '@/components/main/DropDownElement'
import AcademicPerformance from '~/components/main/AcademicPerformance'
import AttendanceCard from '~/components/main/AttendanceCard'
import HomeworkCard from '~/components/main/HomeworkCard'
import StudentProfile from '~/components/main/StudentProfile'

const localVue = createLocalVue()
localVue.use(PiniaVuePlugin)

test('main page schedule', (t) => {
  const wrapper = mount(ScheduleDefault, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        schedule: {
          scheduleDay: [
            {
              date: '2022-07-04',
              scheduled_subjects: [
                {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  subject: {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    name: 'string',
                  },
                  classroom: {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    number: 0,
                  },
                  teacher_name: {
                    first_name: 'string',
                    last_name: 'string',
                  },
                  schedule_time: {
                    start_time: 'string',
                    end_time: 'string',
                  },
                },
              ],
            },
          ],
        },
      },
    }),
  })
  if (wrapper.find('.wrapper').exists()) {
    t.pass()
  }
})

test('main page schedule empty schedule array', (t) => {
  const scheduleMainPage = mount(ScheduleDefault, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        schedule: {
          schedule: [],
        },
      },
    }),
  })
  if (
    scheduleMainPage.isVueInstance() &&
    scheduleMainPage.find('#warn').exists()
  ) {
    t.pass()
  }
})

test('main page attendance', (t) => {
  const wrapper = mount(AttendanceCard, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        attendance: {
          attendance: [
            {
              subject: {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                name: 'string',
              },
              comment: 'string',
              state: 'attended_with_delay',
              date: '2022-06-23',
            },
          ],
          loading: false,
        },
      },
    }),
  })
  if (wrapper.find('.tableWrapper').exists()) {
    t.pass()
  }
})

test('main page attendance skeleton loading', (t) => {
  const wrapper = mount(AttendanceCard, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        attendance: {
          attendance: [
            {
              subject: {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                name: 'string',
              },
              comment: 'string',
              state: 'attended_with_delay',
              date: '2022-06-23',
            },
          ],
          loading: true,
        },
      },
    }),
  })
  if (wrapper.find('.v-skeleton-loader').exists()) {
    t.pass()
  }
})

test('academic performance main page', (t) => {
  const wrapper = mount(AcademicPerformance, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        assignment: {
          assignments: [
            {
              assignment: {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                subject: 'string',
                teacher_name: {
                  first_name: 'string',
                  last_name: 'string',
                },
                deadline: '2022-06-23T09:59:44.030Z',
              },
              max_mark_value: 0,
              mark_value: 0,
              comment: 'string',
            },
          ],
          loading: false,
        },
      },
    }),
  })
  if (wrapper.isVueInstance() && wrapper.find('#academPerformance').exists()) {
    t.pass()
  }
})

test('academic performance main page loading skeleton', (t) => {
  const wrapper = mount(AcademicPerformance, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
  })
  if (wrapper.find('.v-skeleton-loader').exists()) {
    t.pass()
  }
})

test('homework card main page skeleton loader', (t) => {
  const wrapper = mount(HomeworkCard, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        homework: {
          homeworks: [],
          loading: true,
        },
      },
    }),
  })

  if (wrapper.find('.v-skeleton-loader').exists()) {
    t.pass()
  }
})

test('homework card main page', (t) => {
  const wrapper = mount(HomeworkCard, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
      initialState: {
        homework: {
          homeworks: [
            {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              deadline: '2022-06-24T04:54:04.032Z',
              state: 'issued',
              subject: {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                name: 'string',
              },
              teacher_name: {
                first_name: 'string',
                last_name: 'string',
              },
              marks: [
                {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  mark_value: 0,
                  max_mark_value: 0,
                },
              ],
              student_state: 'string',
            },
          ],
          loading: false,
        },
      },
    }),
  })

  if (wrapper.isVueInstance() && wrapper.find('.overflow').exists()) {
    t.pass()
  }
})

test('student profile main page', (t) => {
  const wrapper = mount(StudentProfile, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        profile: {
          profile: {
            user_account: {
              email: 'string',
              first_name: 'string',
              last_name: 'string',
            },
            grade: {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              name: 'string',
            },
            address: {
              city: 'string',
              street: 'string',
              apartment: 'string',
              floor: 0,
              entrance: 'string',
            },
            phone: 'string',
            date_of_birth: '2022-06-24',
            parent_name: 'string',
            parent_phone: 'string',
            image: 'string',
          },
          loading: false,
        },
      },
    }),
  })
  if (wrapper.isVueInstance() && wrapper.find('.profile').exists()) {
    t.pass()
  }
})

test('student profile main page skeleton loading', (t) => {
  const wrapper = mount(StudentProfile, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        profile: {
          profile: {
            user_account: {
              email: 'string',
              first_name: 'string',
              last_name: 'string',
            },
            grade: {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              name: 'string',
            },
            address: {
              city: 'string',
              street: 'string',
              apartment: 'string',
              floor: 0,
              entrance: 'string',
            },
            phone: 'string',
            date_of_birth: '2022-06-24',
            parent_name: 'string',
            parent_phone: 'string',
            image: 'string',
          },
          loading: true,
        },
      },
    }),
  })

  if (wrapper.isVueInstance() && wrapper.find('.v-skeleton-loader').exists()) {
    t.pass()
  }
})

test('drop down options', (t) => {
  const wrapper = mount(DropDownElement, {
    propsData: {
      options: ['1', '2', '3'],
    },
  })
  t.truthy(wrapper.findAll('.option').length > 0)
})

test('drop down selected', (t) => {
  const wrapper = mount(DropDownElement, {
    propsData: {
      options: ['1'],
    },
  })
  wrapper.find('.option').trigger('click')
  t.is(wrapper.find('.selected').text(), '1')
})

test('drop down open close', (t) => {
  const wrapper = mount(DropDownElement, {
    propsData: {
      options: ['1', '2', '3'],
    },
  })
  wrapper.find('.selected').trigger('click')
  t.truthy(wrapper.find('.open'))
  wrapper.find('.selected').trigger('click')
  t.truthy(wrapper.find('.selectHide'))
})

test('drop down no type', (t) => {
  const wrapper = mount(DropDownElement, {
    propsData: {
      options: ['1', '2', '3'],
    },
  })
  t.truthy(wrapper.find('#noType'))
})

test('drop down type not teacher', (t) => {
  const wrapper = mount(DropDownElement, {
    propsData: {
      type: 'number',
      options: ['1', '2', '3'],
    },
  })
  t.truthy(wrapper.find('#notTeacher'))
})

test('drop down type teacher', (t) => {
  const wrapper = mount(DropDownElement, {
    propsData: {
      type: 'teacher',
      options: [
        {
          account: {
            fullName: 'teacher teacher',
          },
        },
      ],
    },
  })
  t.truthy(wrapper.find('#teacher'))
})

test('lesson card', (t) => {
  const wrapper = mount(ScheduleLessonCard, {
    propsData: {
      subject: 'Math',
      teacher: 'teacher',
      cabinet: 0,
    },
  })
  t.truthy(wrapper.isVueInstance())
})
