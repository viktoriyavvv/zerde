import test from 'ava'
import { createLocalVue, mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import { PiniaVuePlugin } from 'pinia'
import { spy } from 'sinon'
import { useHomeworkStore } from '~/store'
import CreateTask from '~/components/homeworks/CreateTask'

const localVue = createLocalVue()
localVue.use(PiniaVuePlugin)

const authMockTeacher = {
  loggedIn: true,
  user: {
    email: 'password0000@example.com',
    first_name: 'Travis',
    last_name: 'Anderson',
    role: 'teacher',
  },
}

const authMockAdmin = {
  loggedIn: true,
  user: {
    email: 'password0000@example.com',
    first_name: 'Travis',
    last_name: 'Anderson',
    role: 'admin',
  },
}

test('create task skeleton loader', (t) => {
  const wrapper = mount(CreateTask, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
    }),
  })
  const store = useHomeworkStore()
  CreateTask.computed.files.call(store.filesID)
  if (wrapper.find('.v-skeleton-loader').exists()) {
    t.pass()
  }
})

test('create task create mode teacher', (t) => {
  const wrapper = mount(CreateTask, {
    propsData: {
      createMode: true,
    },
    mocks: {
      $auth: authMockTeacher,
    },
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
        },
      },
    }),
  })
  const store = useHomeworkStore()
  CreateTask.computed.files.call(store.filesID)
  if (t.is(wrapper.find('.title-component').text(), 'Создание задания')) {
    t.pass()
  }
})

test('create task view mode', (t) => {
  const wrapper = mount(CreateTask, {
    propsData: {
      createMode: false,
      selectedHomework: {
        uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        deadline: '2022-06-29T06:16:53.673Z',
        subject: 'string',
        grade: 'string',
        grade_group: 'string',
        description: 'string',
        attached_files: [
          {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            file_name: 'string',
            file: 'string',
            description: 'string',
          },
        ],
        student_profiles: {
          uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
          user_account: {
            first_name: 'string',
            last_name: 'string',
          },
          mark: 'string',
          student_assignment_replies: [
            {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              attached_files: [
                {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  file_name: 'string',
                  file: 'string',
                  description: 'string',
                },
              ],
              comment: 'string',
            },
          ],
        },
        state: 'issued',
      },
    },
    mocks: {
      $auth: authMockTeacher,
    },
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
        },
      },
    }),
  })
  if (wrapper.find('#viewMode').exists()) {
    t.pass()
  }
})

test('create task patch mode', (t) => {
  const wrapper = mount(CreateTask, {
    propsData: {
      patchMode: true,
      selectedHomework: {
        uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        deadline: '2022-06-29T06:16:53.673Z',
        subject: 'string',
        grade: 'string',
        grade_group: 'string',
        description: 'string',
        attached_files: [
          {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            file_name: 'string',
            file: 'string',
            description: 'string',
          },
        ],
        student_profiles: {
          uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
          user_account: {
            first_name: 'string',
            last_name: 'string',
          },
          mark: 'string',
          student_assignment_replies: [
            {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              attached_files: [
                {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  file_name: 'string',
                  file: 'string',
                  description: 'string',
                },
              ],
              comment: 'string',
            },
          ],
        },
        state: 'issued',
      },
    },
    mocks: {
      $auth: authMockTeacher,
    },
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
        },
      },
    }),
  })
  if (wrapper.find('#viewMode').exists()) {
    t.pass()
  }
})

test('create task create mode teacher drop downs', (t) => {
  const wrapper = mount(CreateTask, {
    propsData: {
      createMode: true,
    },
    mocks: {
      $auth: authMockTeacher,
    },
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
        },
      },
    }),
  })
  const store = useHomeworkStore()
  CreateTask.computed.files.call(store.filesID)
  if (t.is(wrapper.findAll('.custom-select').length, 2)) {
    t.pass()
  }
})

test('create task create mode admin drop downs', (t) => {
  const wrapper = mount(CreateTask, {
    propsData: {
      createMode: true,
    },
    mocks: {
      $auth: authMockAdmin,
    },
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
        },
      },
    }),
  })
  const store = useHomeworkStore()
  CreateTask.computed.files.call(store.filesID)
  if (t.is(wrapper.findAll('.custom-select').length, 3)) {
    t.pass()
  }
})

test('create task save button create mode teacher', (t) => {
  const wrapper = mount(CreateTask, {
    propsData: {
      createMode: true,
    },
    mocks: {
      $auth: authMockTeacher,
    },
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
        },
      },
    }),
  })
  const store = useHomeworkStore()
  CreateTask.computed.files.call(store.filesID)
  if (wrapper.find('#createBtn').exists()) {
    t.pass()
  }
})

test('create task save button create mode admin', (t) => {
  const wrapper = mount(CreateTask, {
    propsData: {
      createMode: true,
    },
    mocks: {
      $auth: authMockTeacher,
    },
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
        },
      },
    }),
  })
  const store = useHomeworkStore()
  CreateTask.computed.files.call(store.filesID)
  if (wrapper.find('#createBtn').exists()) {
    t.pass()
  }
})

test('create task post button create mode teacher', (t) => {
  const wrapper = mount(CreateTask, {
    propsData: {
      selectedHomework: {
        uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        deadline: '2022-06-29T06:16:53.673Z',
        subject: 'string',
        grade: 'string',
        grade_group: 'string',
        description: 'string',
        attached_files: [
          {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            file_name: 'string',
            file: 'string',
            description: 'string',
          },
        ],
        student_profiles: {
          uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
          user_account: {
            first_name: 'string',
            last_name: 'string',
          },
          mark: 'string',
          student_assignment_replies: [
            {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              attached_files: [
                {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  file_name: 'string',
                  file: 'string',
                  description: 'string',
                },
              ],
              comment: 'string',
            },
          ],
        },
        state: 'issued',
      },
    },
    data() {
      return {
        readonly: false,
      }
    },
    mocks: {
      $auth: authMockTeacher,
    },
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
        },
      },
    }),
  })
  const store = useHomeworkStore()
  CreateTask.computed.files.call(store.filesID)
  if (wrapper.find('#postBtn').exists()) {
    t.pass()
  }
})

test('create task post button create mode admin', (t) => {
  const wrapper = mount(CreateTask, {
    propsData: {
      selectedHomework: {
        uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
        deadline: '2022-06-29T06:16:53.673Z',
        subject: 'string',
        grade: 'string',
        grade_group: 'string',
        description: 'string',
        attached_files: [
          {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            file_name: 'string',
            file: 'string',
            description: 'string',
          },
        ],
        student_profiles: {
          uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
          user_account: {
            first_name: 'string',
            last_name: 'string',
          },
          mark: 'string',
          student_assignment_replies: [
            {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              attached_files: [
                {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  file_name: 'string',
                  file: 'string',
                  description: 'string',
                },
              ],
              comment: 'string',
            },
          ],
        },
        state: 'issued',
      },
    },
    data() {
      return {
        readonly: false,
      }
    },
    mocks: {
      $auth: authMockAdmin,
    },
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          loading: false,
        },
      },
    }),
  })
  const store = useHomeworkStore()
  CreateTask.computed.files.call(store.filesID)
  if (wrapper.find('#postBtn').exists()) {
    t.pass()
  }
})
