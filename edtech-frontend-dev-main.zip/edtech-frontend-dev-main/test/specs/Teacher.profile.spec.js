import test from 'ava'
import { spy } from 'sinon'
import { mount, createLocalVue } from '@vue/test-utils'
import { PiniaVuePlugin } from 'pinia'
import { createTestingPinia } from '@pinia/testing'
import TeacherProfile from '~/components/profiles/TeacherProfile.vue'

const localVue = createLocalVue()
localVue.use(PiniaVuePlugin)

test('TeacherProfile.vue renders', (t) => {
  const wrapper = mount(TeacherProfile, {
    propsData: {
      profile: {},
    },
  })
  t.true(wrapper.exists())
  t.true(wrapper.find('.data__teacher').exists())
})

test('TeacherProfile.vue renders a placeholder image if there is no image in provided profile', (t) => {
  const wrapper = mount(TeacherProfile, {
    propsData: {
      profile: {},
    },
  })
  const teacherAvatar = wrapper.find('img')
  t.true(teacherAvatar.exists())
  t.is(teacherAvatar.attributes().src, '~/assets/images/avatar-placeholder.png')
})

test('TeacherProfile.vue renders teacher profile data', (t) => {
  const wrapper = mount(TeacherProfile, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy,
    }),
    propsData: {
      profile: {
        userAccount: {
          email: 'password0001@example.com',
          firstName: 'Brandi',
          lastName: 'Thomas',
          fullName: 'Thomas Brandi',
          role: '',
        },
        subjects: [],
        image:
          'https://squid-app-rjajp.ondigitalocean.app/m/class_teacher_profile_images/4060406a-2a56-4933-b90f-5777e946f9fc.jpg',
        phone: '+77081234567',
      },
      teacherUser: {
        email: 'password0001@example.com',
        firstName: 'Brandi',
        lastName: 'Thomas',
        fullName: 'Thomas Brandi',
        role: '',
      },
    },
  })
  t.true(wrapper.find('.data__profile_name').exists())
  t.true(wrapper.find('.data__profile_name').find('p').exists())
  t.is(
    wrapper.find('.data__profile_name').find('p').text(),
    wrapper.vm.teacherUser.fullName
  )
  t.true(wrapper.find('.data__profile_phone').exists())
  t.is(
    wrapper.find('.data__profile_phone').find('p').text(),
    'Телефон: ' + wrapper.vm.profile.phone
  )
  t.true(wrapper.find('.data__profile_email').exists())
  t.is(
    wrapper.find('.data__profile_email').find('p').text(),
    'Почтовый адрес: ' + wrapper.vm.teacherUser.email
  )
})
