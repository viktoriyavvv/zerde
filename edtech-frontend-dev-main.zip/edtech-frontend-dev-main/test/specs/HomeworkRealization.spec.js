import test from 'ava'
import { createLocalVue, mount } from '@vue/test-utils'
import { createTestingPinia } from '@pinia/testing'
import { PiniaVuePlugin } from 'pinia'
import { spy } from 'sinon'
import HomeworkRealization from '~/components/tasks/HomeworkRealization'

const localVue = createLocalVue()
localVue.use(PiniaVuePlugin)

test('homework realization reply', (t) => {
  const wrapper = mount(HomeworkRealization, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          selectedHomework: {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            deadline: '2022-06-30T07:53:24.752Z',
            subject: {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              name: 'string',
            },
            teacher_name: {
              first_name: 'string',
              last_name: 'string',
            },
            description: 'string',
            marks: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                mark_value: 0,
                max_mark_value: 0,
              },
            ],
            attached_files: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                file_name: 'string',
                file: 'string',
                description: 'string',
              },
            ],
            student_assignment_replies: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                attached_files: [
                  {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    file_name: 'string',
                    file: 'string',
                    description: 'string',
                  },
                ],
                comment: 'string',
              },
            ],
          },
        },
      },
    }),
  })

  if (wrapper.isVueInstance()) {
    t.pass()
  }
})

test('homework realization not deadline', (t) => {
  const wrapper = mount(HomeworkRealization, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          selectedHomework: {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            deadline: '2022-06-30T07:53:24.752Z',
            subject: {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              name: 'string',
            },
            teacher_name: {
              first_name: 'string',
              last_name: 'string',
            },
            description: 'string',
            marks: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                mark_value: 0,
                max_mark_value: 0,
              },
            ],
            attached_files: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                file_name: 'string',
                file: 'string',
                description: 'string',
              },
            ],
            student_assignment_replies: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                attached_files: [
                  {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    file_name: 'string',
                    file: 'string',
                    description: 'string',
                  },
                ],
                comment: 'string',
              },
            ],
          },
        },
      },
    }),
    data() {
      return {
        isDeadline: false,
      }
    },
  })

  if (wrapper.find('#replyField').exists()) {
    t.pass()
  }
})

test('homework realization deadline', (t) => {
  const wrapper = mount(HomeworkRealization, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          selectedHomework: {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            deadline: '2022-06-30T07:53:24.752Z',
            subject: {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              name: 'string',
            },
            teacher_name: {
              first_name: 'string',
              last_name: 'string',
            },
            description: 'string',
            marks: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                mark_value: 0,
                max_mark_value: 0,
              },
            ],
            attached_files: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                file_name: 'string',
                file: 'string',
                description: 'string',
              },
            ],
            student_assignment_replies: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                attached_files: [
                  {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    file_name: 'string',
                    file: 'string',
                    description: 'string',
                  },
                ],
                comment: 'string',
              },
            ],
          },
        },
      },
    }),
    data() {
      return {
        isDeadline: true,
      }
    },
  })

  if (wrapper.find('#deadlineWarn').exists()) {
    t.pass()
  }
})

test('homework realization already answered', (t) => {
  const wrapper = mount(HomeworkRealization, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          selectedHomework: {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            deadline: '2022-06-30T07:53:24.752Z',
            subject: {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              name: 'string',
            },
            teacher_name: {
              first_name: 'string',
              last_name: 'string',
            },
            description: 'string',
            marks: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                mark_value: 0,
                max_mark_value: 0,
              },
            ],
            attached_files: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                file_name: 'string',
                file: 'string',
                description: 'string',
              },
            ],
            student_assignment_replies: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                attached_files: [
                  {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    file_name: 'string',
                    file: 'string',
                    description: 'string',
                  },
                ],
                comment: 'string',
              },
            ],
          },
          studentReply: [
            {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              attached_files: [
                {
                  uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                  file_name: 'string',
                  file: 'string',
                  description: 'string',
                },
              ],
              comment: 'string',
            },
          ],
        },
      },
    }),
    data() {
      return {
        isDeadline: true,
      }
    },
  })

  if (wrapper.find('#answerWarn').exists()) {
    t.pass()
  }
})

test('homework realization reply state false', (t) => {
  const wrapper = mount(HomeworkRealization, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          selectedHomework: {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            deadline: '2022-06-30T07:53:24.752Z',
            subject: {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              name: 'string',
            },
            teacher_name: {
              first_name: 'string',
              last_name: 'string',
            },
            description: 'string',
            marks: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                mark_value: 0,
                max_mark_value: 0,
              },
            ],
            attached_files: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                file_name: 'string',
                file: 'string',
                description: 'string',
              },
            ],
            student_assignment_replies: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                attached_files: [
                  {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    file_name: 'string',
                    file: 'string',
                    description: 'string',
                  },
                ],
                comment: 'string',
              },
            ],
          },
        },
      },
    }),
  })

  if (wrapper.find('#saveBtn').exists()) {
    t.pass()
  }
})

test('homework realization reply state true', (t) => {
  const wrapper = mount(HomeworkRealization, {
    localVue,
    pinia: createTestingPinia({
      createSpy: spy(),
      initialState: {
        homework: {
          selectedHomework: {
            uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
            deadline: '2022-06-30T07:53:24.752Z',
            subject: {
              uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
              name: 'string',
            },
            teacher_name: {
              first_name: 'string',
              last_name: 'string',
            },
            description: 'string',
            marks: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                mark_value: 0,
                max_mark_value: 0,
              },
            ],
            attached_files: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                file_name: 'string',
                file: 'string',
                description: 'string',
              },
            ],
            student_assignment_replies: [
              {
                uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                attached_files: [
                  {
                    uuid: '3fa85f64-5717-4562-b3fc-2c963f66afa6',
                    file_name: 'string',
                    file: 'string',
                    description: 'string',
                  },
                ],
                comment: 'string',
              },
            ],
          },
          successReply: true,
        },
      },
    }),
  })

  if (wrapper.find('#successMsg').exists()) {
    t.pass()
  }
})
